"""Synology layout selection and a camera-only fullscreen presentation.

PeakOS edition: all layout requests are read-only. Video playback remains in
the existing LiveView/mpv implementation.
"""

from __future__ import annotations

import logging

import gi
gi.require_version("Gdk", "4.0")
gi.require_version("Gtk", "4.0")

from gi.repository import Gdk, Gio, GLib, Gtk

from surveillance.config import save_config_now
from surveillance.services.layout import ServerLayout, list_layouts
from surveillance.services.local_layout import load_local_layouts, make_local_layout_record
from surveillance.util.async_bridge import run_async

log = logging.getLogger(__name__)


class CameraPresentationMixin:
    def _init_camera_presentation(self) -> None:
        self.server_layouts: dict[int, ServerLayout] = {}
        self.layout_menu_status = "Connect to load layouts"
        self._layout_request = 0
        self._layout_inventory_ready = False
        self._layout_selection_revision = 0
        self._sequence_timer = 0
        self._sequence_children: list[ServerLayout] = []
        self._sequence_position = 0
        self._sequence_parent: ServerLayout | None = None
        self._camera_fullscreen = False
        self._fullscreen_hide_timer = 0

        self._server_layout_action = Gio.SimpleAction.new_stateful(
            "server-layout", GLib.VariantType.new("s"), GLib.Variant.new_string("")
        )
        self._server_layout_action.connect("change-state", self._choose_server_layout)
        self.add_action(self._server_layout_action)
        refresh = Gio.SimpleAction.new("refresh-server-layouts", None)
        refresh.connect("activate", lambda *_: self.refresh_server_layouts())
        self.add_action(refresh)
        new_layout = Gio.SimpleAction.new("new-camera-layout", None)
        new_layout.connect("activate", lambda *_: self.new_camera_layout())
        self.add_action(new_layout)
        fullscreen = Gio.SimpleAction.new("camera-fullscreen", None)
        fullscreen.connect("activate", lambda *_: self.set_camera_fullscreen(
            not self._camera_fullscreen
        ))
        self.add_action(fullscreen)
        self.app.set_accels_for_action("win.camera-fullscreen", ["F11"])
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._presentation_key_pressed)
        self.add_controller(keys)

    def _build_camera_presentation(self) -> None:
        # The camera controls share the grid's render tree, so they also work
        # with the OpenGL video surfaces used by mpv.
        self.presentation_overlay = Gtk.Overlay()
        self.set_child(None)
        self.presentation_overlay.set_child(self.paned)
        self.set_child(self.presentation_overlay)
        self._fullscreen_controls = Gtk.Revealer()
        self._fullscreen_controls.set_transition_type(Gtk.RevealerTransitionType.CROSSFADE)
        self._fullscreen_controls.set_halign(Gtk.Align.END)
        self._fullscreen_controls.set_valign(Gtk.Align.START)
        self._fullscreen_controls.set_margin_top(10)
        self._fullscreen_controls.set_margin_end(10)
        controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        controls.add_css_class("toolbar")
        controls.add_css_class("card")
        self._fullscreen_layout_btn = Gtk.MenuButton(label="Layouts")
        controls.append(self._fullscreen_layout_btn)
        self._whole_layout_btn = Gtk.Button(label="Whole Layout")
        self._whole_layout_btn.connect("clicked", lambda *_: self.show_whole_layout())
        controls.append(self._whole_layout_btn)
        leave = Gtk.Button(label="Exit Full Screen (Esc)")
        leave.connect("clicked", lambda *_: self.set_camera_fullscreen(False))
        controls.append(leave)
        self._fullscreen_controls.set_child(controls)
        self._fullscreen_controls.set_visible(False)
        self.presentation_overlay.add_overlay(self._fullscreen_controls)
        self.refresh_fullscreen_layout_menu()

    def refresh_fullscreen_layout_menu(self) -> None:
        if hasattr(self, "_fullscreen_layout_btn") and hasattr(self.headerbar, "grid_menu"):
            self._fullscreen_layout_btn.set_menu_model(self.headerbar.grid_menu)

    def _presentation_key_pressed(self, _controller, keyval, _keycode, _state) -> bool:
        if keyval == Gdk.KEY_Escape and self._camera_fullscreen:
            self.set_camera_fullscreen(False)
            return True
        return False

    def set_camera_fullscreen(self, enabled: bool, *, persist: bool = True) -> None:
        live = self.stack.get_child_by_name("live")
        if enabled and (not self.app.api or live is None):
            return
        self._camera_fullscreen = enabled
        if enabled:
            if self.stack.get_visible_child_name() != "live":
                self.show_page("live")
            self.headerbar.set_visible(False)
            self.sidebar.set_visible(False)
            live.set_presentation_mode(True)
            self.fullscreen()
            self._fullscreen_controls.set_visible(True)
            self._whole_layout_btn.set_visible(live.fullscreen_focus is not None)
            self.show_fullscreen_controls()
        else:
            if self._fullscreen_hide_timer:
                GLib.source_remove(self._fullscreen_hide_timer)
                self._fullscreen_hide_timer = 0
            self.unfullscreen()
            self.headerbar.set_visible(True)
            self.sidebar.set_visible(self.app.config.sidebar_visible)
            if live is not None:
                live.set_presentation_mode(False)
            if hasattr(self, "_fullscreen_controls"):
                self._fullscreen_controls.set_visible(False)
        if persist:
            self.app.config.camera_fullscreen = enabled
            save_config_now(self.app.config)

    def focus_camera_fullscreen(self, slot_index: int) -> None:
        live = self.stack.get_child_by_name("live")
        if live is None or slot_index not in live._active:
            return
        if live._slots[slot_index].camera is None:
            return
        if self._camera_fullscreen and live.fullscreen_focus == slot_index:
            self.show_whole_layout()
            return
        self.set_camera_fullscreen(True)
        live.set_fullscreen_focus(slot_index)
        self._whole_layout_btn.set_visible(True)
        self.show_fullscreen_controls()

    def show_whole_layout(self) -> None:
        live = self.stack.get_child_by_name("live")
        if live is not None:
            live.set_fullscreen_focus(None)
        if hasattr(self, "_whole_layout_btn"):
            self._whole_layout_btn.set_visible(False)
        self.show_fullscreen_controls()

    def show_fullscreen_controls(self) -> None:
        if not self._camera_fullscreen:
            return
        self._fullscreen_controls.set_reveal_child(True)
        if self._fullscreen_hide_timer:
            GLib.source_remove(self._fullscreen_hide_timer)
        self._fullscreen_hide_timer = GLib.timeout_add(3000, self._hide_fullscreen_controls)

    def _hide_fullscreen_controls(self) -> bool:
        popover = self._fullscreen_layout_btn.get_popover()
        if popover is not None and popover.get_visible():
            return True
        self._fullscreen_hide_timer = 0
        self._fullscreen_controls.set_reveal_child(False)
        return False

    def _layout_notice(self, text: str) -> None:
        live = self.stack.get_child_by_name("live")
        if live is not None and hasattr(live, "set_layout_notice"):
            live.set_layout_notice(text)

    def refresh_server_layouts(self) -> None:
        api = self.app.api
        if api is None:
            return
        self._layout_request += 1
        request = self._layout_request
        selection_revision = getattr(self, "_layout_selection_revision", 0)
        self.layout_menu_status = "Loading Synology layouts…"
        # Local named layouts remain available even if this account cannot
        # read the NAS layout API. Their negative IDs cannot collide with NAS IDs.
        local_layouts = load_local_layouts(getattr(self.app.config, "custom_layouts", []))
        self.server_layouts.update({layout.id: layout for layout in local_layouts})
        self.sidebar.set_server_layouts(self.server_layouts, self.app.config.selected_server_layout)
        self.sidebar.set_layout_loading(True)
        self.headerbar._build_grid_menu()
        self._layout_notice("Loading saved Synology layouts…")

        def loaded(layouts: list[ServerLayout]) -> None:
            if request != self._layout_request or self.app.api is not api:
                return
            self.server_layouts = {layout.id: layout for layout in layouts}
            # A local layout may have been created while the NAS request was
            # in flight; merge the current profile, not the earlier snapshot.
            self.server_layouts.update({layout.id: layout for layout in load_local_layouts(
                getattr(self.app.config, "custom_layouts", [])
            )})
            self.layout_menu_status = "No saved layouts for this account"
            self.sidebar.set_server_layouts(
                self.server_layouts, self.app.config.selected_server_layout
            )
            self.sidebar.set_layout_loading(False)
            self.headerbar._build_grid_menu()
            self._layout_notice("")
            self._layout_inventory_ready = True
            pending_restore = getattr(self, "_pending_live_restore", None)
            if pending_restore is not None:
                pending_restore()
            elif selection_revision == getattr(self, "_layout_selection_revision", 0):
                self.restore_selected_server_layout()

        def failed(error: Exception) -> None:
            if request != self._layout_request or self.app.api is not api:
                return
            log.warning("Could not load Synology layouts (%s)", type(error).__name__)
            self.layout_menu_status = "Layouts unavailable — refresh to retry"
            self.sidebar.set_layout_loading("Unable to read saved layouts. Click Refresh to retry.")
            self.headerbar._build_grid_menu()
            self._layout_notice(
                "Could not load saved Synology layouts. Your local grids still work. "
                "Check this account's layout access, then choose Refresh Synology Layouts."
            )
            self._layout_inventory_ready = True
            pending_restore = getattr(self, "_pending_live_restore", None)
            if pending_restore is not None:
                pending_restore()
                return
            selected = self.app.config.selected_server_layout
            if (selection_revision == getattr(self, "_layout_selection_revision", 0)
                    and selected.startswith("-") and selected[1:].isdecimal()):
                self.select_server_layout(selected)

        run_async(list_layouts(api), callback=loaded, error_callback=failed)

    def restore_selected_server_layout(self) -> bool:
        """Apply the current saved choice, or report that a local grid is needed.

        The startup coordinator calls this only when camera inventory exists.
        Manual refresh retains its previous behavior, using the inventory the
        already-open Live view has. A failed lookup keeps the saved choice so
        Refresh can recover it later without losing the user's preference.
        """
        selected = self.app.config.selected_server_layout
        if selected.lstrip("-").isdecimal() and int(selected) in self.server_layouts:
            return self.select_server_layout(int(selected))
        if not selected:
            default = next((layout for layout in self.server_layouts.values()
                            if layout.is_default), None)
            return self.select_server_layout(default.id) if default is not None else False
        if selected != "local":
            self._stop_layout_sequence()
            self._layout_notice(
                "The saved Synology layout is unavailable for this account. "
                "Choose another layout from the Layouts menu."
            )
        return False

    def _choose_server_layout(self, action, value: GLib.Variant) -> None:
        key = value.get_string()
        if key.lstrip("-").isdecimal():
            self.select_server_layout(int(key))

    def new_camera_layout(self) -> None:
        """Name and assign a new local or NAS layout from an explicit Save."""
        api = self.app.api
        if api is None:
            return
        from surveillance.ui.layout_editor import LayoutEditorDialog
        from surveillance.api.client import ApiError
        from surveillance.services.layout import (
            create_layout, LayoutCreateUncertainError, LayoutFormatError,
        )

        def save(name, columns, rows, camera_ids, save_on_nas) -> None:
            if self.app.api is not api:
                dialog.show_error("The connection changed. Close this window and try again.")
                return
            if not save_on_nas:
                previous = self.app.config.custom_layouts
                try:
                    record = make_local_layout_record(previous, name, columns, rows, camera_ids)
                except ValueError as error:
                    dialog.show_error(str(error))
                    return
                try:
                    self.app.config.custom_layouts = [*previous, record]
                    save_config_now(self.app.config)
                except OSError:
                    self.app.config.custom_layouts = previous
                    dialog.show_error("The layout could not be saved on this 10ZiG. Check that its application profile is writable.")
                    return
                layout = load_local_layouts([record])[0]
                self.server_layouts[layout.id] = layout
                self.headerbar._build_grid_menu()
                dialog.close()
                self.select_server_layout(layout.id)
                return

            def created(identifier: int) -> None:
                dialog.close()
                if self.app.api is not api:
                    return
                self.app.config.selected_server_layout = str(identifier)
                try:
                    save_config_now(self.app.config)
                except OSError:
                    log.warning("NAS layout was saved, but its local selection could not be persisted")
                self.refresh_server_layouts()

            def failed(error: Exception) -> None:
                log.warning("NAS layout creation failed (%s)", type(error).__name__)
                if isinstance(error, (ValueError, LayoutFormatError, LayoutCreateUncertainError)):
                    dialog.show_error(str(error))
                elif isinstance(error, ApiError):
                    dialog.show_error(
                        f"Synology refused the save (API error {error.code}). "
                        "Sign in again if the session expired, or use an account with "
                        "permission to create layouts. You can also choose This 10ZiG."
                    )
                else:
                    dialog.show_error(
                        "The NAS could not be reached to prepare the new layout. "
                        "Try again after reconnecting, or choose This 10ZiG."
                    )

            run_async(create_layout(api, name, columns, rows, camera_ids),
                      callback=created, error_callback=failed)

        dialog = LayoutEditorDialog(self, self.sidebar.cameras, save, nas_enabled=True)
        dialog.present()

    def _stop_layout_sequence(self) -> None:
        if self._sequence_timer:
            GLib.source_remove(self._sequence_timer)
            self._sequence_timer = 0
        self._sequence_children = []
        self._sequence_parent = None

    def select_local_layout(self) -> None:
        self._layout_selection_revision = getattr(self, "_layout_selection_revision", 0) + 1
        if getattr(self, "_startup_cameras", None) is not None:
            self._pending_live_restore = None
        self._stop_layout_sequence()
        self.app.config.selected_server_layout = "local"
        self._server_layout_action.set_state(GLib.Variant.new_string(""))
        self.sidebar.set_server_layouts(self.server_layouts, "")
        self.show_whole_layout()
        self._layout_notice("")
        save_config_now(self.app.config)

    def select_server_layout(self, layout_id: int | str) -> bool:
        try:
            layout_id = int(layout_id)
        except (TypeError, ValueError):
            return False
        layout = self.server_layouts.get(layout_id)
        if layout is None:
            return False
        live = self.stack.get_child_by_name("live")
        if live is None:
            return False
        self._stop_layout_sequence()
        if layout.kind == "alert":
            self.sidebar.set_server_layouts(self.server_layouts, self.app.config.selected_server_layout)
            self._layout_notice(
                "Event-driven alert layouts are not supported in this native edition. "
                "Choose a camera layout or a sequential layout."
            )
            return False
        if layout.kind == "sequence":
            children = [self.server_layouts[i] for i in layout.child_layout_ids
                        if i in self.server_layouts
                        and self.server_layouts[i].kind not in ("sequence", "alert", "unsupported")]
            if not children:
                self.sidebar.set_server_layouts(self.server_layouts, self.app.config.selected_server_layout)
                self._layout_notice("This sequential layout has no accessible camera layouts.")
                return False
            self._sequence_parent = layout
            self._sequence_children = children
            self._sequence_position = 0
            displayed = children[0]
        else:
            displayed = layout
        self._layout_selection_revision = getattr(self, "_layout_selection_revision", 0) + 1
        if getattr(self, "_startup_cameras", None) is not None:
            self._pending_live_restore = None
        self.app.config.selected_server_layout = str(layout.id)
        self._server_layout_action.set_state(GLib.Variant.new_string(str(layout.id)))
        self.sidebar.set_server_layouts(self.server_layouts, str(layout.id))
        self._grid_layout_action.set_state(GLib.Variant.new_string(""))
        self.show_page("live")
        live.set_server_layout(displayed)
        title = f"{layout.name} · {displayed.name}" if displayed is not layout else layout.name
        self.headerbar.set_layout_title(title)
        self.show_whole_layout()
        save_config_now(self.app.config)
        if self._sequence_children:
            self._schedule_layout_sequence()
        return True

    def _schedule_layout_sequence(self) -> None:
        if self._sequence_children:
            child = self._sequence_children[self._sequence_position]
            self._sequence_timer = GLib.timeout_add_seconds(
                max(1, int(child.interval)), self._advance_layout_sequence
            )

    def _advance_layout_sequence(self) -> bool:
        self._sequence_timer = 0
        live = self.stack.get_child_by_name("live")
        if not self.app.api or not self._sequence_children or live is None:
            self._sequence_timer = 0
            return False
        # Keep the operator's enlarged camera still while they inspect it.
        if self.stack.get_visible_child_name() != "live" or live.fullscreen_focus is not None:
            self._schedule_layout_sequence()
            return False
        self._sequence_position = (self._sequence_position + 1) % len(self._sequence_children)
        layout = self._sequence_children[self._sequence_position]
        live.set_server_layout(layout)
        self.headerbar.set_layout_title(f"{self._sequence_parent.name} · {layout.name}")
        self._schedule_layout_sequence()
        return False

    def reset_camera_presentation(self) -> None:
        self._layout_request += 1
        self._layout_inventory_ready = False
        self._pending_live_restore = None
        self._stop_layout_sequence()
        self.server_layouts = {}
        self.layout_menu_status = "Connect to load layouts"
        self.sidebar.set_server_layouts({})
        self.sidebar.set_layout_loading(False)
        if self._camera_fullscreen:
            self.set_camera_fullscreen(False, persist=False)
        self.headerbar._build_grid_menu()
