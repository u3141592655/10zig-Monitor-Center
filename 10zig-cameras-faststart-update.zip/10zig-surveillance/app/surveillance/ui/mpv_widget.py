# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""MPV video player widget using GTK4 GLArea + mpv OpenGL render context."""

from __future__ import annotations

import contextlib
import ctypes
import ctypes.util
import logging
import math
import os
import re
import shlex
import time
from collections.abc import Callable
from typing import Any

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import GLib, Gtk  # type: ignore[import-untyped]

from surveillance.ui.fisheye import MOUNT_CEILING, DewarpView, FisheyeRenderer, Lens

log = logging.getLogger(__name__)


class _LiveBacklogWatch:
    """Detect growing delay in a *timed* live player, not absolute NAS age.

    A source with arbitrary/epoch PTS is fine: only changes against the
    local monotonic clock matter. Raw untimed NAL streams must never feed
    this detector; their synthetic player clock is not camera time.
    """

    def __init__(self) -> None:
        self.started: float | None = None
        self.last_now: float | None = None
        self.last_pts: float | None = None
        self.best_offset: float | None = None
        self.advances = 0
        self.bad_since: float | None = None
        self.reported = False

    def sample(
        self, now: float, pts: float | None, cache: float | None, target: float = 0.0
    ) -> str | None:
        if self.reported or pts is None or not math.isfinite(pts):
            return None
        if self.started is None:
            self.started = self.last_now = now
            self.last_pts = pts
            self.best_offset = now - pts
            return None
        assert self.last_now is not None and self.last_pts is not None
        delta = pts - self.last_pts
        elapsed = now - self.last_now
        # A new timeline / timestamp discontinuity is not playback lag.
        if elapsed < 0 or delta < -0.25 or delta > max(30.0, elapsed * 4 + 1):
            self.__init__()
            return self.sample(now, pts, cache, target)
        self.last_now = now
        advanced = delta > 0.000001
        if advanced:
            self.advances += 1
            self.last_pts = pts
            self.best_offset = min(self.best_offset, now - pts)  # type: ignore[type-var]
        if self.advances < 3 or now - self.started < 5.0:
            return None
        lag = max(0.0, (now - pts) - self.best_offset) if advanced else 0.0
        excess_cache = (
            max(0.0, cache - max(0.0, target))
            if cache is not None and math.isfinite(cache) else 0.0
        )
        # An unchanging time-pos with no buffered video can be a sparse
        # camera, a still, or an offline placeholder; it is not evidence
        # of accumulating old video. Excess cache is separate evidence.
        if not advanced and excess_cache <= 3.0:
            return None
        if lag <= 3.0 and excess_cache <= 3.0:
            self.bad_since = None
            return None
        if self.bad_since is None:
            self.bad_since = now
            return None
        if now - self.bad_since < 2.0:
            return None
        self.reported = True
        if excess_cache > 3.0:
            return f"live player has {excess_cache:.1f}s excess buffered video"
        return f"live player has fallen {lag:.1f}s behind its initial playback clock"


def _load_gl_get_proc() -> ctypes.CDLL | None:
    """Load a native GL library that can resolve proc addresses."""
    candidates: list[str] = []
    for name in ("EGL", "GL", "GLX"):
        path = ctypes.util.find_library(name)
        if path:
            candidates.append(path)
    candidates.extend(("libEGL.so.1", "libGL.so.1", "libGLX.so.0"))
    for lib_name in candidates:
        try:
            lib = ctypes.CDLL(lib_name)
            # Verify it has a proc address function
            for fn_name in ("eglGetProcAddress", "glXGetProcAddressARB", "glXGetProcAddress"):
                fn = getattr(lib, fn_name, None)
                if fn is not None:
                    fn.argtypes = [ctypes.c_char_p]
                    fn.restype = ctypes.c_void_p
                    return lib
        except OSError:
            continue
    return None


_gl_lib = _load_gl_get_proc()

# video-zoom is mpv's own log2 scale (0 = 100%, 1 = 200%, ...). Zooming out
# below 100% would just letterbox the video within the widget for no
# benefit, so the range only goes up from there.
_ZOOM_MIN = 0.0
_ZOOM_MAX = 3.0  # 2**3 = 800%
# Clamp so scrolling can't pan the video entirely out of view.
_PAN_MAX = 0.8

# Layout thumbnails are downscaled aggressively. mpv's high quality
# convolution/linear-light scaler grows its work as the downscale ratio
# increases; doing that for every tile serializes expensive GL work on
# GTK's main thread. Use the texture sampler's inexpensive bilinear path
# for grids, then restore the player's own settings in enlarged view.
_GRID_SCALING_OPTIONS: dict[str, Any] = {
    "scale": "bilinear",
    "dscale": "bilinear",
    "cscale": "bilinear",
    "correct-downscaling": False,
    "linear-downscaling": False,
    "sigmoid-upscaling": False,
}

# Adaptive playback-speed control keeps mpv's demuxer cache near its
# configured target instead of drifting unbounded in either direction:
# growing when decode falls behind, or draining during a network stall.
# Meaningful only for a profile actually running a cache: RTSP/default
# and muxed_audio always, low_latency only once a fast History rewind
# gives it one.
_CACHE_CONTROL_INTERVAL_MS = 500
_CACHE_CONTROL_SPEED_UP = 1.2
_CACHE_CONTROL_SPEED_DOWN = 0.8
_CACHE_CONTROL_SPEED_UP_ENTER = 1.5  # x target - reaches _SPEED_UP here
_CACHE_CONTROL_SPEED_DOWN_ENTER = 0.5  # x target - reaches _SPEED_DOWN here
# Periodic visibility into cache depth
_CACHE_LOG_INTERVAL_TICKS = round(2000 / _CACHE_CONTROL_INTERVAL_MS)  # ~2s

# Baseline cache target (seconds) for each playback profile, before
# _cache_target_seconds's own speed-aware adjustment. low_latency's
# cache stays off (see _apply_playback_options) whenever this ends up
# 0 (Live, or a History speed below _CACHE_HIGH_SPEED_ENTER), and
# turns on automatically once it isn't, for the extra buffer a fast
# History rewind needs.
_CACHE_SECONDS_DEFAULT = 0.5
_CACHE_SECONDS_MUXED_AUDIO = 0.5
_CACHE_SECONDS_LOW_LATENCY = 0.0

# Extra cache _high_speed_cache_seconds adds on top of a profile's
# baseline at a high History speed: 0 below _CACHE_HIGH_SPEED_ENTER,
# growing exponentially to _CACHE_HIGH_SPEED_MAX_SECONDS at a 100x
# factor (the fastest option Timeline's speed dropdown offers).
_CACHE_HIGH_SPEED_ENTER = 2.0  # x history speed - extra cache starts here
_CACHE_HIGH_SPEED_MAX_SECONDS = 8.0  # ~seconds added at a 100x factor
_CACHE_HIGH_SPEED_GROWTH = math.log(_CACHE_HIGH_SPEED_MAX_SECONDS) / (
    100.0 - _CACHE_HIGH_SPEED_ENTER
)

# Demuxer byte cap for every profile actually running a cache (see
# _apply_playback_options): mpv reads ahead by whichever of this and
# the seconds-based cache-secs/demuxer-readahead-secs above is larger,
# so too small a cap here can bottleneck a cache that's otherwise
# sized generously (e.g. low_latency's at a high History speed).
_DEMUXER_MAX_BYTES_MIB = 32.0

# Byte cap for a profile running with no cache at all -- today only a
# silent camera's Live stream. mpv's own docs put demuxer-max-bytes as
# the limit on "excessive readahead in case of broken files or desynced
# playback", so it is not the dead letter an unused cache would suggest:
# it is exactly the ceiling the demuxer buffers up to while playback is
# stalled, before backpressure reaches the pipe. Keeping it tight here
# bounds that per slot, which matters most on a full 4x4 grid, and costs
# nothing when nothing is stalled -- a stream reading ahead zero seconds
# never approaches it.
_DEMUXER_MAX_BYTES_UNCACHED = "512KiB"

# Cap on the demuxer's back buffer, the already-played data mpv keeps
# so a backward seek can be served without reading the source again.
# mpv's own default is 50 MiB per player, which a live stream fills
# and holds for nothing: Live never seeks, and a History seek restarts
# DSM's stream rather than seeking within it. On a full grid that adds
# up to a large share of the app's memory growth over a day. Applied to
# every profile, so the Recordings player's skip-back re-reads its
# source instead of using the buffer.
_DEMUXER_MAX_BACK_BYTES_MIB = 1.0


# Runtime setters for the constants above, used by the Settings page's
# player-settings registry (surveillance.settings_registry) to override
# them without a restart. Each constant is read fresh wherever it's
# used in this module, so reassigning it here takes effect on the very
# next stream tick. Clamped to a sane floor: a hand-edited config file
# could otherwise hand these a negative (or, for the high-speed one,
# zero) value that mpv or math.log would reject.
def set_cache_seconds_default(value: float) -> None:
    global _CACHE_SECONDS_DEFAULT
    _CACHE_SECONDS_DEFAULT = max(value, 0.0)


def set_cache_seconds_muxed_audio(value: float) -> None:
    global _CACHE_SECONDS_MUXED_AUDIO
    _CACHE_SECONDS_MUXED_AUDIO = max(value, 0.0)


# The two byte caps are whole MiB: mpv refuses a size like "2.5MiB".
def set_demuxer_max_bytes_mib(value: float) -> None:
    global _DEMUXER_MAX_BYTES_MIB
    _DEMUXER_MAX_BYTES_MIB = float(max(round(value), 1))


def set_demuxer_max_back_bytes_mib(value: float) -> None:
    global _DEMUXER_MAX_BACK_BYTES_MIB
    _DEMUXER_MAX_BACK_BYTES_MIB = float(max(round(value), 0))


def set_cache_seconds_low_latency(value: float) -> None:
    global _CACHE_SECONDS_LOW_LATENCY
    _CACHE_SECONDS_LOW_LATENCY = max(value, 0.0)


def set_high_speed_cache_max_seconds(value: float) -> None:
    """Update _CACHE_HIGH_SPEED_MAX_SECONDS and the growth rate derived
    from it together, since the growth rate is only ever computed once
    (not read fresh like the plain constants above) and would otherwise
    go stale."""
    global _CACHE_HIGH_SPEED_MAX_SECONDS, _CACHE_HIGH_SPEED_GROWTH
    value = max(value, 0.1)  # math.log below is undefined at or below 0
    _CACHE_HIGH_SPEED_MAX_SECONDS = value
    _CACHE_HIGH_SPEED_GROWTH = math.log(value) / (100.0 - _CACHE_HIGH_SPEED_ENTER)


# Whether _tick_cache_control draws its cache/target/speed readout as
# mpv OSD text: off by default, toggled from the Settings page (see
# set_osd_enabled). Checked fresh every tick, so toggling this takes
# effect within one tick (_CACHE_CONTROL_INTERVAL_MS) on an
# already-playing stream. The readout lands top-left, which is mpv's
# own default corner for osd-msg1 and the one sitting over video least
# often, so nothing has to ask for it.
_OSD_ENABLED = False


def set_osd_enabled(value: bool) -> None:
    global _OSD_ENABLED
    _OSD_ENABLED = value


def _high_speed_cache_seconds(high_playback_speed_factor: float) -> float:
    """Extra cache (seconds) to add on top of a profile's baseline once
    DSM is delivering frames at *high_playback_speed_factor* or faster:
    0 below _CACHE_HIGH_SPEED_ENTER, exactly 1.0 at
    _CACHE_HIGH_SPEED_ENTER, growing exponentially to
    _CACHE_HIGH_SPEED_MAX_SECONDS at a 100x factor: a low-speed/Live
    stream keeps the profile's own small baseline untouched, while a
    high-speed History stream gets real margin to swallow the increased
    traffic.
    """
    if high_playback_speed_factor < _CACHE_HIGH_SPEED_ENTER:
        return 0.0
    return math.exp(
        _CACHE_HIGH_SPEED_GROWTH * (high_playback_speed_factor - _CACHE_HIGH_SPEED_ENTER)
    )


def _cache_target_seconds(default_seconds: float, high_playback_speed_factor: float) -> float:
    """Cache target (seconds) to actually use, given a profile's own
    baseline *default_seconds* (one of the _CACHE_SECONDS_* constants)
    plus whatever _high_speed_cache_seconds adds for
    *high_playback_speed_factor* (DSM's own History-speed multiplier).
    """
    return default_seconds + _high_speed_cache_seconds(high_playback_speed_factor)


def _cache_control_speed(
    cache_seconds: float, target_seconds: float, *, live: bool = False
) -> float:
    """Playback-speed correction for a cache sitting at *cache_seconds*
    against *target_seconds*: 1.0x exactly on target, ramping linearly
    toward _CACHE_CONTROL_SPEED_UP as the ratio reaches
    _CACHE_CONTROL_SPEED_UP_ENTER, or toward _CACHE_CONTROL_SPEED_DOWN
    at _CACHE_CONTROL_SPEED_DOWN_ENTER.

    Live viewing never deliberately runs slower than real time. A thin
    cache can mean a starved pipe or decoder; slowing the camera to 0.8x
    does not repair that producer and instead turns current events into
    slow motion. Preserve the original two-sided correction for History
    and recording playback, where delivery is not a live wall clock.

    Bounded by those two either way, and deliberately unaware of DSM's
    History-speed multiplier. A high History speed is delivery rate,
    not a clock this correction sits on top of: DSM scales the frame
    rate and the msec header together and the client just relays what
    arrives (see WebSocketBridge._history_play_params' own "speed"
    bullet), so mpv's own speed is never already running that many
    times faster. Scaling this by the multiplier would make it a
    fast-forward rather than a correction -- 21x at 100x History --
    which empties the cache inside one tick and swings straight to the
    floor.
    """
    ratio = cache_seconds / target_seconds
    if ratio >= 1.0:
        fraction = min(1.0, (ratio - 1.0) / (_CACHE_CONTROL_SPEED_UP_ENTER - 1.0))
        return 1.0 + fraction * (_CACHE_CONTROL_SPEED_UP - 1.0)
    if live:
        return 1.0
    fraction = min(1.0, (1.0 - ratio) / (1.0 - _CACHE_CONTROL_SPEED_DOWN_ENTER))
    return 1.0 - fraction * (1.0 - _CACHE_CONTROL_SPEED_DOWN)


def _get_gl_proc_address(_ctx: ctypes.c_void_p, name: bytes) -> int:
    """Get OpenGL procedure address via native GL library.

    Signature matches mpv's MpvGlGetProcAddressFn:
      CFUNCTYPE(c_void_p, c_void_p, c_char_p)
    """
    if _gl_lib is None:
        return 0
    for fn_name in ("eglGetProcAddress", "glXGetProcAddressARB", "glXGetProcAddress"):
        fn = getattr(_gl_lib, fn_name, None)
        if fn is not None:
            addr = fn(name)
            if addr:
                return addr  # type: ignore[no-any-return]
    return 0


# libmpv 0.40 and 0.41 create a GL fence for every rendered frame but only
# delete them in a swap_buffers step the render API never runs, so every
# frame leaks one (mpv commit f74adc4 fixes it upstream, unreleased as of
# 0.41). Some drivers hold several KB per fence, so a full grid leaks
# gigabytes an hour. Handing those versions a glFenceSync that returns no
# fence stops the leak: mpv checks for a null fence before keeping one.
# Its only other user guards texture uploads from a host-mapped buffer, and
# reads a null fence as already signaled, so the buffer could be reused
# while the GPU still reads it. Only direct rendering allocates those
# (gpu-pbo uploads use host-mutable ones, which get no fence), and it needs
# the render context's advanced_control, which _on_realize does not set.
# Turning that on for these versions would need the fences back.
_NO_FENCE_SYNC = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint)(
    lambda _condition, _flags: None
)
_NO_FENCE_SYNC_ADDR = ctypes.cast(_NO_FENCE_SYNC, ctypes.c_void_p).value


def _get_gl_proc_address_no_fences(_ctx: ctypes.c_void_p, name: bytes) -> int:
    """_get_gl_proc_address, except glFenceSync resolves to a stub that
    never creates a fence (see _NO_FENCE_SYNC)."""
    if name == b"glFenceSync":
        return _NO_FENCE_SYNC_ADDR  # type: ignore[return-value]
    return _get_gl_proc_address(_ctx, name)


def _mpv_leaks_vsync_fences(version: str) -> bool:
    """Whether this mpv-version string ("mpv 0.41.0", "mpv v0.41.0-12-g...")
    is one of the releases with the per-frame fence leak."""
    match = re.search(r"(\d+)\.(\d+)", version)
    if match is None:
        return False
    return (0, 40) <= (int(match.group(1)), int(match.group(2))) < (0, 42)


def _mpv_options_from_env() -> tuple[list[str], dict[str, str]]:
    """Flags and options named in SURVEILLANCE_MPV_OPTS, for mpv.MPV().

    Split like a shell command line, so a value keeps its commas
    (hwdec=nvdec,vaapi is mpv's own list syntax) and one with whitespace
    can be quoted. name=value sets an option and a bare name is a flag,
    as on mpv's command line. Nothing is checked here: mpv refuses a
    name it does not know when the handle is created, and _on_realize
    logs that failure with the name in it.
    """
    flags: list[str] = []
    options: dict[str, str] = {}
    for item in shlex.split(os.environ.get("SURVEILLANCE_MPV_OPTS", "")):
        name, sep, value = item.partition("=")
        if sep:
            options[name] = value
        else:
            flags.append(name)
    return flags, options


def _start_option(offset: float) -> str:
    """mpv's `start` for an offset of *offset* seconds, or for none.

    "none" is what mpv reads as unset; "0" is a position like any other,
    so it made the player seek to the beginning of every stream it
    opened. A pipe cannot seek, so each one answered with "Cannot seek
    in this stream" at error level and mpv fell back to playing from
    wherever it already was. The option is sticky on a reused handle,
    which is why an offset of none has to be written rather than left
    alone: it clears the offset the previous recording set.
    """
    return str(offset) if offset else "none"


class MpvGLArea(Gtk.GLArea):
    """GTK4 GLArea widget that renders mpv video via OpenGL.

    Each instance has its own mpv player and render context.
    Works on both X11 and Wayland without wid embedding.
    """

    def __init__(self, tls_verify: bool = True) -> None:
        super().__init__()
        self._mpv: Any = None
        self._ctx: Any = None
        self._url: str = ""
        self._initialized = False
        self._render_pending = False
        self._tls_verify = tls_verify
        self._low_latency = False
        self._muxed_audio = False
        self._live = False
        self._live_generation = 0
        self._live_observations: dict[str, Any] = {}
        self._live_observers: list[tuple[str, Callable[..., None]]] = []
        self._live_backlog = _LiveBacklogWatch()
        self._grid_mode = False
        self._grid_saved_options: dict[str, Any] = {}
        # libavformat's name for the raw pipe's codec, handed over by
        # play(). Empty means auto-detection, which is every profile
        # with a real container and any stream started before one
        # is known.
        self._video_format = ""
        self._start_offset: float = 0
        self._zoom: float = 0.0
        self._pan_x: float = 0.0
        self._pan_y: float = 0.0
        self._muted = False
        self._volume = 100
        self._cache_control_enabled = False
        self._cache_control_source: int | None = None
        self._cache_log_tick = 0
        # DSM's own History-speed multiplier (Live View's timeline speed
        # dropdown — see Timeline._SPEED_OPTIONS), already baked into how
        # fast DSM delivers frames. Used for additional throttling of
        # self._mpv.speed and so _tick_cache_control can report the true
        # playback multiplier.
        self._history_speed: float = 1.0
        # Fisheye dewarp (ui.fisheye): the view state, and its GL objects,
        # created on the first dewarped render with the context current.
        self._dewarp = DewarpView()
        self._fisheye: FisheyeRenderer | None = None
        # Set once the dewarp has failed on this widget's GL, which will
        # not do better on the next stream (see _render_dewarped).
        self._dewarp_failed = False
        # mpv's dwidth/dheight as last reported (_on_video_size).
        self._video_size: dict[str, int] = {"dwidth": 0, "dheight": 0}

        self.set_auto_render(False)
        self.set_hexpand(True)
        self.set_vexpand(True)

        self.connect("realize", self._on_realize)
        self.connect("unrealize", self._on_unrealize)
        self.connect("render", self._on_render)

    def _on_realize(self, widget: Gtk.GLArea) -> None:
        """Initialize mpv and OpenGL render context when widget is realized."""
        self.make_current()

        if self.get_error():
            log.error("GLArea has error: %s", self.get_error())
            return

        try:
            import mpv

            # Audio output driver, left to mpv's own autoprobe unless
            # SURVEILLANCE_AO names one. The AppImage sets it to pulse where
            # it had to keep its own libpipewire, since mpv's PipeWire output
            # would then pair that copy with the host's modules and take the
            # process down with it (see TROUBLESHOOTING.md).
            ao_option: dict[str, str] = {}
            ao = os.environ.get("SURVEILLANCE_AO", "").strip()
            if ao:
                ao_option["ao"] = ao
                log.info("Audio output driver set to %s", ao)

            # Extra options from the environment, e.g. hwdec-extra-frames=12
            # when NVDEC reports "No decoder surfaces left" on a stream with
            # a deep reorder buffer, or hwdec=nvdec to pick the decoder.
            extra_flags, extra_opts = _mpv_options_from_env()
            if extra_flags or extra_opts:
                log.info(
                    "Extra mpv options from SURVEILLANCE_MPV_OPTS: %s %s", extra_flags, extra_opts
                )

            # The client's own options, spelled as mpv spells them, so an
            # entry from SURVEILLANCE_MPV_OPTS naming one replaces it here
            # rather than reaching the constructor as a second keyword
            # argument of the same name, which Python refuses before mpv
            # sees anything.
            options: dict[str, Any] = {
                "vo": "libmpv",
                "hwdec": "auto",
                "keep-open": "yes",
                "idle": "yes",
                "input-default-bindings": False,
                "input-vo-keyboard": False,
                # GTK renders every camera on one main thread. libmpv's
                # default 50 ms timing lead otherwise lets one tile wait
                # for its presentation timestamp while all the other tiles
                # and UI events are blocked. Let GTK's frame clock present
                # the picture, without a deliberate wait inside render().
                "video-timing-offset": 0,
                # A minimum level, not a filter: at "fatal" libmpv delivers
                # nothing else, so _mpv_log's error and warn branches could
                # never run and mpv was silent about every problem short of
                # a fatal one. It writes nothing to stderr either, terminal
                # being off, so this handler is the only way its diagnostics
                # reach a log at all.
                "loglevel": "debug" if log.isEnabledFor(logging.DEBUG) else "warn",
                "demuxer-lavf-o": "rtsp_transport=tcp",
                "tls-verify": self._tls_verify,
                "mute": self._muted,
                "volume": self._volume,
                **ao_option,
            }
            options.update(extra_opts)
            self._mpv = mpv.MPV(*extra_flags, log_handler=self._mpv_log, **options)
            if getattr(self, "_grid_mode", False):
                MpvGLArea.set_grid_mode(self, True)
            self._mpv.observe_property("dwidth", self._on_video_size)
            self._mpv.observe_property("dheight", self._on_video_size)

            version = str(getattr(self._mpv, "mpv_version", ""))
            if _mpv_leaks_vsync_fences(version):
                log.debug("%s leaks GL fences, rendering without them", version)
                resolver = _get_gl_proc_address_no_fences
            else:
                resolver = _get_gl_proc_address
            # Wrap with mpv's own CFUNCTYPE so ctypes type identity matches
            self._proc_addr_fn = mpv.MpvGlGetProcAddressFn(resolver)

            # Set up OpenGL render context
            self._ctx = mpv.MpvRenderContext(
                self._mpv,
                "opengl",
                opengl_init_params={
                    "get_proc_address": self._proc_addr_fn,
                },
            )

            self._ctx.update_cb = self._mpv_update_cb
            self._initialized = True

            # If URL was set before realization, apply options and start playing
            if self._url:
                self._apply_playback_options()
                self._restart_cache_control()
                self._mpv["start"] = _start_option(self._start_offset)
                self._mpv.play(self._url)
                MpvGLArea._observe_live_clock(self)

        except Exception:
            log.exception("Failed to initialize mpv")
            self._initialized = False

    def _on_unrealize(self, widget: Gtk.GLArea) -> None:
        """Clean up mpv when widget is unrealized."""
        self.stop()
        if self._fisheye is not None:
            self.make_current()
            self._fisheye.free()
            self._fisheye = None
        if self._ctx:
            with contextlib.suppress(Exception):
                self._ctx.free()
            self._ctx = None
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.terminate()
            self._mpv = None
        self._grid_saved_options = {}
        self._initialized = False

    def _on_render(self, area: Gtk.GLArea, ctx: Any) -> bool:
        """Render callback - called by GTK when the area needs to be redrawn."""
        self._render_pending = False

        if not self._initialized or not self._ctx:
            return True

        try:
            if not self._url:
                # No active stream: paint black instead of asking mpv's render
                # context to redraw, since libmpv keeps repainting the last
                # decoded frame it has buffered until a new one arrives.
                from OpenGL.GL import GL_COLOR_BUFFER_BIT, glClear, glClearColor

                glClearColor(0.0, 0.0, 0.0, 1.0)
                glClear(GL_COLOR_BUFFER_BIT)
                return True

            width = self.get_width()
            height = self.get_height()
            scale = self.get_scale_factor()

            from OpenGL.GL import GL_FRAMEBUFFER_BINDING, glGetIntegerv

            fbo = int(glGetIntegerv(GL_FRAMEBUFFER_BINDING))

            if self._dewarp.active and self._render_dewarped(
                ctx, fbo, width * scale, height * scale
            ):
                self._ctx.report_swap()
                return True

            self._ctx.render(
                flip_y=True,
                block_for_target_time=False,
                opengl_fbo={
                    "w": width * scale,
                    "h": height * scale,
                    "fbo": fbo,
                },
            )
            self._ctx.report_swap()
        except Exception as e:
            log.debug("Render error: %s", e)

        return True

    def _render_dewarped(self, gl_context: Any, fbo: int, width: int, height: int) -> bool:
        """Render the frame through the fisheye dewarp into *fbo*.

        mpv draws into an offscreen texture at the video's own size, so
        the circle keeps its full resolution, and the dewarp shader then
        fills the widget from it. Returns False, having turned the dewarp
        off for this widget, when GL can't do it, so the caller falls back
        to the plain picture rather than a black slot.
        """
        if self._ctx is None:
            return False
        try:
            if self._fisheye is None:
                self._fisheye = FisheyeRenderer(bool(gl_context.get_use_es()))
            src_w = self._video_size["dwidth"]
            src_h = self._video_size["dheight"]
            if src_w <= 0 or src_h <= 0:
                src_w, src_h = width, height
            limit = 4096
            if max(src_w, src_h) > limit:
                f = limit / max(src_w, src_h)
                src_w, src_h = int(src_w * f), int(src_h * f)
            target = self._fisheye.target(src_w, src_h)
            self._ctx.render(
                flip_y=True,
                block_for_target_time=False,
                opengl_fbo={"w": src_w, "h": src_h, "fbo": target},
            )
            self._fisheye.draw(fbo, width, height, self._dewarp)
        except Exception:
            log.exception("Fisheye dewarp failed; showing the plain picture")
            self._dewarp.mode = ""
            self._dewarp_failed = True
            from OpenGL.GL import GL_FRAMEBUFFER, glBindFramebuffer

            glBindFramebuffer(GL_FRAMEBUFFER, fbo)
            return False
        return True

    def _on_video_size(self, name: str, value: Any) -> None:
        """dwidth/dheight observer, called on mpv's event thread.

        _render_dewarped needs the size on every frame, on the render
        thread, where reading the property waits on the mpv core: 3 ms a
        frame on average and up to 0.2 s at a time, measured with libmpv
        0.41 on a Raspberry Pi.
        """
        self._video_size[name] = int(value or 0)

    def set_dewarp(self, mode: str, lens: Lens | None = None, mount: str = MOUNT_CEILING) -> None:
        """Show this widget's video dewarped (ui.fisheye MODE_*, MOUNT_*),
        or as delivered with mode "". A change starts from the default view
        and drops any flat zoom, which the dewarp's own zoom replaces; the
        same settings again keep both, so a restarted stream keeps the view
        it had. Always as delivered once the dewarp failed here."""
        if self._dewarp_failed:
            mode = ""
        lens = lens or Lens()
        dewarp = self._dewarp
        if (mode, lens, mount) == (dewarp.mode, dewarp.lens, dewarp.mount):
            return
        dewarp.mode = mode
        dewarp.lens = lens
        dewarp.mount = mount
        self.reset_zoom()
        self.queue_render()

    def _mpv_update_cb(self) -> None:
        """Called by mpv from its thread when a new frame is available.

        Coalesces multiple updates into a single render to avoid flooding
        the GTK main loop when many streams are active (e.g. 3x3 grid).
        Skips scheduling when stopped (no URL) to prevent idle render loops.
        """
        if self._url and not self._render_pending:
            self._render_pending = True
            GLib.idle_add(self._do_queue_render)

    def _do_queue_render(self) -> bool:
        """Queue a render on the main thread. Returns False to remove idle source."""
        if self._initialized:
            self.queue_render()
        return False

    def _mpv_log(self, loglevel: str, component: str, message: str) -> None:
        """Handle mpv log messages.

        mpv routes libavcodec and libavformat through the same client log
        under components named ffmpeg/*, and maps AV_LOG_ERROR to its own
        "error". Those are routine on a live stream: a decoder started
        mid-GOP reports a missing PPS and a failed slice header for every
        frame until the next keyframe, which is what a WebSocket bridge
        reconnecting onto the same pipe hands it. Reporting that as an
        application error would call a healthy stream broken, several
        hundred lines at a time and once per slot, so the decoder's own
        complaints stay at debug and only mpv's own components speak up.
        """
        text = message.strip()
        if component.startswith("ffmpeg"):
            log.debug("mpv [%s] %s: %s", component, loglevel, text)
        elif loglevel in ("error", "fatal"):
            log.error("mpv [%s]: %s", component, text)
        elif loglevel == "warn":
            log.warning("mpv [%s]: %s", component, text)
        else:
            # Only reachable on a debug run, which is the only time libmpv
            # is asked for these. Dropping them instead would mean paying
            # to carry every message across the C boundary for nothing.
            log.debug("mpv [%s] %s: %s", component, loglevel, text)

    def _apply_playback_options(self) -> None:
        """Apply buffering and timing options for the current playback profile."""
        if not self._mpv:
            return
        if self._muxed_audio:
            # A live-piped Matroska stream from our own ffmpeg mux (see
            # ws_bridge.py's audio muxing): unlike the other two
            # profiles' analyzeduration=0, this needs an explicit small
            # cap: 0 on a live (never-ending) pipe left libavformat
            # waiting well past any reasonable duration for "enough"
            # data to feel confident, a real, reproducible multi-second
            # stall. A well-formed MKV header (ffmpeg has already
            # resolved codec/timing info by the time mpv sees it) needs
            # nowhere near that.
            target_seconds = _cache_target_seconds(_CACHE_SECONDS_MUXED_AUDIO, self._history_speed)
            self._mpv["demuxer-lavf-analyzeduration"] = 0.3
        elif self._low_latency:
            # A silent camera's raw H.264/H.265 WebSocket pipe (video
            # only, no container at all to probe). demuxer-lavf-probesize,
            # in the shared block below, drops to the smallest value
            # libmpv accepts whenever this stream also stays untimed
            # (Live, or History below _CACHE_HIGH_SPEED_ENTER), shaving
            # startup latency off Live, where it matters most.
            target_seconds = _cache_target_seconds(_CACHE_SECONDS_LOW_LATENCY, self._history_speed)
            self._mpv["demuxer-lavf-analyzeduration"] = 0
        else:
            # RTSP/local file: 0 is mpv's own default for
            # analyzeduration, not a deliberate RTSP-specific tuning;
            # restated explicitly since every profile states its own
            # value for every option here (see
            # test_every_profile_writes_the_same_options).
            target_seconds = _cache_target_seconds(_CACHE_SECONDS_DEFAULT, self._history_speed)
            self._mpv["demuxer-lavf-analyzeduration"] = 0

        # Shared by all three profiles. cache-secs is a deliberate cap
        # everywhere, not mpv's own (much larger) default, and the
        # cache is on for as long as one is asked for at all: always
        # for muxed_audio/default's own nonzero baseline, and for
        # low_latency once a fast History rewind's extra cache
        # (_high_speed_cache_seconds) gives it one.
        #
        # The timing options key off the profile, not off the cache.
        # Only low_latency reads a headerless H.264/H.265 pipe, and
        # only it can be played untimed off a fixed frame rate with
        # libmpv's minimum probesize; muxed_audio has a real MKV
        # header and RTSP a real container, both with per-frame timing
        # worth trusting however deep their buffer happens to be. A
        # cache size of 0, which the Settings page accepts for either,
        # must not turn them into raw-NAL streams. The untimed pairing
        # still tracks the cache within low_latency itself: once a fast
        # rewind buffers, there is real timing to keep.
        cache_enabled = target_seconds > 0
        timed = cache_enabled or not self._low_latency
        self._mpv["cache"] = "yes" if cache_enabled else "no"
        self._mpv["demuxer-max-bytes"] = (
            f"{_DEMUXER_MAX_BYTES_MIB:g}MiB" if cache_enabled else _DEMUXER_MAX_BYTES_UNCACHED
        )
        self._mpv["demuxer-max-back-bytes"] = f"{_DEMUXER_MAX_BACK_BYTES_MIB:g}MiB"
        self._mpv["demuxer-readahead-secs"] = target_seconds
        self._mpv["cache-secs"] = target_seconds
        self._mpv["correct-pts"] = timed
        self._mpv["untimed"] = not timed
        self._mpv["container-fps-override"] = 0 if timed else 25
        # 32 is libmpv's own minimum, for the fastest possible Live
        # startup on a raw pipe; 32768 is reliable for format/stream
        # detection everywhere else, and well below the probesize of
        # 5000000 the default profile used to inherit.
        self._mpv["demuxer-lavf-probesize"] = 32768 if timed else 32
        # Only the raw pipe needs telling: it has no container, so
        # libavformat is otherwise left scoring the first bytes against
        # every format it knows, on the 32 bytes above. A stream that
        # scores too low is refused outright rather than played badly
        # (see WebSocketBridge.video_format). The other two profiles
        # carry a real container and must stay on auto-detection, which
        # is what "" restores on a widget reused across protocols.
        self._mpv["demuxer-lavf-format"] = self._video_format if self._low_latency else ""

        # An av:// source is generated locally by libavdevice, not pulled
        # over a network: the offline placeholder. There is no delivery to
        # drift against, so nudging its speed corrects nothing and only
        # fills a debug log with ticks for a static card (measured: 306 of
        # them in six minutes, all setting 1.08x, on one placeholder).
        generated = self._url.startswith("av://")
        self._cache_control_enabled = self._mpv["cache-secs"] > 0 and not generated

    def _restart_cache_control(self) -> None:
        """(Re)start the cache-speed ticker for the profile just applied
        by _apply_playback_options, stopping any previous one first.
        Called on every play()/profile change so a widget reused across
        streams doesn't keep ticking against a target or speed state left
        over from what it played before."""
        self._stop_cache_control()
        if self._cache_control_enabled:
            self._cache_control_source = GLib.timeout_add(
                _CACHE_CONTROL_INTERVAL_MS, self._tick_cache_control
            )

    def _stop_cache_control(self) -> None:
        """Cancel the ticker and reset playback to normal speed."""
        if self._cache_control_source is not None:
            GLib.source_remove(self._cache_control_source)
            self._cache_control_source = None
        if self._mpv is not None:
            with contextlib.suppress(Exception):
                self._mpv.speed = 1.0
                self._mpv["osd-msg1"] = ""

    def _tick_cache_control(self) -> bool:
        """Nudge playback speed to keep the demuxer cache near its
        target depth rather than drifting: growing without bound when
        decode falls behind, or draining to nothing during a network
        stall, both of which would otherwise mean the app silently
        lagging further behind real time. See _cache_control_speed for
        the ramp itself.
        """
        if not self._mpv or not self._url:
            self._cache_control_source = None
            return False
        with contextlib.suppress(Exception):
            if self._mpv.pause:
                return True
        # Attribute access, not mpv[name]: mpv[name] reads options/*, not
        # this runtime property, so it would silently read back None
        # instead of the live cache duration.
        cache_seconds: float | None = None
        with contextlib.suppress(Exception):
            cache_seconds = getattr(self._mpv, "demuxer_cache_duration", None)
        if cache_seconds is None:
            return True
        # Dict access here, not attribute: the inverse of the gotcha
        # above. cache-secs is an option _apply_playback_options wrote,
        # not a runtime property, so mpv[name] reads back exactly what
        # was set instead of options/* silently returning nothing.
        target_seconds: float | None = None
        with contextlib.suppress(Exception):
            target_seconds = self._mpv["cache-secs"]
        if not target_seconds:
            return True

        mpv_playback_speed = _cache_control_speed(
            cache_seconds, target_seconds, live=self._live
        )
        with contextlib.suppress(Exception):
            self._mpv.speed = mpv_playback_speed
        # The number shown/logged is the true playback multiplier against
        # real time: DSM already delivers frames self._history_speed
        # times faster, and mpv_playback_speed is only cache control's own
        # correction on top of that, so self._mpv.speed alone would
        # understate it.
        effective_speed = mpv_playback_speed * self._history_speed
        with contextlib.suppress(Exception):
            # Cleared rather than left as-is when disabled, so toggling
            # the setting off clears an already-playing stream's OSD
            # within one tick instead of leaving stale text on screen.
            self._mpv["osd-msg1"] = (
                (
                    f"cache {cache_seconds:.2f}secs\n"
                    f"target {target_seconds:.2f}secs\n"
                    f"speed {effective_speed:.2f}X"
                )
                if _OSD_ENABLED
                else ""
            )

        self._cache_log_tick += 1
        due = self._cache_log_tick % _CACHE_LOG_INTERVAL_TICKS == 0
        if due:
            log.debug(
                "Cache control: url=%s cache=%.2fs target=%.2fs speed=%.2f",
                self._url,
                cache_seconds,
                target_seconds,
                effective_speed,
            )
        return True

    def play(
        self,
        url: str,
        *,
        low_latency: bool = False,
        muxed_audio: bool = False,
        start_offset: float = 0,
        history_speed: float = 1.0,
        video_format: str = "",
        live: bool = False,
    ) -> None:
        """Start playing a stream URL.

        When *low_latency* is True, disable caching and read-ahead so the
        stream plays in near real-time (used for WebSocket pipe bridges
        without a usable audio track, piping raw video only).

        When *muxed_audio* is True, use the buffering profile tuned for a
        live-piped Matroska stream instead (used for WebSocket pipe
        bridges that muxed real audio in via ffmpeg — see ws_bridge.py).
        Takes precedence over *low_latency* if both are set.

        *start_offset* seeks to that position (seconds) as the file loads,
        for playing a moment within a much longer recording file.

        *history_speed* is DSM's own History-speed multiplier already in
        effect for this stream (1.0 for Live, which has no speed concept);
        see set_history_speed for updating it on an already-playing
        History stream.

        *live* identifies a real-time camera feed explicitly. Cached live
        streams may catch up when buffered, but are never deliberately
        slowed below 1x to fill their cache. False preserves recording and
        History playback behavior, including their cache-speed correction.
        """
        MpvGLArea._reset_live_clock(self)
        self._url = url
        self._low_latency = low_latency
        self._muxed_audio = muxed_audio
        self._live = live
        self._start_offset = start_offset
        self._history_speed = history_speed
        self._video_format = video_format
        if self._initialized and self._mpv:
            try:
                self._apply_playback_options()
                self._restart_cache_control()
                self._mpv["start"] = _start_option(start_offset)
                self._mpv.play(url)
                MpvGLArea._observe_live_clock(self)
            except Exception:
                log.exception("Failed to play %s", url)
                # _restart_cache_control() above already started the
                # ticker; without this it would keep polling and nudging
                # speed against a URL that never actually started playing.
                self._stop_cache_control()

    def stop(self) -> None:
        """Stop playback."""
        MpvGLArea._reset_live_clock(self)
        self._url = ""
        self._stop_cache_control()
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.command("stop")
        if self._initialized:
            self.queue_render()

    def pause(self) -> None:
        """Toggle pause."""
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.pause = not self._mpv.pause
        self._live_backlog = _LiveBacklogWatch()

    def set_paused(self, paused: bool) -> None:
        """Explicitly pause or resume, unlike pause()'s toggle -- for a
        caller tracking its own paused state (Live View's timeline
        Pause/Play button) where a toggle could drift out of sync with
        it if this and some other trigger ever raced."""
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.pause = paused
        self._live_backlog = _LiveBacklogWatch()

    def _reset_live_clock(self) -> None:
        """Invalidate old asynchronous observations before a source change."""
        self._live_generation = getattr(self, "_live_generation", 0) + 1
        for name, observer in getattr(self, "_live_observers", []):
            with contextlib.suppress(Exception):
                self._mpv.unobserve_property(name, observer)
        self._live_observers = []
        self._live_observations = {}
        self._live_backlog = _LiveBacklogWatch()

    def _observe_live_clock(self) -> None:
        """Keep monitoring off GTK's synchronous mpv property-get path."""
        if not getattr(self, "_live", False) or not self._mpv:
            return
        if self._low_latency and not self._muxed_audio:
            return  # its synthetic 25fps clock is not camera time
        generation = self._live_generation
        for name in ("time-pos", "demuxer-cache-duration", "pause", "seeking"):
            def observed(prop: str, value: Any, token: int = generation) -> None:
                if token == self._live_generation:
                    self._live_observations[prop] = value
            try:
                self._mpv.observe_property(name, observed)
            except Exception:
                log.debug("Live player observation unavailable: %s", name)
            else:
                self._live_observers.append((name, observed))

    def live_backlog_reason(self, now: float | None = None) -> str | None:
        """Return one request for a full Live pipeline restart, if overdue.

        The LiveView polls this on the GTK thread; the property values
        below arrive asynchronously from mpv. No synchronous IPC per tile
        is introduced. Raw WebSocket age belongs to the bridge's source
        timestamps; History and ordinary files never enter this detector.
        """
        if not self._live or not self._url or not self._mpv:
            return None
        if self._low_latency and not self._muxed_audio:
            return None
        values = dict(self._live_observations)
        if values.get("pause") or values.get("seeking"):
            self._live_backlog = _LiveBacklogWatch()
            return None
        def number(value: Any) -> float | None:
            if isinstance(value, bool) or not isinstance(value, (float, int)):
                return None
            return float(value) if math.isfinite(value) else None
        target = _CACHE_SECONDS_MUXED_AUDIO if self._muxed_audio else _CACHE_SECONDS_DEFAULT
        return self._live_backlog.sample(
            time.monotonic() if now is None else now,
            number(values.get("time-pos")), number(values.get("demuxer-cache-duration")),
            target,
        )

    def set_grid_mode(self, enabled: bool) -> None:
        """Use inexpensive scaling for layout tiles; preserve enlarged quality.

        Safe before realization. The original values are read from this
        mpv instance, including user/environment overrides, only on entry
        and restored on exit. A no-op repeated call cannot overwrite that
        snapshot with the temporary grid settings. Decode policy, source
        quality, timing, and frame rate are not changed here.
        """
        self._grid_mode = bool(enabled)
        if not self._mpv:
            return
        if enabled:
            if self._grid_saved_options:
                return
            for name, value in _GRID_SCALING_OPTIONS.items():
                try:
                    original = self._mpv[name]
                    self._mpv[name] = value
                except Exception:
                    log.debug("Grid scaling option unavailable: %s", name)
                else:
                    self._grid_saved_options[name] = original
        else:
            saved = self._grid_saved_options
            self._grid_saved_options = {}
            for name, original in saved.items():
                try:
                    # libmpv reports an unset scaler as integer 0 in its
                    # node API (notably the default cscale), but its string
                    # setter rejects "0". Empty string restores that unset
                    # value, which again follows the main scale setting.
                    restore = (
                        "" if name in {"scale", "dscale", "cscale"} and original == 0
                        else original
                    )
                    self._mpv[name] = restore
                except Exception:
                    log.debug("Could not restore enlarged-view scaling: %s", name)

    def set_history_speed(self, value: float) -> None:
        """Update DSM's own History-speed multiplier for an already-
        playing stream (Live View's timeline speed dropdown, changed
        mid-session); see play()'s *history_speed* for the value set
        when a stream starts. Re-applies playback options, then
        restarts cache control against the new target.

        The cache options land on the running stream; the demuxer ones
        (demuxer-lavf-probesize/analyzeduration) are read when the
        demuxer is created, so if crossing _CACHE_HIGH_SPEED_ENTER
        changes them, the stream keeps the values it started with until
        the next play().
        """
        self._history_speed = value
        self._apply_playback_options()
        self._restart_cache_control()

    def _letterbox_fraction(self, width: int, height: int) -> tuple[float, float]:
        """Fraction of the widget's width/height the fitted (unzoomed)
        video actually occupies — 1.0 on an axis mpv doesn't letterbox to
        preserve the camera's aspect ratio, less than 1.0 on one it does.
        Falls back to (1.0, 1.0) if mpv hasn't reported a video size yet.
        """
        dwidth = getattr(self._mpv, "dwidth", None)
        dheight = getattr(self._mpv, "dheight", None)
        if not dwidth or not dheight or width <= 0 or height <= 0:
            return 1.0, 1.0
        fit_scale = min(width / dwidth, height / dheight)
        return (dwidth * fit_scale) / width, (dheight * fit_scale) / height

    def zoom_at(self, delta: float, cursor_x: float, cursor_y: float) -> None:
        """Zoom in/out by *delta* (mpv's own log2 video-zoom units — e.g.
        0.15 per scroll tick), keeping whatever's under the cursor
        (cursor_x, cursor_y — widget-relative pixel coordinates) fixed on
        screen — the standard "zoom to point" behavior of image viewers,
        maps, and graphics editors.

        mpv's video-pan-x/y are fractions of the *scaled* video size, not
        the widget, so a screen position maps to a video-space point via
        `screen = scale * (point + pan)`. Solving for the pan that keeps a
        screen position mapped to the same point across a scale change
        gives `pan' = pan + cursor_offset * (1/scale' - 1/scale)` — exact
        at every step either direction, and self-limiting at high zoom
        since 1/scale shrinks. cursor_offset is relative to the actual
        displayed video rect (see _letterbox_fraction), not the raw
        widget.
        """
        if not self._mpv or not self._initialized:
            return
        if self._dewarp.active:
            # The dewarp's own zoom (virtual PTZ field of view).
            self._dewarp.zoom(delta)
            self.queue_render()
            return

        width = self.get_width()
        height = self.get_height()
        if width <= 0 or height <= 0:
            return

        new_zoom = max(_ZOOM_MIN, min(_ZOOM_MAX, self._zoom + delta))

        if new_zoom <= _ZOOM_MIN:
            # Back at (or already at) 1:1 — pan is meaningless with no
            # extra zoomed content to shift around, and leaving it nonzero
            # would show the video pushed off into a corner instead of
            # filling the slot. Reset it here unconditionally, even if the
            # zoom level itself isn't changing — e.g. scrolling out
            # further while already at the floor after panning around at
            # 1:1, which would otherwise never reach this branch at all.
            if self._zoom == new_zoom and self._pan_x == 0.0 and self._pan_y == 0.0:
                return  # genuinely nothing to do
            self._zoom = new_zoom
            self._pan_x = 0.0
            self._pan_y = 0.0
        else:
            if new_zoom == self._zoom:
                return
            scale_old = 2**self._zoom
            scale_new = 2**new_zoom
            inv_delta = 1 / scale_new - 1 / scale_old
            letterbox_x, letterbox_y = self._letterbox_fraction(width, height)
            # Cursor position relative to widget center, normalized to
            # [-0.5, 0.5], then rescaled from widget-relative to
            # actual-video-rect-relative.
            nx = (cursor_x / width - 0.5) / letterbox_x
            ny = (cursor_y / height - 0.5) / letterbox_y
            self._pan_x = max(-_PAN_MAX, min(_PAN_MAX, self._pan_x + nx * inv_delta))
            self._pan_y = max(-_PAN_MAX, min(_PAN_MAX, self._pan_y + ny * inv_delta))
            self._zoom = new_zoom

        with contextlib.suppress(Exception):
            self._mpv.video_zoom = self._zoom
            self._mpv.video_pan_x = self._pan_x
            self._mpv.video_pan_y = self._pan_y

    def pan_by(self, dx_fraction: float, dy_fraction: float) -> None:
        """Pan by an incremental amount, as fractions of the widget's own
        size (same units zoom_at() takes a cursor offset in). Divided by
        the current scale and the letterbox fraction to convert to mpv's
        own pan units, so a drag tracks the cursor at a constant
        screen-space rate regardless of zoom level or the camera's aspect
        ratio. Allowed even at 1:1 zoom (scrolling back out already
        re-centers via reset-on-floor in zoom_at(), so panning off-center
        at 1:1 is always one scroll-out away from being undone)."""
        if not self._mpv or not self._initialized:
            return
        if self._dewarp.active:
            # Look around instead of moving the flat picture.
            self._dewarp.drag(dx_fraction, dy_fraction)
            self.queue_render()
            return
        scale = 2**self._zoom
        letterbox_x, letterbox_y = self._letterbox_fraction(self.get_width(), self.get_height())
        self._pan_x = max(
            -_PAN_MAX, min(_PAN_MAX, self._pan_x + dx_fraction / (scale * letterbox_x))
        )
        self._pan_y = max(
            -_PAN_MAX, min(_PAN_MAX, self._pan_y + dy_fraction / (scale * letterbox_y))
        )
        with contextlib.suppress(Exception):
            self._mpv.video_pan_x = self._pan_x
            self._mpv.video_pan_y = self._pan_y

    def reset_zoom(self) -> None:
        """Reset zoom/pan to the default 1:1 view, and a dewarp to its
        starting view."""
        self._dewarp.reset()
        self._zoom = 0.0
        self._pan_x = 0.0
        self._pan_y = 0.0
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.video_zoom = 0.0
                self._mpv.video_pan_x = 0.0
                self._mpv.video_pan_y = 0.0

    def set_volume(self, volume: int) -> None:
        """Set volume (0-100). Independent of mute — the level set here is
        what's restored on unmute, silent or not in the meantime. Stored
        whether or not mpv has been realized yet, same as set_mute()."""
        self._volume = volume
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.volume = volume

    @property
    def muted(self) -> bool:
        return self._muted

    def set_mute(self, muted: bool) -> None:
        """Mute/unmute without touching the volume level (mpv's own `mute`
        property, not zeroing volume) — stored regardless of whether mpv
        has been realized yet, same as _low_latency/_start_offset, and
        applied immediately if it has."""
        self._muted = muted
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.mute = muted

    def seek(self, seconds: float) -> None:
        """Seek relative to current position."""
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.seek(seconds)

    def seek_absolute(self, seconds: float) -> None:
        """Seek to absolute position."""
        if self._mpv:
            with contextlib.suppress(Exception):
                self._mpv.seek(seconds, reference="absolute")

    @property
    def duration(self) -> float | None:
        """Get duration of current media."""
        if self._mpv:
            try:
                result: float | None = self._mpv.duration
            except Exception:
                return None
            else:
                return result
        return None

    @property
    def time_pos(self) -> float | None:
        """Get current playback position."""
        if self._mpv:
            try:
                result: float | None = self._mpv.time_pos
            except Exception:
                return None
            else:
                return result
        return None

    @property
    def is_playing(self) -> bool:
        """Check if currently playing."""
        if self._mpv:
            try:
                return not self._mpv.pause and self._mpv.time_pos is not None
            except Exception:
                return False
        return False


# video-zoom units (mpv's own log2 scale) applied per scroll wheel tick.
_ZOOM_STEP = 0.15
# A drag shorter than this (pixels, either axis) is still treated as a
# plain click rather than a pan.
_DRAG_CLICK_THRESHOLD = 4


def attach_zoom_pan_controls(player: MpvGLArea, on_click: Callable[[], None] | None = None) -> None:
    """Wire up scroll-to-zoom (centered on the cursor) and click-and-drag
    panning on an MpvGLArea. Shared by Live View slots and the recording
    player dialog so both behave identically.

    If `on_click` is given, a drag shorter than _DRAG_CLICK_THRESHOLD is
    treated as a plain click and calls it with no arguments — used by Live
    View slots, which select the slot on click. Pass None (the default)
    where the video area has no click behavior to preserve, so every drag
    is treated as a pan from the first pixel.
    """
    # EventControllerScroll's "scroll" signal has no position, so a motion
    # controller tracks the last-known pointer position for it to use.
    pointer = {"x": 0.0, "y": 0.0}

    def on_motion(controller: Gtk.EventControllerMotion, x: float, y: float) -> None:
        pointer["x"] = x
        pointer["y"] = y

    motion = Gtk.EventControllerMotion()
    motion.connect("motion", on_motion)
    player.add_controller(motion)

    def on_scroll(controller: Gtk.EventControllerScroll, dx: float, dy: float) -> bool:
        # Scroll up (dy negative — "away from the user") zooms in, matching
        # the near-universal convention (maps, image viewers, etc.).
        player.zoom_at(-dy * _ZOOM_STEP, pointer["x"], pointer["y"])
        return True  # handled — don't let it bubble past the widget

    scroll = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL)
    scroll.connect("scroll", on_scroll)
    player.add_controller(scroll)

    # drag-update/drag-end report the offset cumulative from drag-begin,
    # not incrementally — pan_by() wants an increment, so track how much
    # of that cumulative offset has already been applied.
    drag_last = {"x": 0.0, "y": 0.0}

    def on_drag_begin(gesture: Gtk.GestureDrag, start_x: float, start_y: float) -> None:
        drag_last["x"] = 0.0
        drag_last["y"] = 0.0

    def on_drag_update(gesture: Gtk.GestureDrag, offset_x: float, offset_y: float) -> None:
        width = player.get_width()
        height = player.get_height()
        if width <= 0 or height <= 0:
            return
        dx = (offset_x - drag_last["x"]) / width
        dy = (offset_y - drag_last["y"]) / height
        drag_last["x"] = offset_x
        drag_last["y"] = offset_y
        # Content should follow the cursor (grab-and-drag feel): dragging
        # right/down reveals what was previously off to the left/top.
        player.pan_by(dx, dy)

    def on_drag_end(gesture: Gtk.GestureDrag, offset_x: float, offset_y: float) -> None:
        moved = abs(offset_x) >= _DRAG_CLICK_THRESHOLD or abs(offset_y) >= _DRAG_CLICK_THRESHOLD
        if not moved and on_click is not None:
            on_click()

    drag = Gtk.GestureDrag(button=1)
    drag.connect("drag-begin", on_drag_begin)
    drag.connect("drag-update", on_drag_update)
    drag.connect("drag-end", on_drag_end)
    player.add_controller(drag)
