# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Saved Synology layouts and individual camera sidebar."""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Mapping
from typing import TYPE_CHECKING, Any

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import GLib, Gtk, Pango  # type: ignore[import-untyped]

from surveillance.api.models import Camera, CameraStatus
from surveillance.config import save_config
from surveillance.services.camera import list_cameras
from surveillance.util.async_bridge import run_async

if TYPE_CHECKING:
    from surveillance.app import SurveillanceApp
    from surveillance.services.layout import ServerLayout
    from surveillance.ui.window import MainWindow

log = logging.getLogger(__name__)


def sidebar_width_for_window(requested: int, available: int) -> int:
    """Keep the remembered width usable after moving to a smaller display."""
    maximum = min(1600, max(180, available - 320)) if available > 0 else 1600
    return max(180, min(maximum, requested))


def layout_height_for_sidebar(requested: int, available: int) -> int:
    """Reserve a camera header and some scroll space below the layout list."""
    maximum = min(2400, max(64, available - 88)) if available > 0 else 2400
    return max(64, min(maximum, requested))


def label_paned_handle(paned: Gtk.Paned, tooltip: str, cursor: str) -> None:
    """Give the actual splitter a visible affordance and a useful tooltip."""
    child = paned.get_first_child()
    while child is not None:
        if child.get_css_name() == "separator":
            child.set_tooltip_text(tooltip)
            child.set_cursor_from_name(cursor)
        child = child.get_next_sibling()


class CameraSidebar(Gtk.Box):
    """Separate scrollable lists for saved layouts and individual cameras."""

    def __init__(self, window: MainWindow) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self.app: SurveillanceApp = window.get_application()  # type: ignore[assignment]
        self.cameras: list[Camera] = []
        self._poll_id: int = 0
        self._restoring_selection = False
        self._restoring_sizes = False
        self._logged_out = False
        # Set by the live view page so it can swap slots between their
        # real stream and the offline placeholder as camera status changes.
        self.on_cameras_updated: Callable[[list[Camera]], None] | None = None

        self.add_css_class("sidebar")
        self.set_size_request(180, -1)

        # Two independent lists, like Monitor Center.  Dragging the divider
        # gives either list more room without scrolling the other one away.
        self._lists_paned = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        self._lists_paned.add_css_class("sidebar-lists-split")
        self._lists_paned.set_vexpand(True)
        self._lists_paned.set_position(self.app.config.sidebar_layout_height)
        self._lists_paned.set_resize_start_child(False)
        self._lists_paned.set_shrink_start_child(True)
        self._lists_paned.set_resize_end_child(True)
        self._lists_paned.set_shrink_end_child(True)
        self._lists_paned.set_wide_handle(True)
        self.append(self._lists_paned)

        self._layouts_section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._layouts_section.set_size_request(-1, 64)
        self._lists_paned.set_start_child(self._layouts_section)
        self._server_layout_rows: dict[str, Gtk.ListBoxRow] = {}
        self._server_layout_order: list[str] = []
        self._selected_server_layout = ""

        layout_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        layout_header.set_margin_top(8)
        layout_header.set_margin_bottom(8)
        layout_header.set_margin_start(8)
        layout_header.set_margin_end(8)
        layout_label = Gtk.Label(label="Layouts")
        layout_label.add_css_class("title-4")
        layout_label.set_hexpand(True)
        layout_label.set_xalign(0)
        layout_header.append(layout_label)
        self._layout_spinner = Gtk.Spinner()
        self._layout_spinner.set_visible(False)
        layout_header.append(self._layout_spinner)
        self._layout_new = Gtk.Button(icon_name="list-add-symbolic")
        self._layout_new.set_tooltip_text("Create a new camera layout")
        self._layout_new.connect("clicked", lambda _: self.window.new_camera_layout())
        layout_header.append(self._layout_new)
        self._layout_refresh = Gtk.Button(icon_name="view-refresh-symbolic")
        self._layout_refresh.set_tooltip_text("Refresh saved Synology layouts")
        self._layout_refresh.connect("clicked", lambda _: self.window.refresh_server_layouts())
        layout_header.append(self._layout_refresh)
        self._layouts_section.append(layout_header)
        self._layout_notice = Gtk.Label()
        self._layout_notice.set_wrap(True)
        self._layout_notice.set_max_width_chars(26)
        self._layout_notice.set_margin_start(8)
        self._layout_notice.set_margin_end(8)
        self._layout_notice.set_margin_bottom(6)
        self._layout_notice.add_css_class("error")
        self._layout_notice.set_visible(False)
        self._layouts_section.append(self._layout_notice)

        layout_scroll = Gtk.ScrolledWindow()
        layout_scroll.set_vexpand(True)
        layout_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.layout_listbox = Gtk.ListBox()
        self.layout_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.layout_listbox.set_activate_on_single_click(True)
        self.layout_listbox.connect("row-activated", self._on_layout_activated)
        self._layout_status = Gtk.Label(label="Saved layouts appear after connecting")
        self._layout_status.set_wrap(True)
        self._layout_status.set_max_width_chars(26)
        self._layout_status.set_margin_top(16)
        self._layout_status.set_margin_bottom(16)
        self._layout_status.set_margin_start(12)
        self._layout_status.set_margin_end(12)
        self._layout_status.add_css_class("dim-label")
        self.layout_listbox.set_placeholder(self._layout_status)
        layout_scroll.set_child(self.layout_listbox)
        self._layouts_section.append(layout_scroll)

        camera_section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        camera_section.set_size_request(-1, 64)
        self._lists_paned.set_end_child(camera_section)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        header.set_margin_top(8)
        header.set_margin_bottom(8)
        header.set_margin_start(8)
        header.set_margin_end(8)
        label = Gtk.Label(label="Cameras")
        label.add_css_class("title-4")
        label.set_hexpand(True)
        label.set_xalign(0)
        header.append(label)

        refresh_btn = Gtk.Button()
        refresh_btn.set_icon_name("view-refresh-symbolic")
        refresh_btn.set_tooltip_text("Refresh cameras")
        refresh_btn.connect("clicked", lambda _: self.refresh())
        header.append(refresh_btn)
        self._list_header = header
        camera_section.append(header)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.connect("row-selected", self._on_row_selected)
        self.listbox.connect("row-activated", self._on_row_activated)
        scroll.set_child(self.listbox)
        camera_section.append(scroll)

        # View switcher at the bottom
        nav_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        nav_box.set_margin_top(8)
        nav_box.set_margin_bottom(8)
        nav_box.set_margin_start(8)
        nav_box.set_margin_end(8)

        self._nav_buttons: dict[str, Gtk.ToggleButton] = {}
        first_btn: Gtk.ToggleButton | None = None
        for icon, label_text, page_name in [
            ("camera-video-symbolic", "Live View", "live"),
            ("media-playback-start-symbolic", "Recordings", "recordings"),
            ("camera-photo-symbolic", "Snapshots", "snapshots"),
            ("dialog-warning-symbolic", "Events", "events"),
            ("surveillance-time-lapse-symbolic", "Time Lapse", "timelapse"),
            ("dialog-password-symbolic", "Licenses", "licenses"),
            ("preferences-system-symbolic", "Settings", "settings"),
            ("help-about-symbolic", "About", "about"),
        ]:
            # A shared toggle group makes these behave like radio buttons —
            # exactly one active at a time — using the system theme's own
            # toggle-button highlight, rather than a custom CSS "selected"
            # style.
            btn = Gtk.ToggleButton()
            btn.add_css_class("sidebar-nav")
            if first_btn is None:
                first_btn = btn
            else:
                btn.set_group(first_btn)
            btn_content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            btn_icon = Gtk.Image.new_from_icon_name(icon)
            btn_label = Gtk.Label(label=label_text)
            btn_label.set_xalign(0)
            btn_label.set_hexpand(True)
            btn_content.append(btn_icon)
            btn_content.append(btn_label)
            if page_name == "about":
                # Update-available indicator — cleared once About is
                # actually visited (see AboutView.on_page_shown).
                self._about_update_dot = Gtk.Box()
                self._about_update_dot.add_css_class("status-dot")
                self._about_update_dot.set_size_request(10, 10)
                self._about_update_dot.set_valign(Gtk.Align.CENTER)
                self._about_update_dot.set_visible(False)
                btn_content.append(self._about_update_dot)
            btn.set_child(btn_content)
            btn.connect("toggled", self._on_nav_toggled, page_name)
            nav_box.append(btn)
            self._nav_buttons[page_name] = btn

        self.append(Gtk.Separator())
        # The eight navigation rows used to consume much of a 720p sidebar.
        # Collapsing them leaves nearly all its height for the two lists.
        self._navigation_expander = Gtk.Expander(label="Views and settings")
        self._navigation_expander.set_tooltip_text(
            "Collapse to give the Layouts and Cameras lists more room"
        )
        self._navigation_expander.set_margin_start(8)
        self._navigation_expander.set_margin_end(8)
        self._navigation_expander.set_margin_top(6)
        self._navigation_expander.set_margin_bottom(6)
        self._navigation_expander.set_expanded(self.app.config.sidebar_navigation_expanded)
        self._navigation_expander.set_child(nav_box)
        self.append(self._navigation_expander)
        self._navigation_expander.connect("notify::expanded", self._on_navigation_expanded)
        self._lists_paned.connect("notify::position", self._on_list_position_changed)
        self._lists_paned.connect("map", lambda *_: GLib.idle_add(self._restore_list_position))
        self._lists_paned.connect(
            "notify::max-position", lambda *_: GLib.idle_add(self._restore_list_position)
        )
        label_paned_handle(
            self._lists_paned, "Drag up or down to resize Layouts and Cameras", "row-resize"
        )

    def _restore_list_position(self) -> bool:
        if self._logged_out or not self._lists_paned.get_mapped():
            return False
        height = self._lists_paned.get_height()
        if height <= 0:
            return False
        self._restoring_sizes = True
        try:
            self._lists_paned.set_position(layout_height_for_sidebar(
                self.app.config.sidebar_layout_height, height
            ))
        finally:
            self._restoring_sizes = False
        return False

    def _on_list_position_changed(self, paned: Gtk.Paned, *_args: Any) -> None:
        if self._restoring_sizes or self._logged_out or not paned.get_mapped():
            return
        position = layout_height_for_sidebar(paned.get_position(), paned.get_height())
        if position != paned.get_position():
            self._restoring_sizes = True
            try:
                paned.set_position(position)
            finally:
                self._restoring_sizes = False
        if self.app.config.sidebar_layout_height != position:
            self.app.config.sidebar_layout_height = position
            save_config(self.app.config)

    def _on_navigation_expanded(self, expander: Gtk.Expander, *_args: Any) -> None:
        if self._restoring_sizes or self._logged_out:
            return
        self.app.config.sidebar_navigation_expanded = expander.get_expanded()
        save_config(self.app.config)

    def set_server_layouts(
        self,
        layouts: Iterable[ServerLayout] | Mapping[str, ServerLayout],
        selected_id: str = "",
    ) -> None:
        """Replace the saved-layout list without launching a selection.

        The parent owns fetching and applying layouts.  This method is also
        used after a layout was applied, so it must not trigger another fetch
        or turn a programmatic selection into a second activation.
        """
        items = list(layouts.values() if isinstance(layouts, Mapping) else layouts)
        selected = str(selected_id) if selected_id is not None else ""
        self._selected_server_layout = selected
        self._layout_notice.set_visible(False)
        self._layout_spinner.stop()
        self._layout_spinner.set_visible(False)
        self._layout_refresh.set_sensitive(True)
        self._layout_refresh.set_tooltip_text("Refresh saved Synology layouts")
        self._layout_status.set_text("No saved layouts available for this account")
        order = [str(layout.id) for layout in items]
        if order == self._server_layout_order and all(
            self._server_layout_rows[str(layout.id)].server_layout == layout for layout in items
        ):
            # Applying a layout updates only the highlight.  Rebuilding all
            # rows here would jump a long layout list back to the top.
            self.layout_listbox.select_row(self._server_layout_rows.get(selected))
            self._refresh_layout_tooltips()
            return
        self._server_layout_order = order
        self._server_layout_rows.clear()
        while (row := self.layout_listbox.get_row_at_index(0)) is not None:
            self.layout_listbox.remove(row)
        for layout in items:
            row = Gtk.ListBoxRow()
            row.add_css_class("layout-row")
            row.layout_id = str(layout.id)
            row.server_layout = layout
            content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            content.set_margin_top(6)
            content.set_margin_bottom(6)
            content.set_margin_start(8)
            content.set_margin_end(8)
            icon = Gtk.Image.new_from_icon_name("view-grid-symbolic")
            content.append(icon)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            text.set_hexpand(True)
            name = Gtk.Label(label=layout.name)
            name.set_xalign(0)
            name.set_ellipsize(Pango.EllipsizeMode.END)
            name.set_max_width_chars(24)
            name.add_css_class("camera-label")
            text.append(name)
            identifiers = self._layout_camera_ids(layout)
            if layout.kind == "sequence":
                description = "Sequential layout"
            elif layout.kind == "alert":
                description = "Alert layout"
            else:
                count = len(identifiers)
                description = f"{count} camera{'s' if count != 1 else ''}"
                if layout.kind == "local":
                    description = f"This 10ZiG · {description}"
            detail = Gtk.Label(label=description)
            detail.set_xalign(0)
            detail.add_css_class("dim-label")
            detail.add_css_class("caption")
            text.append(detail)
            content.append(text)
            row.set_child(content)
            self.layout_listbox.append(row)
            self._server_layout_rows[str(layout.id)] = row
            if str(layout.id) == selected:
                self.layout_listbox.select_row(row)
        self._refresh_layout_tooltips()

    @staticmethod
    def _layout_camera_ids(layout: ServerLayout) -> list[int]:
        identifiers: list[int] = []
        for tile in layout.tiles:
            for identifier in tile.camera_ids or (tile.camera_id,):
                if identifier is not None and identifier not in identifiers:
                    identifiers.append(identifier)
        return identifiers

    def _refresh_layout_tooltips(self) -> None:
        camera_names = {camera.id: camera.name for camera in self.cameras}
        for row in self._server_layout_rows.values():
            layout = row.server_layout
            names = [camera_names.get(identifier, f"Camera {identifier}")
                     for identifier in self._layout_camera_ids(layout)]
            description = layout.name
            if layout.kind == "local":
                description += "\nSaved on this 10ZiG only; not saved on the Synology NAS."
            if names:
                description += "\n" + "\n".join(names)
            if layout.warnings:
                description += "\n" + "\n".join(layout.warnings)
            row.set_tooltip_text(description)

    def set_layout_loading(self, status: bool | str) -> None:
        """Show loading, empty-list, or permission/fetch error feedback."""
        loading = status is True
        self._layout_notice.set_visible(isinstance(status, str) and bool(status))
        if isinstance(status, str):
            self._layout_notice.set_text(status)
        self._layout_spinner.set_visible(loading)
        self._layout_refresh.set_sensitive(not loading)
        if loading:
            self._layout_spinner.start()
            self._layout_status.set_text("Loading saved layouts…")
        else:
            self._layout_spinner.stop()
            text = str(status) if isinstance(status, str) and status else (
                "No saved layouts available for this account"
            )
            self._layout_status.set_text(text)
        # Keep cached layouts usable if a refresh fails; show the failure
        # above the list instead of silently replacing it with an empty list.
        self._layout_refresh.set_tooltip_text(
            str(status) if isinstance(status, str) and status
            else "Refresh saved Synology layouts"
        )

    def _on_layout_activated(self, _listbox: Gtk.ListBox, row: Gtk.ListBoxRow) -> None:
        if self.app.api is not None:
            self.window.select_server_layout(row.layout_id)

    def set_logged_out(self, logged_out: bool) -> None:
        """Leave only what works without a session.

        The camera list and every nav row but Settings need one, so they
        go away until login; Settings is this client's own tunables and
        is available without any connection. Hidden rather than just
        disabled, matching how the header bar treats its own
        session-only controls. The empty list keeps its space so the
        Settings row stays where it always sits, at the bottom.
        """
        self._logged_out = logged_out
        self._list_header.set_visible(not logged_out)
        if hasattr(self, "_layouts_section"):
            self._layouts_section.set_visible(not logged_out)
        if hasattr(self, "_navigation_expander"):
            self._restoring_sizes = True
            try:
                self._navigation_expander.set_expanded(
                    True if logged_out else self.app.config.sidebar_navigation_expanded
                )
            finally:
                self._restoring_sizes = False
            if not logged_out:
                GLib.idle_add(self._restore_list_position)
        for page_name, btn in self._nav_buttons.items():
            btn.set_visible(not logged_out or page_name == "settings")
            if logged_out:
                # The stack now shows the login prompt, not the page the
                # highlight is on. Left active, Settings could not be
                # opened from here: GTK ignores a click on the active
                # button of a toggle group, so nothing would toggle.
                # Turning it off emits a toggled that _on_nav_toggled
                # ignores.
                btn.set_active(False)

    def set_update_available(self, available: bool) -> None:
        """Show/hide the update dot on the About nav row."""
        self._about_update_dot.set_visible(available)

    def refresh(self, on_complete: Any = None) -> None:
        """Refresh the camera list."""
        api = self.app.api
        if not api:
            return

        def _on_loaded(cameras: list[Camera]) -> None:
            if self.app.api is not api:
                # Logged out, or into another NAS, while this was out:
                # the list would refill a cleared sidebar, and seed the
                # pages with cameras from the wrong NAS.
                return
            self._update_camera_list(cameras)
            if self.on_cameras_updated:
                self.on_cameras_updated(cameras)
            if on_complete:
                on_complete(cameras)

        run_async(
            list_cameras(api),
            callback=_on_loaded,
            error_callback=lambda e: log.error("Failed to refresh cameras: %s", e),
        )

    def clear(self) -> None:
        """Drop the camera list on disconnect.

        on_connected() builds the content pages before refresh() has
        returned, and every page seeds its camera filter from this list, so
        one left over from the previous NAS would seed them with cameras
        that do not exist on the new one.
        """
        self.cameras = []
        if hasattr(self, "layout_listbox"):
            self.set_server_layouts([], "")
            self._layout_status.set_text("Saved layouts appear after connecting")
        while True:
            row = self.listbox.get_row_at_index(0)
            if row is None:
                break
            self.listbox.remove(row)

    def _update_camera_list(self, cameras: list[Camera]) -> None:
        cameras = sorted(cameras, key=lambda c: (c.name.casefold(), c.id))

        # Skip rebuild if camera list is unchanged
        if len(cameras) == len(self.cameras) and all(
            a.id == b.id and a.status == b.status and a.name == b.name
            for a, b in zip(cameras, self.cameras, strict=True)
        ):
            return

        # Remember selected camera before rebuilding
        selected_row = self.listbox.get_selected_row()
        selected_id: int | None = None
        if selected_row is not None:
            selected_id = selected_row.camera.id  # type: ignore[attr-defined]

        self.cameras = cameras
        if hasattr(self, "_server_layout_rows"):
            self._refresh_layout_tooltips()

        # Remove old rows
        while True:
            row = self.listbox.get_row_at_index(0)
            if row is None:
                break
            self.listbox.remove(row)

        # Add camera rows and restore selection. Rebuilding always creates
        # fresh row objects, so restoring the highlight still fires
        # "row-selected" like a real click would — guarded here so a status
        # change elsewhere in the list can't silently reassign/zoom to
        # whatever camera the user last happened to click.
        self._restoring_selection = True
        try:
            for cam in cameras:
                row = self._create_camera_row(cam)
                self.listbox.append(row)
                if cam.id == selected_id:
                    self.listbox.select_row(row)
        finally:
            self._restoring_selection = False

        # Action row at the end: clears the currently selected grid slot
        self.listbox.append(self._create_clear_slot_row())

    def _create_camera_row(self, cam: Camera) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.add_css_class("camera-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_top(2)
        box.set_margin_bottom(2)
        box.set_margin_start(8)
        box.set_margin_end(8)

        # Status indicator
        status_icon = Gtk.Image()
        if cam.status == CameraStatus.ENABLED:
            status_icon.set_from_icon_name("object-select-symbolic")
            status_icon.add_css_class("camera-status-online")
        elif cam.status == CameraStatus.DISCONNECTED:
            status_icon.set_from_icon_name("network-offline-symbolic")
            status_icon.add_css_class("camera-status-offline")
        else:
            status_icon.set_from_icon_name("action-unavailable-symbolic")
            status_icon.add_css_class("camera-status-offline")
        box.append(status_icon)

        # Camera info
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        name_label = Gtk.Label(label=cam.name)
        name_label.set_xalign(0)
        name_label.set_ellipsize(Pango.EllipsizeMode.END)
        name_label.set_max_width_chars(30)
        name_label.set_tooltip_text(cam.name)
        name_label.add_css_class("camera-label")
        info_box.append(name_label)

        detail = f"{cam.vendor} {cam.model}" if cam.vendor else cam.model
        if detail:
            detail_label = Gtk.Label(label=detail)
            detail_label.set_xalign(0)
            detail_label.set_ellipsize(Pango.EllipsizeMode.END)
            detail_label.set_max_width_chars(30)
            detail_label.add_css_class("dim-label")
            detail_label.add_css_class("caption")
            info_box.append(detail_label)

        info_box.set_hexpand(True)
        box.append(info_box)

        # PTZ badge
        if cam.is_ptz:
            ptz_label = Gtk.Label(label="PTZ")
            ptz_label.add_css_class("caption")
            box.append(ptz_label)

        # Right-click gesture for context menu
        click = Gtk.GestureClick(button=3)
        click.connect("pressed", self._on_row_right_click, cam)
        row.add_controller(click)

        row.set_child(box)
        row.camera = cam  # type: ignore[attr-defined]
        return row

    def _on_row_right_click(
        self,
        gesture: Gtk.GestureClick,
        n_press: int,
        x: float,
        y: float,
        cam: Camera,
    ) -> None:
        """Show the camera settings dialog on right-click.

        Clears the row's pressed (CSS ":active") state by hand first:
        opening the modal dialog from this "pressed" handler was seen to
        leave the row highlighted for good, as though the matching
        button-release never reached it.

        That treats the symptom. GTK counts this state rather than storing
        a flag (GtkWidgetPrivate.n_active, driven by
        gtk_widget_set_active_state), and unset_state_flags leaves the
        count alone, so it stays one above zero and a later press/release
        pair on the same row can end with the row lit again. If that turns
        up, the fix belongs at the cause instead. Upstream reworked the
        same accounting for GTK issue 7930
        (https://gitlab.gnome.org/GNOME/gtk/-/issues/7930), released in
        4.21.6.
        """
        widget = gesture.get_widget()
        if widget is not None:
            widget.unset_state_flags(Gtk.StateFlags.ACTIVE)
        from surveillance.ui.camera_settings import CameraSettingsDialog

        CameraSettingsDialog(self.window, cam).present()

    def _create_clear_slot_row(self) -> Gtk.ListBoxRow:
        """Action row that clears whichever grid slot is currently selected.

        Not selectable: it is activated by a click or Enter, so moving the
        keyboard cursor over it cannot clear a slot, and activating it leaves
        the selected camera alone.
        """
        row = Gtk.ListBoxRow()
        row.add_css_class("camera-row")
        row.set_selectable(False)
        row.camera = None  # type: ignore[attr-defined]

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_top(2)
        box.set_margin_bottom(2)
        box.set_margin_start(8)
        box.set_margin_end(8)

        icon = Gtk.Image.new_from_icon_name("edit-clear-symbolic")
        box.append(icon)

        label = Gtk.Label(label="Empty Slot")
        label.set_xalign(0)
        label.add_css_class("dim-label")
        label.set_hexpand(True)
        box.append(label)

        row.set_child(box)
        row.set_tooltip_text("Select a grid slot, then click here to clear it")
        return row

    def _on_row_selected(self, listbox: Gtk.ListBox, row: Gtk.ListBoxRow | None) -> None:
        if row is None or self._restoring_selection:
            return
        cam = row.camera  # type: ignore[attr-defined]
        self.window.on_camera_selected(cam)

    def _on_row_activated(self, listbox: Gtk.ListBox, row: Gtk.ListBoxRow) -> None:
        if row.camera is None:  # type: ignore[attr-defined]
            self.window.clear_selected_slot()

    def _on_nav_toggled(self, btn: Gtk.ToggleButton, page_name: str) -> None:
        if not btn.get_active():
            return
        self.window.show_page(page_name)

    def set_active_page(self, page_name: str) -> None:
        """Highlight *page_name*'s nav button without re-triggering show_page().

        Used both at startup (restoring the persisted last-active page) and
        from show_page() itself, so the highlight always matches the stack's
        actual visible child regardless of how it got there.
        """
        btn = self._nav_buttons.get(page_name)
        if btn is None or btn.get_active():
            return
        btn.handler_block_by_func(self._on_nav_toggled)
        btn.set_active(True)
        btn.handler_unblock_by_func(self._on_nav_toggled)

    def start_polling(self) -> None:
        """Start periodic camera status polling."""
        self.stop_polling()
        interval = self.app.config.poll_interval_cameras
        self._poll_id = GLib.timeout_add_seconds(interval, self._poll_tick)

    def stop_polling(self) -> None:
        """Stop polling."""
        if self._poll_id:
            GLib.source_remove(self._poll_id)
            self._poll_id = 0

    def _poll_tick(self) -> bool:
        self.refresh()
        return True  # continue polling
