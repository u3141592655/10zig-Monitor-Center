# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Main application window."""

from __future__ import annotations

import logging
from importlib import import_module
import time
from typing import TYPE_CHECKING

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import Gio, GLib, Gtk  # type: ignore[import-untyped]

from surveillance.api.models import Camera
from surveillance.ui.camera_presentation import CameraPresentationMixin
from surveillance.ui.headerbar import AppHeaderBar
from surveillance.ui.layouts import valid_layout
from surveillance.ui.sidebar import CameraSidebar, label_paned_handle, sidebar_width_for_window

if TYPE_CHECKING:
    from surveillance.app import SurveillanceApp
    from surveillance.services.transactions import Transaction
    from surveillance.ui.liveview import LiveView

log = logging.getLogger(__name__)

# Auxiliary views do real work in their constructors (including NAS queries
# and recording thumbnails). Keep their imports and work off the login/live
# path; a page is created on its first visit, then retained for this session.
_CONTENT_PAGES = {
    "live": ("liveview", "LiveView"),
    "recordings": ("recordings", "RecordingsView"),
    "snapshots": ("snapshots", "SnapshotsView"),
    "events": ("events", "EventsView"),
    "timelapse": ("timelapse", "TimeLapseView"),
    "licenses": ("licenses", "LicensesView"),
    "about": ("about", "AboutView"),
}


class MainWindow(CameraPresentationMixin, Gtk.ApplicationWindow):
    """Main application window with sidebar and content stack."""

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)
        self.app: SurveillanceApp = self.get_application()  # type: ignore[assignment]
        self.set_title("Surveillance Station")
        self.set_default_size(1280, 720)
        self._init_camera_presentation()

        # Header bar
        self._setup_actions()
        self.headerbar = AppHeaderBar(self)
        self.set_titlebar(self.headerbar)

        # Main layout: sidebar + content with draggable divider
        self.paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.paned.add_css_class("sidebar-width-split")
        self.paned.set_wide_handle(True)
        self._restoring_sidebar_width = False
        self.set_child(self.paned)

        # Sidebar
        self.sidebar = CameraSidebar(self)
        self.sidebar.set_visible(self.app.config.sidebar_visible)
        self.paned.set_start_child(self.sidebar)
        self.paned.set_resize_start_child(False)
        self.paned.set_shrink_start_child(False)

        # Content stack
        self.stack = Gtk.Stack()
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.paned.set_end_child(self.stack)
        # A large video grid's natural width must not pin the sidebar
        # divider in place. The content can scale to its allocated space.
        self.paned.set_shrink_end_child(True)
        self.paned.set_position(self.app.config.sidebar_width)
        self.paned.connect("notify::position", self._on_sidebar_width_changed)
        self.sidebar.connect("map", lambda *_: GLib.idle_add(self._restore_sidebar_width))
        self.paned.connect(
            "notify::max-position", lambda *_: GLib.idle_add(self._restore_sidebar_width)
        )
        label_paned_handle(
            self.paned, "Drag left or right to resize the Layouts and Cameras sidebar", "col-resize"
        )
        self._build_camera_presentation()

        # Shown instead of the whole page stack while logged out (see
        # _show_logged_out_state). Simpler than a separate placeholder
        # per page, since none of them have anything to show without a
        # connection anyway, and the sidebar drops their nav rows while
        # logged out so none of them can be reached either.
        logged_out_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        logged_out_box.set_halign(Gtk.Align.CENTER)
        logged_out_box.set_valign(Gtk.Align.CENTER)
        logged_out_icon = Gtk.Image.new_from_icon_name("camera-video-symbolic")
        logged_out_icon.set_pixel_size(64)
        logged_out_icon.add_css_class("dim-label")
        logged_out_box.append(logged_out_icon)
        logged_out_label = Gtk.Label(label="Login to your DSM Server to use the application")
        logged_out_label.add_css_class("title-1")
        logged_out_label.add_css_class("dim-label")
        logged_out_box.append(logged_out_label)
        self.stack.add_named(logged_out_box, "logged_out")

        # Settings remains available while logged out, but its many controls
        # are constructed only if opened. Persisted values have already been
        # applied by the application before any player or login can use them.
        self._pending_live_restore = None
        self._startup_restore_api = None
        self._startup_cameras: list[Camera] | None = None

        self._homemode_poll_id: int = 0
        self._alerts_poll_id: int = 0
        self._transactions_poll_id: int = 0

        # Window-wide mouse activity, used to keep the Live View timeline's
        # focus-slot frame lit (see LiveView.register_timeline_activity).
        # Capture phase so it sees every motion first, regardless of which
        # child widget the event is actually over or does with it.
        activity = Gtk.EventControllerMotion()
        activity.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        activity.connect("motion", self._on_window_motion)
        self.add_controller(activity)

        # Exit handlers. Both vfunc override and signal connection
        # for maximum compatibility across PyGObject versions.
        self.connect("close-request", lambda *_: self._force_exit("signal"))

        # Show login if not connected
        if self.app.api:
            self.on_connected()
        else:
            self._show_logged_out_state()
            self._schedule_login()

    def _setup_actions(self) -> None:
        """Register the window actions driven by the header bar menus."""
        self._grid_layout_action = Gio.SimpleAction.new_stateful(
            "grid-layout",
            GLib.VariantType.new("s"),
            GLib.Variant.new_string(valid_layout(self.app.config.grid_layout)),
        )
        self._grid_layout_action.connect("change-state", self._on_grid_layout_action)
        self.add_action(self._grid_layout_action)

        clear_action = Gio.SimpleAction.new("clear-layout", None)
        clear_action.connect("activate", self._on_clear_layout_action)
        self.add_action(clear_action)

    def _on_window_motion(
        self, _controller: Gtk.EventControllerMotion, _x: float, _y: float
    ) -> None:
        self.show_fullscreen_controls()
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "register_timeline_activity"):
            live_view.register_timeline_activity()

    def _on_grid_layout_action(self, action: Gio.SimpleAction, value: GLib.Variant) -> None:
        self.select_local_layout()
        action.set_state(value)
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "set_layout"):
            live_view.set_layout(value.get_string())

    def _on_clear_layout_action(self, action: Gio.SimpleAction, param: None) -> None:
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "confirm_clear_layout"):
            live_view.confirm_clear_layout()

    def sync_grid_layout(self, layout: str) -> None:
        """Reflect a layout change made by the live view itself in the menu."""
        self.select_local_layout()
        self._grid_layout_action.set_state(GLib.Variant.new_string(layout))

    def do_close_request(self) -> bool:
        """Vfunc override for close-request."""
        self._force_exit("vfunc")
        return True

    def _force_exit(self, source: str) -> bool:
        log.warning("exit requested via %s", source)
        self.app.exit_now()

    def _schedule_login(self) -> None:
        """Show login dialog after window is shown."""
        GLib.idle_add(self.show_login)

    def show_login(self) -> None:
        """Show the login dialog."""
        from surveillance.ui.login import LoginDialog

        dialog = LoginDialog(self.app, self)
        dialog.present()

    def _show_logged_out_state(self) -> None:
        """Drop every control that needs a connection to do anything and
        show a single login prompt in place of the whole page stack.
        There is nothing any of them has to show without one anyway, so
        gating each individually would just be more to keep in sync for
        no real benefit. The sidebar stays, trimmed to its Settings row
        (see CameraSidebar.set_logged_out): that page is this client's
        own tunables and works with no NAS behind it, and the sidebar is
        the only way to reach it. Safe to call before a first login too,
        not just on logout: set_connected also covers the header
        controls' initial hidden state, which AppHeaderBar.__init__
        itself only half-does (sensitivity, not visibility). Undone by
        _setup_content_pages() on login.
        """
        self.reset_camera_presentation()
        self.headerbar.set_connected(False)
        self.sidebar.set_logged_out(True)
        self.sidebar.set_visible(self.app.config.sidebar_visible)
        self.stack.set_visible_child_name("logged_out")
        self.headerbar.set_page("logged_out")

    def on_connected(self) -> None:
        """Called after successful login."""
        self.headerbar.set_connected(True)
        self._setup_content_pages()
        self._startup_restore_api = self.app.api
        self._startup_cameras = None
        self._layout_inventory_ready = False
        self._pending_live_restore = self._finish_live_session_restore
        # Independent reads share the authenticated connection pool. Start
        # both now; do not open a temporary built-in grid while waiting for
        # the selected NAS layout, only to replace all its streams again.
        self.refresh_server_layouts()
        self.sidebar.refresh()
        self.sidebar.start_polling()
        self._start_polling()
        self._check_for_update()

    def _check_for_update(self) -> None:
        """Check GitHub once per launch for a release newer than this build.

        Best-effort only: get_latest_release() never raises, so no
        error_callback is needed here.
        """
        from surveillance import __version__
        # Stock upstream releases do not contain this edition's layout and
        # credential changes. Updates are installed using its own package.
        if "+peakos." in __version__:
            return
        from surveillance.services.update_check import get_latest_release, is_newer
        from surveillance.util.async_bridge import run_async

        async def _check() -> tuple[str, str] | None:
            release = await get_latest_release()
            if release and is_newer(release[0], __version__):
                return release
            return None

        run_async(_check(), callback=self._on_update_check_result)

    def _on_update_check_result(self, release: tuple[str, str] | None) -> None:
        if not release:
            return
        self.app.latest_release = release
        tag, _url = release
        show_dot = tag != self.app.config.dismissed_update_version
        self.sidebar.set_update_available(show_dot)
        self.headerbar.set_update_available(show_dot)

        # This check runs async and can finish after About was already
        # shown (e.g. it's the restored last_page at startup) — that
        # on_page_shown() call ran with no release known yet, so its
        # banner needs a nudge now rather than waiting for the next visit.
        if self.stack.get_visible_child_name() == "about":
            about_page = self.stack.get_child_by_name("about")
            if about_page and hasattr(about_page, "on_page_shown"):
                about_page.on_page_shown()

    def _restore_live_session(self, cameras: list[Camera]) -> None:
        """Restore live view camera assignments and refresh other pages' camera filters.

        Runs once the sidebar's camera list has actually loaded. Recordings,
        Snapshots, and Events build their camera filter dropdown from that
        same list at construction time, which happens before this — so
        without this, their filter would only ever show whatever camera
        happened to already be loaded (usually none) plus any camera the
        user later clicked in the sidebar.
        """
        self._startup_cameras = cameras
        self._finish_live_session_restore()

        for page_name in ("recordings", "snapshots", "events"):
            page = self.stack.get_child_by_name(page_name)
            if page and hasattr(page, "refresh_camera_filter"):
                page.refresh_camera_filter()

    def _finish_live_session_restore(self) -> None:
        """Restore once both inputs needed by the selected view are ready."""
        if (self._pending_live_restore is None
                or self.app.api is not self._startup_restore_api
                or self._startup_cameras is None):
            return
        live_view = self.stack.get_child_by_name("live")
        if live_view is None:
            return
        cameras = self._startup_cameras
        live_view.restore_session(cameras, start_streams=False)
        selected = self.app.config.selected_server_layout
        # Built-in grids and named local layouts never need a NAS-layout
        # round trip. A blank choice may resolve to the account's default.
        local_ready = (selected == "local" or
                       (selected.startswith("-") and selected[1:].isdecimal()
                        and int(selected) in self.server_layouts))
        if not local_ready and not self._layout_inventory_ready:
            return
        self._pending_live_restore = None
        if not self.restore_selected_server_layout():
            live_view.restore_session(cameras)
        if self.app.config.camera_fullscreen:
            self.set_camera_fullscreen(True)

    def _ensure_page(self, name: str) -> Gtk.Widget | None:
        """Create an allowed page once; Settings is also usable logged out."""
        existing = self.stack.get_child_by_name(name)
        if existing is not None:
            return existing
        if name == "settings":
            module_name, class_name = "settings", "SettingsView"
        elif name in _CONTENT_PAGES and self.app.api is not None:
            module_name, class_name = _CONTENT_PAGES[name]
        else:
            return None
        widget_class = getattr(import_module(f"surveillance.ui.{module_name}"), class_name)
        widget = widget_class(self)
        self.stack.add_named(widget, name)
        if name == "live":
            api = self.app.api

            def cameras_updated(cameras: list[Camera]) -> None:
                if self.app.api is not api or self.stack.get_child_by_name("live") is not widget:
                    return
                widget.sync_camera_statuses(cameras)
                # Also catches a successful poll after the first Camera.List
                # failed. Initial restoration must not depend on that one
                # request's optional completion callback firing.
                if self._pending_live_restore is not None:
                    self._restore_live_session(cameras)

            self.sidebar.on_cameras_updated = cameras_updated
        return widget

    def _setup_content_pages(self) -> None:
        """Build Live and the selected page; other views open on demand."""
        self.sidebar.set_logged_out(False)
        self.sidebar.set_visible(self.app.config.sidebar_visible)

        # Discard pages from an earlier NAS/session. Settings has no NAS
        # state and remains usable throughout a logout/re-login.
        self.sidebar.on_cameras_updated = None
        for name in _CONTENT_PAGES:
            old = self.stack.get_child_by_name(name)
            if old is not None:
                if name == "live":
                    old.stop_all()
                self.stack.remove(old)
        self._ensure_page("live")

        # Restore last active page
        last_page = self.app.config.last_page
        if last_page not in _CONTENT_PAGES and last_page != "settings":
            last_page = "live"
        self._ensure_page(last_page)
        self.stack.set_visible_child_name(last_page)
        self.headerbar.set_page(last_page)
        self.sidebar.set_active_page(last_page)

        # This bypasses show_page(), which normally pauses Live View's
        # streams on navigating away — so without this, the session-restore
        # triggered by login (see _restore_live_session) would start every
        # camera in the last-used layout playing (with audio, if unmuted)
        # even though a different page is what's actually shown.
        if last_page != "live":
            live_view = self.stack.get_child_by_name("live")
            if live_view and hasattr(live_view, "pause_streams"):
                live_view.pause_streams()

    def _start_polling(self) -> None:
        """Start background polling for alerts and home mode."""
        self._stop_polling()

        from surveillance.util.async_bridge import run_async

        self._homemode_available = True
        self._alerts_available = True

        # Poll home mode
        def _poll_homemode() -> bool:
            if not self._homemode_available:
                # Returning False is GLib destroying this source, so drop the
                # id with it. _stop_polling() would otherwise call
                # source_remove() on a source that is already gone.
                self._homemode_poll_id = 0
                return False
            if not self.app.api:
                return True
            from surveillance.services.homemode import get_homemode

            def _homemode_error(e: Exception) -> None:
                from surveillance.api.client import ApiError

                if isinstance(e, ApiError) and e.code in (102, 103, 104):
                    log.debug("Home mode API not available: %s", e)
                    self._homemode_available = False
                else:
                    log.debug("Home mode poll failed: %s", e)

            run_async(
                get_homemode(self.app.api),
                callback=lambda info: self.headerbar.set_home_mode(info.on),
                error_callback=_homemode_error,
            )
            return True

        self._homemode_poll_id = GLib.timeout_add_seconds(
            self.app.config.poll_interval_homemode, _poll_homemode
        )
        _poll_homemode()  # initial fetch

        # Poll alerts
        def _poll_alerts() -> bool:
            if not self._alerts_available:
                self._alerts_poll_id = 0
                return False
            if not self.app.api:
                return True
            from surveillance.services.event import count_unread_alerts

            def _alerts_error(e: Exception) -> None:
                from surveillance.api.client import ApiError

                if isinstance(e, ApiError) and e.code in (102, 103, 104):
                    log.debug("Notification API not available: %s", e)
                    self._alerts_available = False
                else:
                    log.debug("Alert poll failed: %s", e)

            run_async(
                count_unread_alerts(self.app.api),
                callback=self.headerbar.set_notification_count,
                error_callback=_alerts_error,
            )
            return True

        self._alerts_poll_id = GLib.timeout_add_seconds(
            self.app.config.poll_interval_alerts, _poll_alerts
        )
        _poll_alerts()

        self._start_transactions_polling()

    def _start_transactions_polling(self) -> None:
        """Show new POS receipts (Surveillance Station Transactions) over
        the Live View slots showing each POS device's paired camera."""
        from surveillance.util.async_bridge import run_async

        self._transactions_available = True
        # POS device id -> camera id, None until first read.
        self._pos_cameras: dict[int, int] | None = None
        self._pos_cameras_at = 0.0
        self._seen_transactions: dict[str, str] = {}  # id -> text

        def _live_view() -> LiveView | None:
            from surveillance.ui.liveview import LiveView

            live = self.stack.get_child_by_name("live")
            return live if isinstance(live, LiveView) else None

        async def _fetch(
            shown: set[int], paired: dict[int, int] | None
        ) -> tuple[dict[int, int] | None, tuple[int, list[Transaction]]]:
            """Re-read the pairing when *paired* is None, then the
            receipts if a paired camera is among *shown*."""
            from surveillance.services.transactions import (
                get_paired_devices,
                get_recent_transactions,
            )

            api = self.app.api
            if api is None:
                return None, (0, [])
            cameras = None
            if paired is None:
                cameras = paired = await get_paired_devices(api)
            if not shown & set(paired.values()):
                return cameras, (0, [])
            return cameras, await get_recent_transactions(api)

        def _apply(result: tuple[dict[int, int] | None, tuple[int, list[Transaction]]]) -> None:
            cameras, (now, transactions) = result
            if cameras is not None:
                self._pos_cameras = cameras
                self._pos_cameras_at = time.monotonic()
            from surveillance.services.transactions import fresh_receipts
            from surveillance.ui import liveview

            live = _live_view()
            # The NAS's own clock, as receipt times are in it: a client
            # running a minute fast would otherwise see every one as stale.
            cutoff = (now or time.time()) - liveview._RECEIPT_SECONDS
            paired = self._pos_cameras or {}
            for tx in fresh_receipts(transactions, self._seen_transactions, cutoff):
                camera_id = paired.get(tx.pos_id)
                if live is not None and camera_id:
                    live.show_transaction(camera_id, tx.text)
            if len(self._seen_transactions) > 500:
                self._seen_transactions = {tx.id: tx.text for tx in transactions}

        def _transactions_error(e: Exception) -> None:
            from surveillance.api.auth import SessionExpiredError
            from surveillance.api.client import ApiError

            # 102-104: no such API/method/version; 105 even after the fresh
            # login request() makes for it: the account lacks the
            # Transactions privilege; 410: the Transactions add-on is off.
            # A failed re-login must not retry a login every poll; the
            # next connect starts polling again.
            if isinstance(e, SessionExpiredError) or (
                isinstance(e, ApiError) and e.code in (102, 103, 104, 105, 410)
            ):
                log.info("POS transactions overlay off: %s", e)
                self._transactions_available = False
            else:
                log.debug("Transactions poll failed: %s", e)

        def _poll_transactions() -> bool:
            if not self._transactions_available:
                self._transactions_poll_id = 0
                return False
            from surveillance.ui import liveview

            # Switched off on the Settings page: keep the timer, skip the
            # request, so switching it back on needs no restart.
            if not self.app.api or not liveview._RECEIPT_ENABLED:
                return True
            live = _live_view()
            if live is None:
                return True
            shown = live.displayed_camera_ids()
            paired = self._pos_cameras
            # The pairing rarely changes; re-read it every few minutes.
            if paired is not None and time.monotonic() - self._pos_cameras_at > 300:
                paired = None
            # Nothing to draw on: skip the request (each row carries a
            # snapshot) until a paired camera is on screen, also when
            # nothing is paired at all.
            if paired is not None and not shown & set(paired.values()):
                return True
            run_async(_fetch(shown, paired), callback=_apply, error_callback=_transactions_error)
            return True

        self._transactions_poll_id = GLib.timeout_add_seconds(
            self.app.config.poll_interval_transactions, _poll_transactions
        )
        _poll_transactions()

    def _stop_polling(self) -> None:
        """Stop background polling for alerts and home mode."""
        if self._homemode_poll_id:
            GLib.source_remove(self._homemode_poll_id)
            self._homemode_poll_id = 0
        if self._alerts_poll_id:
            GLib.source_remove(self._alerts_poll_id)
            self._alerts_poll_id = 0
        if self._transactions_poll_id:
            GLib.source_remove(self._transactions_poll_id)
            self._transactions_poll_id = 0

    def on_disconnected(self) -> None:
        """Clean up when disconnected (logout/quit)."""
        self.sidebar.stop_polling()
        self.sidebar.clear()
        self._stop_polling()
        self._show_logged_out_state()

        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "stop_all"):
            live_view.stop_all()

        from surveillance.services.recording import clear_snapshot_cache

        clear_snapshot_cache()

    def on_camera_selected(self, camera: Camera) -> None:
        """Handle camera selection from sidebar."""
        log.info("Selected camera: %s (id=%d)", camera.name, camera.id)

        # Notify the current visible page
        current_page = self.stack.get_visible_child()
        if current_page and hasattr(current_page, "on_camera_selected"):
            if self.stack.get_visible_child_name() == "live":
                self._pending_live_restore = None
                self._layout_selection_revision = getattr(self, "_layout_selection_revision", 0) + 1
            current_page.on_camera_selected(camera)

    def restart_camera_stream(self, camera_id: int) -> None:
        """Restart the stream for a camera after a protocol change."""
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "restart_camera"):
            live_view.restart_camera(camera_id)

    def reload_all_streams(self) -> None:
        """Restart every live stream, from the header bar's Reload button."""
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "reload_all_streams"):
            live_view.reload_all_streams()

    def clear_selected_slot(self) -> None:
        """Clear the selected grid slot on the visible page, if it has one."""
        current_page = self.stack.get_visible_child()
        if current_page and hasattr(current_page, "clear_selected_slot"):
            current_page.clear_selected_slot()

    def toggle_sidebar(self, visible: bool) -> None:
        """Show or hide the camera sidebar panel."""
        self.sidebar.set_visible(visible)
        self.app.config.sidebar_visible = visible

        from surveillance.config import save_config

        save_config(self.app.config)

    def _restore_sidebar_width(self) -> bool:
        if not self.sidebar.get_mapped() or self.paned.get_width() <= 0:
            return False
        self._restoring_sidebar_width = True
        try:
            self.paned.set_position(sidebar_width_for_window(
                self.app.config.sidebar_width, self.paned.get_width()
            ))
        finally:
            self._restoring_sidebar_width = False
        return False

    def _on_sidebar_width_changed(self, paned: Gtk.Paned, *_args: object) -> None:
        # Fullscreen/hide temporarily removes the sidebar from allocation;
        # that must not erase the remembered user width.
        if self._restoring_sidebar_width or not self.sidebar.get_mapped():
            return
        position = sidebar_width_for_window(paned.get_position(), paned.get_width())
        if position != paned.get_position():
            self._restoring_sidebar_width = True
            try:
                paned.set_position(position)
            finally:
                self._restoring_sidebar_width = False
        if self.app.config.sidebar_width != position:
            self.app.config.sidebar_width = position
            from surveillance.config import save_config

            save_config(self.app.config)

    def toggle_timeline(self, visible: bool) -> None:
        """Show or hide the Live View timeline."""
        live_view = self.stack.get_child_by_name("live")
        if live_view and hasattr(live_view, "timeline"):
            live_view.timeline.set_visible(visible)
        self.app.config.timeline_visible = visible

        from surveillance.config import save_config

        save_config(self.app.config)

    def show_page(self, page_name: str) -> None:
        """Switch to a content page, pausing/resuming live streams as needed."""
        existing = self.stack.get_child_by_name(page_name)
        new_page = self._ensure_page(page_name)
        if new_page is None:
            return
        previous = self.stack.get_visible_child_name()
        self.stack.set_visible_child_name(page_name)
        self.headerbar.set_page(page_name)
        self.sidebar.set_active_page(page_name)
        self.app.config.last_page = page_name
        from surveillance.config import save_config

        save_config(self.app.config)

        # Data views fetch during construction. A first visit must not
        # immediately queue a duplicate refresh behind that initial request.
        if (existing is not None or page_name == "about") and hasattr(new_page, "on_page_shown"):
            new_page.on_page_shown()

        live_view = self.stack.get_child_by_name("live")
        if not live_view or not hasattr(live_view, "pause_streams"):
            return
        if previous == "live" and page_name != "live":
            live_view.pause_streams()
        elif previous != "live" and page_name == "live":
            live_view.resume_streams()
