"""Execute the real installer/rollback with isolated PeakOS paths and freeze.

The application's runtime bytes are reduced to a test fixture, with the matching
expected digest substituted in the temporary copy. No real /boot or /tmp/config
path is touched.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import unittest


PACKAGE = Path(__file__).parent / "package" / "10zig-surveillance"
if not (PACKAGE / "install.sh").is_file():
    # This test is also shipped in the extracted ZIP's build-information.
    PACKAGE = Path(__file__).resolve().parent.parent
RUNTIME = b"fixture for the existing read-only native runtime\n"
SHA = hashlib.sha256(RUNTIME).hexdigest()
OLD_SHA = "91dc667cc2f2c1b49af9ec06a6ba5a7df1253ee36dcc9394a5eb6113a45973c4"
BUILD_ID = "surveillance-0.15.0-peakos16.5-x86_64-20261030"


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="cameras-install-test-")
        self.base = Path(self.tmp.name)
        self.usb = self.base / "usb" / "10zig-surveillance"
        self.root = self.base / "boot" / "custom-apps" / "10zig-surveillance"
        self.config = self.base / "tmp" / "config"
        self.local = self.config / "files" / "surveillance-client"
        self.conn = self.config / "xmlconfig" / "user" / "software" / "shellscript" / "connections" / "Q2FtZXJhcw==.xml"
        self.bin = self.base / "bin"
        self.bin.mkdir()
        self.usb.mkdir(parents=True)
        self.local.mkdir(parents=True)
        self.conn.parent.mkdir(parents=True)
        (self.base / "boot").mkdir(exist_ok=True)
        (self.usb / "app" / "surveillance").mkdir(parents=True)
        (self.usb / "app" / "surveillance" / "__main__.py").write_text("# new application\n")
        for name in ("install.sh", "start-surveillance.sh", "rollback.sh"):
            text = (PACKAGE / name).read_text()
            text = text.replace("/boot/", str(self.base / "boot") + "/")
            text = text.replace("/tmp/config", str(self.config))
            text = text.replace('"/tmp/$SURV_REL"', '"' + str(self.base / "tmp") + '/$SURV_REL"')
            text = text.replace("/tmp/10zig-", str(self.base / "tmp") + "/10zig-")
            text = text.replace(OLD_SHA, SHA)
            (self.usb / name).write_text(text)
        freeze = self.bin / "freeze"
        freeze.write_text("#!/bin/sh\nset -e\n[ \"${FAIL_FREEZE:-0}\" = 0 ] || exit 8\ntar -czf " + str(self.base / "boot" / "config.tar.gz") + " -C " + str(self.base / "tmp") + " config\n")
        freeze.chmod(0o755)
        identity = self.bin / "id"
        identity.write_text("#!/bin/sh\nprintf '0\\n'\n")
        identity.chmod(0o755)
        self.tool("sync", "exit 0\n")
        self.env = dict(os.environ, PATH=str(self.bin) + ":" + os.environ["PATH"], DISPLAY="")

    def tearDown(self):
        self.tmp.cleanup()

    def manifest(self):
        rows = []
        for path in sorted(self.usb.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                rows.append(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(self.usb)))
        (self.usb / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n")

    def existing(self):
        self.root.mkdir(parents=True)
        (self.root / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        (self.root / "profile" / "config").mkdir(parents=True)
        (self.root / "profile" / "config" / "keep.toml").write_text("valuable = 'existing profile'\n")
        (self.local / "start-surveillance.sh").write_text("# original launcher\n")
        (self.local / "image-path.txt").write_text(str(self.root / "surveillance-runtime.squashfs") + "\n")
        (self.config / "files" / "Cameras.sh").write_text("# original connection script\n")
        self.conn.write_text('<key><_string value="connStartArgs">CONN_PNAME_SUBST</_string><untouched>yes</untouched></key>\n')

    def run_script(self, script, **extra_env):
        return subprocess.run(["sh", str(script)], env=dict(self.env, **extra_env), capture_output=True, text=True, timeout=20)

    def tool(self, name, body):
        command = self.bin / name
        command.write_text("#!/bin/sh\n" + body)
        command.chmod(0o755)

    def mount_harness(self):
        """Run the real launcher; emulate only mount syscalls and the GUI child.

        Real stat, SHA256, flock, scripts, file moves, and cache receipts are used.
        No privileged mount, actual /boot, or endpoint hardware is involved.
        """
        self.prefix = self.base / "tmp" / "10zig-surveillance-runtime"
        self.mount_receipt = self.base / "tmp" / "10zig-surveillance-runtime.identity"
        self.mounted = self.base / "mounted"
        self.trace = self.base / "commands.txt"
        self.capture = self.base / "captured-environment.txt"
        self.template = self.base / "runtime-template"
        (self.template / "bin").mkdir(parents=True)
        (self.template / "10zig-build-id.txt").write_text(BUILD_ID + "\n")
        python = self.template / "bin" / "python"
        python.write_text(
            '#!/bin/sh\nprintf "python\\n" >> "$SURV_TEST_TRACE"\n'
            'printf "%s\\n" "$XDG_CONFIG_HOME" "$XDG_DATA_HOME" "$PYTHONPATH" '
            '"$SURVEILLANCE_CREDENTIAL_STORE" "$SURVEILLANCE_MPV_OPTS" > "$SURV_TEST_CAPTURE"\n'
            'exit "${SURV_TEST_CHILD_STATUS:-0}"\n'
        )
        python.chmod(0o755)
        self.env.update(
            SURV_TEST_PREFIX=str(self.prefix),
            SURV_TEST_IMAGE=str(self.root / "surveillance-runtime.squashfs"),
            SURV_TEST_MOUNTED=str(self.mounted),
            SURV_TEST_TEMPLATE=str(self.template),
            SURV_TEST_TRACE=str(self.trace),
            SURV_TEST_CAPTURE=str(self.capture),
        )
        self.tool("mountpoint", '[ -f "$SURV_TEST_MOUNTED" ]\n')
        self.tool("mount", '''set -e
[ "$1" = -t ] && [ "$2" = squashfs ] && [ "$3" = -o ]
[ "$4" = loop,ro,nodev,nosuid ]
[ "$5" = "$SURV_TEST_IMAGE" ] && [ "$6" = "$SURV_TEST_PREFIX" ]
printf 'mount\n' >> "$SURV_TEST_TRACE"
cp -R "$SURV_TEST_TEMPLATE/." "$SURV_TEST_PREFIX/"
touch "$SURV_TEST_MOUNTED"
''')
        self.tool("umount", '''set -e
[ "$1" = "$SURV_TEST_PREFIX" ]
printf 'umount\n' >> "$SURV_TEST_TRACE"
[ "${SURV_TEST_BUSY:-0}" = 0 ] || exit 32
rm -rf "$SURV_TEST_PREFIX"
mkdir -p "$SURV_TEST_PREFIX"
rm -f "$SURV_TEST_MOUNTED"
''')
        real_sha = shlex.quote(shutil.which("sha256sum"))
        self.tool("sha256sum", '''printf 'sha256sum %s\n' "$*" >> "$SURV_TEST_TRACE"
''' + real_sha + ''' "$@"
SURV_TEST_RESULT=$?
if [ "${SURV_TEST_MUTATE_AFTER_HASH:-}" = "$1" ]; then
    printf 'changed during hashing\n' >> "$1"
fi
exit "$SURV_TEST_RESULT"
''')
        real_stat = shlex.quote(shutil.which("stat"))
        self.tool("stat", '[ "${SURV_TEST_NO_STAT:-0}" = 0 ] || exit 1\nexec ' + real_stat + ' "$@"\n')

    def simulate_mount(self, build_id=BUILD_ID):
        shutil.copytree(self.template, self.prefix, dirs_exist_ok=True)
        (self.prefix / "10zig-build-id.txt").write_text(build_id + "\n")
        self.mounted.touch()

    def launch(self, **extra_env):
        return self.run_script(self.local / "start-surveillance.sh", **extra_env)

    def events(self):
        return self.trace.read_text().splitlines() if self.trace.exists() else []

    def install_for_launcher_test(self):
        self.existing()
        self.mount_harness()
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.trace.write_text("")

    def test_update_and_rollback_preserve_profile_and_runtime(self):
        self.existing()
        old_app = self.root / "app" / "surveillance" / "__main__.py"
        old_app.parent.mkdir(parents=True)
        old_app.write_text("# previous layouts4 application\n")
        (self.root / "release.txt").write_text("0.15.0+peakos.layouts4\n")
        credentials = self.root / "profile" / "data" / "surveillance" / "credentials"
        credentials.mkdir(parents=True)
        (credentials / "account.fernet").write_bytes(b"encrypted credential test fixture")
        layouts = self.root / "profile" / "config" / "local-layouts.json"
        layouts.write_text('{"name":"My layout","cameras":[1,2,3,4]}\n')
        profile_before = {p.relative_to(self.root / "profile"): p.read_bytes() for p in (self.root / "profile").rglob("*") if p.is_file()}
        self.manifest()
        original_config = (self.root / "profile" / "config" / "keep.toml").read_bytes()
        original_script = (self.config / "files" / "Cameras.sh").read_bytes()
        original_xml = self.conn.read_bytes()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.root / "surveillance-runtime.squashfs").read_bytes(), RUNTIME)
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_bytes(), original_config)
        self.assertIn('>Cameras<', self.conn.read_text())
        self.assertIn('<untouched>yes</untouched>', self.conn.read_text())
        self.assertTrue((self.root / "app" / "surveillance" / "__main__.py").exists())
        self.assertEqual((self.root / "release.txt").read_text(), "0.15.0+peakos.layouts5\n")
        for relative, contents in profile_before.items():
            self.assertEqual((self.root / "profile" / relative).read_bytes(), contents)
        self.assertIn('SURVEILLANCE_CREDENTIAL_STORE=file', (self.local / "start-surveillance.sh").read_text())
        result = self.run_script(self.root / "rollback.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertEqual((self.config / "files" / "Cameras.sh").read_bytes(), original_script)
        self.assertEqual(self.conn.read_bytes(), original_xml)
        self.assertEqual(old_app.read_text(), "# previous layouts4 application\n")
        self.assertEqual((self.root / "release.txt").read_text(), "0.15.0+peakos.layouts4\n")
        for relative, contents in profile_before.items():
            self.assertEqual((self.root / "profile" / relative).read_bytes(), contents)
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_bytes(), original_config)

    def test_update_rejects_missing_runtime_before_installing(self):
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("small update requires", result.stderr)
        self.assertFalse(self.root.exists())

    def test_damaged_source_rejected_before_touching_existing_install(self):
        self.existing()
        self.manifest()
        (self.usb / "app" / "surveillance" / "__main__.py").write_text("corrupted\n")
        result = self.run_script(self.usb / "install.sh")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertFalse((self.root / "last-backup.txt").exists())

    def test_full_package_installs_runtime(self):
        (self.usb / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.root / "surveillance-runtime.squashfs").read_bytes(), RUNTIME)
        self.assertTrue((self.root / "profile").exists())

    def test_failed_freeze_reports_rollback_and_previous_install_is_restorable(self):
        self.existing()
        self.manifest()
        result = self.run_script(self.usb / "install.sh", FAIL_FREEZE="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("rollback.sh", result.stderr)
        result = self.run_script(self.root / "rollback.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_text(), "valuable = 'existing profile'\n")

    def test_launcher_uses_internal_profile_overlay_and_software_decoding(self):
        self.install_for_launcher_test()
        result = self.launch(SURVEILLANCE_MPV_OPTS="")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.capture.read_text().splitlines(), [
            str(self.root / "profile" / "config"),
            str(self.root / "profile" / "data"),
            str(self.root / "app"),
            "file",
            "hwdec=no",
        ])
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_text(), "valuable = 'existing profile'\n")

    def test_installer_seeds_checksum_and_two_launches_mount_only_once(self):
        self.install_for_launcher_test()
        self.assertTrue((self.root / "runtime-verification.txt").is_file())
        for _ in range(2):
            result = self.launch()
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["mount", "python", "python"])
        self.assertTrue(self.mounted.exists())
        self.assertTrue(self.mount_receipt.is_file())

    def test_reboot_remounts_without_rehashing_unchanged_verified_file(self):
        self.install_for_launcher_test()
        self.assertEqual(self.launch().returncode, 0)
        self.mounted.unlink()
        self.mount_receipt.unlink()
        shutil.rmtree(self.prefix)
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["mount", "python", "mount", "python"])

    def test_missing_checksum_receipt_hashes_once_then_reuses(self):
        self.install_for_launcher_test()
        (self.root / "runtime-verification.txt").unlink()
        for _ in range(2):
            result = self.launch()
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["sha256sum " + self.env["SURV_TEST_IMAGE"], "mount", "python", "python"])

    def test_corrupt_backing_file_is_rejected_even_with_mount_and_restored_mtime(self):
        self.install_for_launcher_test()
        self.assertEqual(self.launch().returncode, 0)
        image = self.root / "surveillance-runtime.squashfs"
        before = image.stat()
        image.write_bytes(b"X" + RUNTIME[1:])
        os.utime(image, ns=(before.st_atime_ns, before.st_mtime_ns))
        self.trace.write_text("")
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("runtime is incomplete", result.stderr)
        self.assertEqual(self.events(), ["sha256sum " + str(image)])

    def test_same_bytes_replaced_at_same_path_are_reverified_and_remounted(self):
        self.install_for_launcher_test()
        self.assertEqual(self.launch().returncode, 0)
        image = self.root / "surveillance-runtime.squashfs"
        replacement = image.with_suffix(".new")
        replacement.write_bytes(RUNTIME)
        replacement.replace(image)
        self.trace.write_text("")
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["sha256sum " + str(image), "umount", "mount", "python"])

    def test_changed_during_verification_is_rejected_without_saving_receipt(self):
        self.install_for_launcher_test()
        (self.root / "runtime-verification.txt").unlink()
        result = self.launch(SURV_TEST_MUTATE_AFTER_HASH=self.env["SURV_TEST_IMAGE"])
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("changed while it was being verified", result.stderr)
        self.assertFalse((self.root / "runtime-verification.txt").exists())
        self.assertFalse(self.mounted.exists())

    def test_unavailable_stat_keeps_full_verification_and_remounts(self):
        self.install_for_launcher_test()
        (self.root / "runtime-verification.txt").unlink()
        for _ in range(2):
            result = self.launch(SURV_TEST_NO_STAT="1")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        checksum = "sha256sum " + self.env["SURV_TEST_IMAGE"]
        self.assertEqual(self.events(), [checksum, "mount", "python", checksum, "umount", "mount", "python"])
        self.assertFalse((self.root / "runtime-verification.txt").exists())

    def test_legacy_mount_without_identity_is_remounted_once(self):
        self.install_for_launcher_test()
        self.simulate_mount()
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["umount", "mount", "python"])

    def test_foreign_or_busy_mount_is_not_used(self):
        self.install_for_launcher_test()
        self.simulate_mount("unrelated runtime")
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("different version", result.stderr)
        self.assertEqual(self.events(), [])
        (self.prefix / "10zig-build-id.txt").write_text(BUILD_ID + "\n")
        result = self.launch(SURV_TEST_BUSY="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("still in use", result.stderr)
        self.assertEqual(self.events(), ["umount"])

    def test_full_install_releases_stale_mount_before_copying_missing_runtime(self):
        self.mount_harness()
        self.simulate_mount()
        (self.usb / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("umount", self.events())
        self.assertFalse(self.mounted.exists())
        self.trace.write_text("")
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["mount", "python"])

    def test_full_install_refuses_foreign_mount_before_committing(self):
        self.mount_harness()
        self.simulate_mount("unrelated runtime")
        (self.usb / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("another application build", result.stderr)
        self.assertFalse(self.root.exists())
        self.assertNotIn("umount", self.events())

    def test_symlink_receipts_never_overwrite_their_targets(self):
        self.install_for_launcher_test()
        receipt = self.root / "runtime-verification.txt"
        receipt.unlink()
        target = self.base / "unrelated-file"
        target.write_text("keep this file\n")
        receipt.symlink_to(target)
        self.mount_receipt.symlink_to(target)
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(target.read_text(), "keep this file\n")
        self.assertFalse(receipt.is_symlink())
        self.assertFalse(self.mount_receipt.is_symlink())

    def test_update_and_rollback_with_retained_mount_preserve_runtime(self):
        self.install_for_launcher_test()
        self.assertEqual(self.launch().returncode, 0)
        runtime_before = (self.root / "surveillance-runtime.squashfs").stat()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self.run_script(self.root / "rollback.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(self.mounted.exists())
        self.assertFalse(self.mount_receipt.exists())
        self.trace.write_text("")
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.events(), ["mount", "python"])
        runtime_after = (self.root / "surveillance-runtime.squashfs").stat()
        self.assertEqual((runtime_before.st_ino, runtime_before.st_mtime_ns),
                         (runtime_after.st_ino, runtime_after.st_mtime_ns))

    def test_rollback_refuses_busy_or_foreign_mount_before_changes(self):
        self.install_for_launcher_test()
        self.assertEqual(self.launch().returncode, 0)
        launcher_before = (self.local / "start-surveillance.sh").read_bytes()
        backup = Path((self.root / "last-backup.txt").read_text().strip())
        for build_id, busy, expected in ((BUILD_ID, "1", "still in use"), ("foreign", "0", "another build")):
            (self.prefix / "10zig-build-id.txt").write_text(build_id + "\n")
            result = self.run_script(self.root / "rollback.sh", SURV_TEST_BUSY=busy)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(expected, result.stderr)
            self.assertEqual((self.local / "start-surveillance.sh").read_bytes(), launcher_before)
            self.assertFalse((backup / "RESTORED").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
