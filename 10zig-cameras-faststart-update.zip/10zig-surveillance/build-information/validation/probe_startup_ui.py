#!/usr/bin/env python3
"""Time the real GTK/app/Live constructors using a local video fixture.

Run in an isolated XDG profile and virtual display. Network coroutines are
closed rather than run; the fixture checks real libmpv/OpenGL first-frame
latency without claiming to measure a NAS or a physical 10ZiG.
"""
from __future__ import annotations

import json
import os
import sys
import time

started = time.perf_counter()
marks: dict[str, float] = {}
requests: list[str] = []
render_info: dict[str, object] = {"count": 0}


def mark(name: str) -> None:
    marks[name] = time.perf_counter() - started


from surveillance.app import SurveillanceApp
from gi.repository import GLib, Gtk
from surveillance import config as config_store
from surveillance.config import AppConfig, ConnectionProfile
from surveillance.util import async_bridge

mark("app_imported")


def no_network(coroutine, **kwargs):
    requests.append(getattr(coroutine, "__qualname__", type(coroutine).__name__))
    coroutine.close()
    return None


async_bridge.run_async = no_network
config = AppConfig()
config.grid_layout = "1x1"
config.last_page = "live"
config.selected_server_layout = "local"
config.live_pipeline_revision = 1
config_store.save_config_now(config)


class ProbeApp(SurveillanceApp):
    def do_startup(self):
        mark("startup_begin")
        super().do_startup()
        mark("startup_complete")

    def do_activate(self):
        mark("activate_begin")
        super().do_activate()
        mark("present_called")


app = ProbeApp()
app.register(None)
app.activate()
window = app._window
loop = GLib.MainLoop()
connected = False


def finish(error=None):
    result = {
        "python": sys.version.split()[0],
        "source": __import__("surveillance.app", fromlist=["__file__"]).__file__,
        "timings_seconds": marks,
        "requests_scheduled_before_first_frame": requests,
        "pages_built": [name for name in
            ("live", "recordings", "snapshots", "events", "timelapse", "licenses", "about", "settings")
            if window.stack.get_child_by_name(name)],
        "error": error,
        "render_info": render_info,
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    os._exit(0 if error is None else 1)


def begin_connection():
    for top in list(Gtk.Window.get_toplevels()):
        if top is not window:
            top.destroy()
    from types import SimpleNamespace
    api = SimpleNamespace(
        profile=ConnectionProfile(name="local-probe", host="127.0.0.1", port=5001,
                                  https=True, verify_ssl=False),
        has_api=lambda *_: False,
    )
    def refresh(on_complete=None):
        if window.sidebar.on_cameras_updated is not None:
            window.sidebar.on_cameras_updated([])
        if on_complete is not None:
            on_complete([])
    window.sidebar.refresh = refresh
    mark("connection_begin")
    from surveillance.ui.mpv_widget import MpvGLArea
    original_render = MpvGLArea._on_render
    def frame_rendered(player, *args):
        result = original_render(player, *args)
        render_info["count"] += 1
        render_info["url"] = player._url
        render_info["mapped"] = player.get_mapped()
        render_info["initialized"] = player._initialized
        render_info["size"] = player._video_size
        if "first_fixture_frame" not in marks and player._mpv is not None and player._url:
            try:
                position = player._mpv.time_pos
                render_info["position"] = position
                if position is not None:
                    mark("first_fixture_frame")
                    GLib.idle_add(finish)
            except Exception as error:
                render_info["position_error"] = str(error)
        return result
    MpvGLArea._on_render = frame_rendered
    app.set_api(api, app.event_backend)
    window.on_connected()
    mark("connected_handler_complete")
    live = window.stack.get_child_by_name("live")
    player = live._slots[0].player
    mark("play_requested")
    player.play(sys.argv[1])
    return False


def painted(clock):
    global connected
    if not connected:
        connected = True
        mark("first_window_painted")
        GLib.idle_add(begin_connection)


window.get_frame_clock().connect("after-paint", painted)
GLib.timeout_add_seconds(20, lambda: finish("startup or first-video-frame timed out"))
loop.run()
