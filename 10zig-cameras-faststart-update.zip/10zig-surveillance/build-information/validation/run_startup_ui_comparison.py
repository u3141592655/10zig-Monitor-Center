#!/usr/bin/env python3
"""Repeat paired, fresh-process GTK startup probes on a virtual display."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--baseline", type=Path, required=True)
parser.add_argument("--candidate", type=Path, required=True)
parser.add_argument("--runtime", type=Path, required=True)
parser.add_argument("--fixture", type=Path, required=True)
parser.add_argument("--display", default=":95")
parser.add_argument("--runs", type=int, default=5)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
raw = {"baseline": [], "candidate": []}
probe = Path(__file__).with_name("probe_startup_ui.py")
with tempfile.TemporaryDirectory(prefix="camera-startup-compare-") as temporary:
    for trial in range(args.runs):
        for label, source in (("baseline", args.baseline), ("candidate", args.candidate)):
            profile = Path(temporary) / f"{label}-{trial}"
            env = {
                **os.environ,
                "DISPLAY": args.display,
                "LD_LIBRARY_PATH": str(args.runtime / "lib"),
                "PYTHONPATH": str(source / "src"),
                "PYTHONNOUSERSITE": "1",
                "GI_TYPELIB_PATH": str(args.runtime / "lib/girepository-1.0"),
                "GSETTINGS_SCHEMA_DIR": str(args.runtime / "share/glib-2.0/schemas"),
                "XDG_DATA_DIRS": f"{args.runtime}/share:/usr/local/share:/usr/share",
                "XDG_CONFIG_HOME": str(profile / "config"),
                "XDG_DATA_HOME": str(profile / "data"),
                "XDG_STATE_HOME": str(profile / "state"),
                "SURVEILLANCE_CREDENTIAL_STORE": "file",
                "SURVEILLANCE_MPV_OPTS": "hwdec=no",
                "SURVEILLANCE_AO": "null",
                "GDK_BACKEND": "x11",
                "GSK_RENDERER": "gl",
                "GDK_DEBUG": "gl-prefer-gl",
            }
            result = subprocess.run(
                [str(args.runtime / "bin/python"), str(probe), str(args.fixture)],
                env=env, capture_output=True, text=True, timeout=30, check=False,
            )
            if result.returncode:
                raise RuntimeError(f"{label} probe failed:\n{result.stdout}\n{result.stderr}")
            raw[label].append(json.loads(result.stdout.strip().splitlines()[-1]))

summary = {}
for label, runs in raw.items():
    summary[label] = {
        "first_real_window_painted_seconds_median": statistics.median(
            row["timings_seconds"]["first_window_painted"] for row in runs),
        "login_handler_seconds_median": statistics.median(
            row["timings_seconds"]["connected_handler_complete"] -
            row["timings_seconds"]["connection_begin"] for row in runs),
        "login_to_first_real_video_frame_seconds_median": statistics.median(
            row["timings_seconds"]["first_fixture_frame"] -
            row["timings_seconds"]["connection_begin"] for row in runs),
        "process_to_first_real_video_frame_seconds_median": statistics.median(
            row["timings_seconds"]["first_fixture_frame"] for row in runs),
        "startup_requests": runs[0]["requests_scheduled_before_first_frame"],
        "pages_built": runs[0]["pages_built"],
    }
report = {
    "scope": "Fresh app processes, warm host filesystem cache, bundled GTK/libmpv, "
             "software-rendered Xvfb, local 1080p fixture; launcher, NAS latency and "
             "physical 10ZiG performance are not measured.",
    "runs_per_version": args.runs,
    "summary": summary,
    "raw": raw,
}
args.output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(summary, indent=2))
