#!/bin/sh
# Restore app and saved launcher from the latest Cameras update backup.
# Persistent camera profiles are deliberately retained.
set -eu

SURV_ROOT='/boot/custom-apps/10zig-surveillance'
SURV_LOCAL='/tmp/config/files/surveillance-client'
SURV_CAMERAS='/tmp/config/files/Cameras.sh'
SURV_CONN='/tmp/config/xmlconfig/user/software/shellscript/connections/Q2FtZXJhcw==.xml'
SURV_PREFIX='/tmp/10zig-surveillance-runtime'
SURV_MOUNT_RECEIPT='/tmp/10zig-surveillance-runtime.identity'
SURV_BUILD_ID='surveillance-0.15.0-peakos16.5-x86_64-20261030'

[ "$(id -u)" = 0 ] || { printf '%s\n' 'Use the PeakOS administrative console.' >&2; exit 1; }
command -v freeze >/dev/null 2>&1 || { printf '%s\n' 'PeakOS freeze was not found.' >&2; exit 1; }
exec 9>/tmp/10zig-surveillance.lock
flock -n 9 || { printf '%s\n' 'Close Cameras before restoring its previous version.' >&2; exit 1; }
[ -f "$SURV_ROOT/last-backup.txt" ] || { printf '%s\n' 'No update backup was found.' >&2; exit 1; }
IFS= read -r SURV_BACKUP < "$SURV_ROOT/last-backup.txt"
case "$SURV_BACKUP" in "$SURV_ROOT"/backup-before-layouts.*) ;; *) printf '%s\n' 'The saved backup path is invalid.' >&2; exit 1;; esac
[ -d "$SURV_BACKUP" ] || { printf '%s\n' 'The saved backup folder is missing.' >&2; exit 1; }
[ ! -e "$SURV_BACKUP/RESTORED" ] || { printf '%s\n' 'This backup has already been restored.' >&2; exit 1; }

# Older launchers do not track the retained mount's backing-file identity.
# Release our own idle mount before restoring them, so they perform their
# normal full runtime verification. Refuse a busy or foreign mount before
# modifying the app or shortcut. The runtime file and profile stay intact.
if mountpoint -q "$SURV_PREFIX"; then
    [ -r "$SURV_PREFIX/10zig-build-id.txt" ] && \
    [ "$(cat "$SURV_PREFIX/10zig-build-id.txt")" = "$SURV_BUILD_ID" ] || \
        { printf '%s\n' 'The runtime mount belongs to another build. Restart the 10ZiG before rolling back.' >&2; exit 1; }
    umount "$SURV_PREFIX" || \
        { printf '%s\n' 'The runtime is still in use. Close applications using it before rolling back.' >&2; exit 1; }
fi
if [ ! -d "$SURV_MOUNT_RECEIPT" ] || [ -L "$SURV_MOUNT_RECEIPT" ]; then
    rm -f "$SURV_MOUNT_RECEIPT"
fi

if [ -d "$SURV_ROOT/app" ]; then mv "$SURV_ROOT/app" "$SURV_BACKUP/new-app-after-rollback"; fi
if [ -d "$SURV_BACKUP/app" ]; then cp -R "$SURV_BACKUP/app" "$SURV_ROOT/app"; fi
if [ -d "$SURV_LOCAL" ]; then mv "$SURV_LOCAL" "$SURV_BACKUP/new-local-after-rollback"; fi
if [ -d "$SURV_BACKUP/local" ]; then cp -R "$SURV_BACKUP/local" "$SURV_LOCAL"; fi
if [ -f "$SURV_BACKUP/Cameras.sh" ]; then
    cp "$SURV_BACKUP/Cameras.sh" "$SURV_CAMERAS"
else
    rm -f "$SURV_CAMERAS"
fi
if [ -f "$SURV_BACKUP/Cameras.xml" ]; then cp "$SURV_BACKUP/Cameras.xml" "$SURV_CONN"; fi
if [ -f "$SURV_BACKUP/root-launcher.sh" ]; then
    cp "$SURV_BACKUP/root-launcher.sh" "$SURV_ROOT/start-surveillance.sh"
fi
if [ -f "$SURV_BACKUP/release.txt" ]; then
    cp "$SURV_BACKUP/release.txt" "$SURV_ROOT/release.txt"
else
    rm -f "$SURV_ROOT/release.txt"
fi
freeze
printf '%s\n' 'Restored' > "$SURV_BACKUP/RESTORED"
sync
printf '%s\n' 'Previous application and launcher restored. The persistent profile was retained.'
printf '%s\n' 'Restart the 10ZiG normally, then launch Cameras.'
