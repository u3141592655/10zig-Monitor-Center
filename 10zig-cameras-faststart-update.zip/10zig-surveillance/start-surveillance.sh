#!/bin/sh
# Community native Surveillance Station client for PeakOS 16.5 x86_64.
# Fast startup edition 0.15.0+peakos.layouts5: unchanged runtime, updated app overlay.
# Mounts this package's application runtime read-only. Does not modify system libraries.
set -u

SURV_BUILD_ID='surveillance-0.15.0-peakos16.5-x86_64-20261030'
SURV_EXPECTED_SHA256='91dc667cc2f2c1b49af9ec06a6ba5a7df1253ee36dcc9394a5eb6113a45973c4'
SURV_RUNTIME_NAME='surveillance-runtime.squashfs'
SURV_PREFIX='/tmp/10zig-surveillance-runtime'
SURV_MOUNT_RECEIPT='/tmp/10zig-surveillance-runtime.identity'
SURV_LOCAL='/tmp/config/files/surveillance-client'
SURV_LOG='/tmp/10zig-surveillance.log'
SURV_ERROR='/tmp/10zig-surveillance-error.txt'
SURV_SELF="$SURV_LOCAL/start-surveillance.sh"

if [ "${1:-}" = '--show-error' ]; then
    cat "${2:-$SURV_ERROR}"
    printf '\nPress Enter to close this window. '
    IFS= read -r SURV_REPLY || :
    exit 0
fi

surv_error() {
    printf '%s\n' "$1" >&2
    {
        printf '%s\n\n' "$1"
        if [ -s "$SURV_LOG" ]; then
            printf 'Last application messages:\n'
            tail -n 45 "$SURV_LOG"
        fi
    } > "$SURV_ERROR"
    if [ -n "${DISPLAY:-}" ] && command -v rxvt-unicode >/dev/null 2>&1; then
        rxvt-unicode -title 'Surveillance Station - message' -geometry 100x25 \
            -e /bin/sh "$SURV_SELF" --show-error "$SURV_ERROR" >/dev/null 2>&1 &
    fi
    exit 1
}

surv_file_identity() {
    # Both GNU and BusyBox stat accept this form. Include ctime as well
    # as mtime, and their fractional precision where the filesystem has
    # it: restoring a file's old mtime must not reuse an old checksum.
    SURV_ID=$(stat -L -c '%d:%i:%s:%y:%z' "$1" 2>/dev/null) || return 1
    case "$SURV_ID" in ''|*'%'*|*'?'*) return 1 ;; esac
    printf '%s\n' "$SURV_ID"
}

[ "$(id -u)" = 0 ] || surv_error 'This launcher needs the normal PeakOS root desktop session to mount its read-only application runtime.'
[ "$(uname -m)" = x86_64 ] || surv_error 'This package requires an x86_64 10ZiG. It does not support ARM or a 32-bit operating system.'

# One instance owns the mount and log. flock releases automatically on exit.
exec 9>/tmp/10zig-surveillance.lock
flock -n 9 || surv_error 'Surveillance Station is already running. Return to its existing window.'
: > "$SURV_LOG"

# This edition always uses internal storage. Falling back to an attached USB
# would create a different profile and make saved credentials appear to vanish.
SURV_IMAGE='/boot/custom-apps/10zig-surveillance/surveillance-runtime.squashfs'
[ -f "$SURV_IMAGE" ] || surv_error 'The internally installed runtime was not found. Run install.sh from the extracted full faster-startup ZIP.'

SURV_APP_DIR=${SURV_IMAGE%/*}
SURV_APP="$SURV_APP_DIR/app"
[ -f "$SURV_APP/surveillance/__main__.py" ] || surv_error 'The updated Cameras application files are missing. Run install.sh from the extracted faster-startup ZIP again.'
SURV_PROFILE="$SURV_APP_DIR/profile"
mkdir -p "$SURV_PROFILE/config" "$SURV_PROFILE/data" "$SURV_PROFILE/state" \
    /tmp/10zig-surveillance-cache || surv_error 'The application folder must be writable so the app can save its NAS profile and preferences.'
[ -w "$SURV_PROFILE/config" ] || surv_error 'The profile folder is not writable. Restore write access to the application storage and try again.'

# Installation has already checked every byte. Reuse that result only
# for this exact path, expected digest and unchanged file identity. A
# replaced/touched runtime or missing receipt receives a full checksum
# again. This avoids rereading 323 MB of slow flash on every app launch.
SURV_RECEIPT="$SURV_APP_DIR/runtime-verification.txt"
SURV_IMAGE_ID=$(surv_file_identity "$SURV_IMAGE") || SURV_IMAGE_ID=''
SURV_RECEIPT_EXPECTED=$(printf 'runtime-check-v1\n%s\n%s\n%s\n' \
    "$SURV_IMAGE" "$SURV_EXPECTED_SHA256" "$SURV_IMAGE_ID")
SURV_VERIFIED=no
if [ -n "$SURV_IMAGE_ID" ] && [ ! -L "$SURV_RECEIPT" ] && [ -f "$SURV_RECEIPT" ] && \
   [ "$(cat "$SURV_RECEIPT" 2>/dev/null)" = "$SURV_RECEIPT_EXPECTED" ]; then
    SURV_VERIFIED=yes
fi
if [ "$SURV_VERIFIED" != yes ]; then
    SURV_ACTUAL_SHA256=$(sha256sum "$SURV_IMAGE") || surv_error 'Cannot read the application runtime from storage.'
    SURV_ACTUAL_SHA256=${SURV_ACTUAL_SHA256%% *}
    [ "$SURV_ACTUAL_SHA256" = "$SURV_EXPECTED_SHA256" ] || \
        surv_error 'The runtime is incomplete or does not match this launcher. Replace the application folder with a fresh copy of the package.'
    SURV_AFTER_ID=$(surv_file_identity "$SURV_IMAGE") || SURV_AFTER_ID=''
    [ "$SURV_AFTER_ID" = "$SURV_IMAGE_ID" ] || \
        surv_error 'The runtime changed while it was being verified. Close other installation tasks and try again.'
    if [ -n "$SURV_IMAGE_ID" ]; then
        # Failure to save this optional cache is harmless: the next
        # launch verifies the whole image again. Never trust a partial
        # receipt left by a power failure.
        SURV_RECEIPT_TEMP=$(mktemp "$SURV_APP_DIR/.runtime-verification.XXXXXX") || SURV_RECEIPT_TEMP=''
        if [ -n "$SURV_RECEIPT_TEMP" ]; then
            if [ ! -d "$SURV_RECEIPT" ] && printf '%s\n' "$SURV_RECEIPT_EXPECTED" > "$SURV_RECEIPT_TEMP"; then
                mv -f "$SURV_RECEIPT_TEMP" "$SURV_RECEIPT" || rm -f "$SURV_RECEIPT_TEMP"
            else
                rm -f "$SURV_RECEIPT_TEMP"
            fi
        fi
    fi
fi

SURV_IS_MOUNTED=no
if mountpoint -q "$SURV_PREFIX"; then
    [ -r "$SURV_PREFIX/10zig-build-id.txt" ] || surv_error 'The runtime mount location is already used by something else. Restart the 10ZiG and try again.'
    [ "$(cat "$SURV_PREFIX/10zig-build-id.txt")" = "$SURV_BUILD_ID" ] || \
        surv_error 'A different version of this runtime is mounted. Restart the 10ZiG before using this package.'
    # A retained mount must refer to the same verified backing file.
    # A new inode, changed metadata, or a mount left by an older launcher
    # requires a fresh mount, even when its build-ID text looks correct.
    if [ -n "$SURV_IMAGE_ID" ] && [ ! -L "$SURV_MOUNT_RECEIPT" ] && \
       [ -f "$SURV_MOUNT_RECEIPT" ] && \
       [ "$(cat "$SURV_MOUNT_RECEIPT" 2>/dev/null)" = "$SURV_RECEIPT_EXPECTED" ]; then
        SURV_IS_MOUNTED=yes
    else
        umount "$SURV_PREFIX" >> "$SURV_LOG" 2>&1 || \
            surv_error 'The previous runtime mount is still in use. Close applications using it or restart the 10ZiG before launching Cameras.'
    fi
fi
if [ "$SURV_IS_MOUNTED" != yes ]; then
    [ ! -L "$SURV_PREFIX" ] || surv_error 'The runtime path is a symbolic link. Installation has stopped.'
    mkdir -p "$SURV_PREFIX" || surv_error 'Cannot create the temporary runtime mount directory.'
    if [ -n "$(ls -A "$SURV_PREFIX")" ]; then
        surv_error 'The temporary runtime directory is not empty. Restart the 10ZiG and try again.'
    fi
    mount -t squashfs -o loop,ro,nodev,nosuid "$SURV_IMAGE" "$SURV_PREFIX" >> "$SURV_LOG" 2>&1 || \
        surv_error 'PeakOS could not mount the read-only application runtime. The mount error is shown below.'
    if [ -n "$SURV_IMAGE_ID" ] && [ ! -d "$SURV_MOUNT_RECEIPT" ]; then
        SURV_MOUNT_TEMP=$(mktemp /tmp/10zig-surveillance-mount.XXXXXX) || SURV_MOUNT_TEMP=''
        if [ -n "$SURV_MOUNT_TEMP" ]; then
            if printf '%s\n' "$SURV_RECEIPT_EXPECTED" > "$SURV_MOUNT_TEMP"; then
                mv -f "$SURV_MOUNT_TEMP" "$SURV_MOUNT_RECEIPT" || rm -f "$SURV_MOUNT_TEMP"
            else
                rm -f "$SURV_MOUNT_TEMP"
            fi
        fi
    fi
fi

# Keep app preferences beside the runtime and cache in RAM, outside the PeakOS config archive.
# Run a child environment; the PeakOS desktop keeps its own libraries and HOME.
env \
    PATH="$SURV_PREFIX/bin:${PATH:-/usr/bin:/bin}" \
    LD_LIBRARY_PATH="$SURV_PREFIX/lib" \
    PYTHONPATH="$SURV_APP" \
    PYTHONNOUSERSITE=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    GI_TYPELIB_PATH="$SURV_PREFIX/lib/girepository-1.0" \
    GSETTINGS_SCHEMA_DIR="$SURV_PREFIX/share/glib-2.0/schemas" \
    XDG_DATA_DIRS="$SURV_PREFIX/share:/usr/local/share:/usr/share" \
    XDG_CONFIG_HOME="$SURV_PROFILE/config" \
    XDG_DATA_HOME="$SURV_PROFILE/data" \
    XDG_STATE_HOME="$SURV_PROFILE/state" \
    XDG_CACHE_HOME=/tmp/10zig-surveillance-cache \
    SURVEILLANCE_CREDENTIAL_STORE=file \
    SURVEILLANCE_MPV_OPTS="${SURVEILLANCE_MPV_OPTS:-hwdec=no}" \
    GDK_BACKEND=x11 \
    GSK_RENDERER=gl \
    GDK_DEBUG=gl-prefer-gl \
    "$SURV_PREFIX/bin/python" -m surveillance "$@" >> "$SURV_LOG" 2>&1
SURV_STATUS=$?
sync
# Keep the verified read-only runtime mounted for the next launch. A
# mount consumes no idle decoder or application process; normal system
# shutdown releases it. Installer runtime replacement handles its own
# unmount while holding the same application lock.
if [ "$SURV_STATUS" -ne 0 ]; then
    surv_error "Surveillance Station stopped with exit code $SURV_STATUS. Its recent messages are shown below."
fi
exit 0
