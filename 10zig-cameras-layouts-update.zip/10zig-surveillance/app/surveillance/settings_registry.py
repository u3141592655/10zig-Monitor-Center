# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Registry of runtime-tunable constants exposed on the Settings page.

Each Setting bridges a plain module-level constant elsewhere in the app
(read fresh on every use there, so reassigning it here takes effect
immediately, no restart needed) to a label/tooltip/default, so the
Settings page can render and reset it generically without knowing
anything about what the constant actually does. Grow the page by adding
a Setting to an existing SettingSection, or a new SettingSection for a
new named subsection.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from surveillance.services import event_backend, live
from surveillance.ui import liveview, mpv_widget, timeline

if TYPE_CHECKING:
    from surveillance.config import AppConfig


@dataclass(frozen=True)
class Setting:
    """One user-configurable numeric constant.

    *get*/*set* read and write the actual live value; *default* is a
    snapshot of the constant's own hardcoded value, captured at import
    time before any persisted override is applied: what "Reset to
    default" restores. *digits* is how many decimals the spinner
    offers; at 0 it only takes whole numbers.
    """

    key: str
    label: str
    tooltip: str
    default: float
    get: Callable[[], float]
    set: Callable[[float], None]
    minimum: float = 0.0
    maximum: float = 100.0
    step: float = 0.1
    digits: int = 2


@dataclass(frozen=True)
class BoolSetting:
    """One user-configurable on/off constant; same *get*/*set*/*default*
    shape as Setting, just bool-valued (rendered as a switch, not a
    spinner)."""

    key: str
    label: str
    tooltip: str
    default: bool
    get: Callable[[], bool]
    set: Callable[[bool], None]


@dataclass(frozen=True)
class ChoiceSetting:
    """One user-configurable choice among fixed values, rendered as a
    dropdown. *options* maps each value to its label, in display order."""

    key: str
    label: str
    tooltip: str
    default: str
    options: dict[str, str]
    get: Callable[[], str]
    set: Callable[[str], None]


@dataclass(frozen=True)
class SettingSection:
    """A named group of settings, e.g. "Media player settings"."""

    title: str
    settings: list[Setting] = field(default_factory=list)
    bool_settings: list[BoolSetting] = field(default_factory=list)
    choice_settings: list[ChoiceSetting] = field(default_factory=list)


def _live_view_choice_settings() -> list[ChoiceSetting]:
    return [
        ChoiceSetting(
            key="live_view_stream_profile",
            label="Live View stream profile",
            tooltip=(
                "Which Surveillance Station stream profile Live View plays "
                'for each camera. "Use camera settings" follows '
                "each camera's own choice in Camera Settings (right-click "
                "it in the sidebar), and otherwise its Live View setting "
                "in Surveillance Station. Any other value applies to every "
                "camera. WebSocket streams only: RTSP always uses the "
                "camera's Live View setting in Surveillance Station."
            ),
            default=live.StreamProfile.CAMERA,
            options={str(k): v for k, v in live.STREAM_PROFILE_LABELS.items()},
            get=live.app_stream_profile,
            set=live.set_app_stream_profile,
        ),
    ]


def _player_settings() -> list[Setting]:
    return [
        Setting(
            key="cache_seconds_default",
            label="Default camera cache size (seconds)",
            tooltip=(
                "Demuxer cache target for a plain RTSP camera stream. "
                "Keep small but not zero to absorb normal "
                "scheduling jitter without audible micro-cuts."
            ),
            default=mpv_widget._CACHE_SECONDS_DEFAULT,
            get=lambda: mpv_widget._CACHE_SECONDS_DEFAULT,
            set=mpv_widget.set_cache_seconds_default,
            maximum=10.0,
        ),
        Setting(
            key="cache_seconds_muxed_audio",
            label="Audio-camera cache size (seconds)",
            tooltip=(
                "Demuxer cache target for a live-piped stream muxed with "
                "real audio. Keep small but not zero to absorb normal "
                "scheduling jitter without audible micro-cuts."
            ),
            default=mpv_widget._CACHE_SECONDS_MUXED_AUDIO,
            get=lambda: mpv_widget._CACHE_SECONDS_MUXED_AUDIO,
            set=mpv_widget.set_cache_seconds_muxed_audio,
            maximum=10.0,
        ),
        Setting(
            key="cache_seconds_low_latency",
            label="Silent-camera cache size (seconds)",
            tooltip=(
                "Demuxer cache target for WebSocket pipes used by cameras "
                "without audio track. Will provide least possible latency "
                "when set to 0."
            ),
            default=mpv_widget._CACHE_SECONDS_LOW_LATENCY,
            get=lambda: mpv_widget._CACHE_SECONDS_LOW_LATENCY,
            set=mpv_widget.set_cache_seconds_low_latency,
            maximum=10.0,
        ),
        Setting(
            key="cache_high_speed_max_seconds",
            label="Max high-speed History cache (seconds)",
            tooltip=(
                "Extra cache on top of a streaming profile's own baseline "
                "at History's fastest (100x) playback speed. DSM delivers "
                "frames proportionally faster at high speed, so a bigger "
                "buffer here keeps a fast rewind from outrunning its "
                "cache. Cache growth between 2x and 100x is exponential."
            ),
            default=mpv_widget._CACHE_HIGH_SPEED_MAX_SECONDS,
            get=lambda: mpv_widget._CACHE_HIGH_SPEED_MAX_SECONDS,
            set=mpv_widget.set_high_speed_cache_max_seconds,
            minimum=1.0,
            maximum=60.0,
            step=1.0,
        ),
        Setting(
            key="demuxer_max_bytes_mib",
            label="Demuxer byte cap (MiB)",
            tooltip=(
                "Byte-size cap on the demuxer cache, same for every "
                "streaming profile above that runs one. Player reads ahead by "
                "whichever of this and the seconds-based cache targets "
                "above is larger, so too small a value here can "
                "bottleneck a cache otherwise sized generously (e.g. the "
                "silent-camera cache at a high History speed)."
            ),
            default=mpv_widget._DEMUXER_MAX_BYTES_MIB,
            get=lambda: mpv_widget._DEMUXER_MAX_BYTES_MIB,
            set=mpv_widget.set_demuxer_max_bytes_mib,
            minimum=1.0,
            maximum=512.0,
            step=1.0,
            digits=0,
        ),
        Setting(
            key="demuxer_max_back_bytes_mib",
            label="Demuxer back buffer cap (MiB)",
            tooltip=(
                "How much already-played video each player keeps for "
                "seeking backwards. Live View never uses it, so a small "
                "value saves a lot of memory on a full grid. Larger "
                "values only help the Recordings player's skip-back, "
                "which otherwise reads the recording again."
            ),
            default=mpv_widget._DEMUXER_MAX_BACK_BYTES_MIB,
            get=lambda: mpv_widget._DEMUXER_MAX_BACK_BYTES_MIB,
            set=mpv_widget.set_demuxer_max_back_bytes_mib,
            minimum=0.0,
            maximum=512.0,
            step=1.0,
            digits=0,
        ),
    ]


def _player_bool_settings() -> list[BoolSetting]:
    return [
        BoolSetting(
            key="osd_enabled",
            label="Show stream cache details overlaid on video",
            tooltip=(
                "Draws a small live readout (cache depth, target, and "
                "effective playback speed) in the corner of each video: "
                "useful for diagnosing buffering or speed-correction "
                "behavior, not needed for normal use."
            ),
            default=mpv_widget._OSD_ENABLED,
            get=lambda: mpv_widget._OSD_ENABLED,
            set=mpv_widget.set_osd_enabled,
        ),
    ]


def _event_bool_settings() -> list[BoolSetting]:
    return [
        BoolSetting(
            key="force_legacy_events",
            label="Decode events as before Surveillance Station 9.3 (testing)",
            tooltip=(
                "Reads events from the recording-interval bitmask the way "
                "Surveillance Station before 9.3 requires, even where the "
                "Event Center is available. For testing that path on a "
                "newer NAS: on 9.3 and later some event types come out "
                "wrong this way. Takes effect at the next login."
            ),
            default=event_backend._FORCE_LEGACY_EVENTS,
            get=lambda: event_backend._FORCE_LEGACY_EVENTS,
            set=event_backend.set_force_legacy_events,
        ),
    ]


def _timeline_settings() -> list[Setting]:
    return [
        Setting(
            key="max_speed_slot_product",
            label="Max limit for (playback speed X number of slots)",
            tooltip=(
                "Ceiling on (playback speed X active grid slots) offered "
                "in the History speed dropdown. DSM delivers that many "
                "times more video per second, on every slot at once, so "
                "too high a product across a full grid can overload the "
                "app. Higher speeds are greyed out on layouts with more "
                "slots to stay under this budget; 1x stays on offer "
                "however low it goes."
            ),
            default=timeline._MAX_SPEED_SLOT_PRODUCT,
            get=lambda: timeline._MAX_SPEED_SLOT_PRODUCT,
            set=timeline.set_max_speed_slot_product,
            minimum=1.0,
            maximum=1000.0,
            step=10.0,
        ),
    ]


def _receipt_settings() -> list[Setting]:
    return [
        Setting(
            key="receipt_scale_percent",
            label="Receipt text size (%)",
            tooltip=(
                "Size of the POS receipt shown over a cashier camera, as a "
                "percentage of the normal overlay text. Lower it for small "
                "tiles in a 3x3 or 4x4 grid."
            ),
            default=liveview._RECEIPT_SCALE_PERCENT,
            get=lambda: liveview._RECEIPT_SCALE_PERCENT,
            set=liveview.set_receipt_scale_percent,
            minimum=liveview.RECEIPT_SCALE_RANGE[0],
            maximum=liveview.RECEIPT_SCALE_RANGE[1],
            step=5.0,
            digits=0,
        ),
        Setting(
            key="receipt_max_lines",
            label="Receipt maximum lines",
            tooltip=(
                "Longest receipt drawn in full. A longer one keeps its "
                "first and last lines (header, total, payment) and folds "
                "the items in between into one line."
            ),
            default=float(liveview._RECEIPT_MAX_LINES),
            get=lambda: float(liveview._RECEIPT_MAX_LINES),
            set=liveview.set_receipt_max_lines,
            minimum=float(liveview.RECEIPT_MAX_LINES_RANGE[0]),
            maximum=float(liveview.RECEIPT_MAX_LINES_RANGE[1]),
            step=1.0,
            digits=0,
        ),
        Setting(
            key="receipt_seconds",
            label="Receipt time on screen (seconds)",
            tooltip=(
                "How long a receipt stays over the video. Receipts older "
                "than this when they reach the app are not shown."
            ),
            default=float(liveview._RECEIPT_SECONDS),
            get=lambda: float(liveview._RECEIPT_SECONDS),
            set=liveview.set_receipt_seconds,
            minimum=float(liveview.RECEIPT_SECONDS_RANGE[0]),
            maximum=float(liveview.RECEIPT_SECONDS_RANGE[1]),
            step=5.0,
            digits=0,
        ),
    ]


def _receipt_bool_settings() -> list[BoolSetting]:
    return [
        BoolSetting(
            key="receipt_enabled",
            label="Show POS receipts over the paired camera",
            tooltip=(
                "Surveillance Station Transactions: each new receipt from a "
                "POS device is drawn over every Live View slot showing the "
                "camera paired with that device. Live view only."
            ),
            default=liveview._RECEIPT_ENABLED,
            get=lambda: liveview._RECEIPT_ENABLED,
            set=liveview.set_receipt_enabled,
        ),
    ]


SECTIONS: list[SettingSection] = [
    SettingSection(title="Live View settings", choice_settings=_live_view_choice_settings()),
    SettingSection(
        title="Media player settings",
        settings=_player_settings(),
        bool_settings=_player_bool_settings(),
    ),
    SettingSection(title="Timeline settings", settings=_timeline_settings()),
    SettingSection(title="Event settings", bool_settings=_event_bool_settings()),
    SettingSection(
        title="POS receipt overlay",
        settings=_receipt_settings(),
        bool_settings=_receipt_bool_settings(),
    ),
]


def apply_persisted_settings(config: AppConfig) -> None:
    """Push every persisted override in *config.setting_overrides* /
    *config.setting_overrides_bool* / *config.setting_overrides_choice*
    onto its live constant. Called once at startup, before any stream
    can start, so a saved value is in effect from the very first camera
    played."""
    for section in SECTIONS:
        for setting in section.settings:
            if setting.key in config.setting_overrides:
                setting.set(config.setting_overrides[setting.key])
        for bool_setting in section.bool_settings:
            if bool_setting.key in config.setting_overrides_bool:
                bool_setting.set(config.setting_overrides_bool[bool_setting.key])
        for choice_setting in section.choice_settings:
            if choice_setting.key in config.setting_overrides_choice:
                choice_setting.set(config.setting_overrides_choice[choice_setting.key])


def update_setting(config: AppConfig, setting: Setting, value: float) -> None:
    """Apply and persist a new value for one setting."""
    setting.set(value)
    config.setting_overrides[setting.key] = value


def update_bool_setting(config: AppConfig, setting: BoolSetting, value: bool) -> None:
    """Apply and persist a new value for one on/off setting."""
    setting.set(value)
    config.setting_overrides_bool[setting.key] = value


def update_choice_setting(config: AppConfig, setting: ChoiceSetting, value: str) -> None:
    """Apply and persist a new value for one dropdown setting."""
    setting.set(value)
    config.setting_overrides_choice[setting.key] = value


def reset_setting(config: AppConfig, setting: Setting) -> None:
    """Apply one setting's default and drop its override.

    Dropped rather than saved back as an explicit value: writing the
    default in would pin today's number in the config file for good, so
    a later release that retunes the constant would never reach anyone
    who had ever pressed Reset.
    """
    setting.set(setting.default)
    config.setting_overrides.pop(setting.key, None)


def reset_bool_setting(config: AppConfig, setting: BoolSetting) -> None:
    """Apply one on/off setting's default and drop its override, for
    the same reason as reset_setting."""
    setting.set(setting.default)
    config.setting_overrides_bool.pop(setting.key, None)


def reset_choice_setting(config: AppConfig, setting: ChoiceSetting) -> None:
    """Apply one dropdown setting's default and drop its override, for
    the same reason as reset_setting."""
    setting.set(setting.default)
    config.setting_overrides_choice.pop(setting.key, None)


def reset_all_settings(config: AppConfig) -> None:
    """Reset every registered setting to its default and persist that."""
    for section in SECTIONS:
        for setting in section.settings:
            reset_setting(config, setting)
        for bool_setting in section.bool_settings:
            reset_bool_setting(config, bool_setting)
        for choice_setting in section.choice_settings:
            reset_choice_setting(config, choice_setting)
