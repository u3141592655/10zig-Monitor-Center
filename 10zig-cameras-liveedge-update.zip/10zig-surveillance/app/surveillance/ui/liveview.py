# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Live view grid for displaying camera streams."""

from __future__ import annotations

import asyncio
import calendar
import logging
import math
import re
import time
from collections.abc import Callable, Coroutine, Iterable, Sequence
from datetime import datetime, timedelta
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")

from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango  # type: ignore[import-untyped]

from surveillance.api.models import Camera, CameraStatus, Event, PtzPatrol, PtzPreset, Recording
from surveillance.config import EventTypeHistory, save_config, save_config_now
from surveillance.services import ptz
from surveillance.services.layout import ServerLayout
from surveillance.services.event import list_recording_presence, merge_intervals
from surveillance.services.event_backend import TypeSignature
from surveillance.services.live import (
    AUDIO_PROTOCOLS,
    OFFLINE_PLACEHOLDER_URL,
    WEBSOCKET_PROTOCOLS,
    StreamProfile,
    effective_layout_profile,
    get_history_view_path,
    get_live_view_path,
)
from surveillance.services.ptt import PttOccupiedError, PttSession
from surveillance.services.recording import (
    download_recording_range,
    fetch_camera_thumbnail_at,
    find_covering_recording_at,
    find_recording_at,
    find_recording_in_range,
)
from surveillance.services.snapshot import download_snapshot, take_and_save_snapshot
from surveillance.services.ws_bridge import MIN_HISTORY_DELTA_SECONDS, WebSocketBridge
from surveillance.ui.fisheye import camera_dewarp
from surveillance.ui.layouts import LAYOUT_VISIBLE, valid_layout
from surveillance.ui.mpv_widget import MpvGLArea, attach_zoom_pan_controls
from surveillance.ui.rtsp_health import RtspHealthMonitor
from surveillance.ui.slot_toolbar import SlotToolbar
from surveillance.ui.timeline import Timeline
from surveillance.util.async_bridge import run_async

if TYPE_CHECKING:
    from surveillance.ui.window import MainWindow

log = logging.getLogger(__name__)

# Internal grid is always 4x4 (16 slots).  Positions: idx = row*4 + col.
_GRID_COLS = 4
_MAX_SLOTS = 16

_TIMELINE_THUMBNAIL_WIDTH = 160
_TIMELINE_THUMBNAIL_HEIGHT = 90

# Gap between each slot's own WS-connect/ffmpeg-spawn burst when many
# slots change Live/History state at once (entering History via a
# timeline click, or returning via the Live button/layout switch) --
# without it, a full 4x4 grid opens 16 new WebSocket connections and
# spawns up to 16 new ffmpeg mux processes in the same GTK main-loop
# iteration, on top of whatever the slots being replaced were still
# using (their own teardown is async -- see CameraSlot.stop_stream --
# so there's a real window where both coexist). Confirmed live: this
# reliably OOM-killed the whole app (and took other running
# applications down with it) before staggering was added; 3x3 (9
# slots) survived unstaggered. Not scientifically tuned -- just small
# enough that a full 4x4 transition (16 * this) still feels immediate.
_HISTORY_TRANSITION_STAGGER_MS = 150

_TIMELINE_NUDGE_SECONDS = 10  # Back 10s / Forward 10s's step size

# Safety net for _flush_timeline_nudge's in-flight tracking: normally
# cleared the moment the focus slot's own recording lookup resolves,
# but that signal can go missing (e.g. the timeline focus slot changes
# mid-lookup) -- without this, a single missed signal would wedge
# Back/Forward 10s shut forever. Generous relative to DSM's observed
# few-second lookup latency, since firing early just means a
# still-accumulating burst of clicks gets flushed a little sooner
# rather than fully coalesced -- never incorrect, just less batched.
_NUDGE_RESOLVE_TIMEOUT_SECONDS = 10

# How long a pan/zoom must settle before the presence bar refetches --
# same technique and rough magnitude as the hover-thumbnail debounce
# (see timeline._THUMBNAIL_DEBOUNCE_MS), just slower since a presence
# fetch covers a whole camera list rather than one hover point.
_PRESENCE_DEBOUNCE_MS = 200

# While following "now" the view changes every tick by design (see
# TimelineCanvas._on_tick), which would otherwise mean a presence
# fetch every second; this caps it to an occasional trailing-edge
# refresh instead.
_PRESENCE_LIVE_REFRESH_SEC = 5.0

# How far Previous/Next event search beyond the events the timeline
# already has, one step at a time: each step only covers time the one
# before it didn't, and the search stops at the first step with an
# event in it (see event_nav_search_windows).
_EVENT_NAV_SEARCH_STEPS = (3600, 86400, 7 * 86400)
# Previous event's grace period (see event_nav_grace_seconds): this
# share of the visible timeline, held to these bounds, before speed.
_EVENT_NAV_GRACE_VIEW_FRACTION = 0.04
_EVENT_NAV_GRACE_MIN_SECONDS = 10.0
_EVENT_NAV_GRACE_MAX_SECONDS = 30.0
# Next event skips events starting this close after the position: a
# seek lands at or just after the event it targets (DSM rounds forward
# onto the next servable frame), which must not find it again.
_EVENT_NAV_NEXT_SKIP_SECONDS = 2.0

# A camera's first-ever event-type scan (see _scan_next_camera_for_
# event_types) can't ask EnumInterval for literally its entire history
# from epoch: confirmed live -- from_time=0 crashes DSM's backend with
# an HTTP 502 (not a client-side timeout) rather than just being slow,
# almost certainly because event_map's 5-second-bucket bookkeeping has
# to cover the whole requested range regardless of how much of it
# actually has data, and a multi-decade range is a few hundred million
# buckets. This cap is comfortably past any real NAS's own storage-
# limited retention without being unbounded -- not a substitute for
# asking DSM what a camera's oldest recording actually is, just
# cheaper than doing so.
_EVENT_TYPE_SCAN_MAX_LOOKBACK_SECONDS = 2 * 365 * 86400


def order_cameras_focus_first(
    cameras: list[tuple[int, str]], focus_camera_id: int | None
) -> list[tuple[int, str]]:
    """Move the entry matching *focus_camera_id* to the front, preserving
    relative order otherwise -- used by _download_available_cameras so the
    Download popover's camera dropdown (which always defaults to position
    0) opens on the camera the timeline is already tracking. A no-op if
    focus_camera_id isn't None but also isn't in *cameras* (e.g. the
    tracked slot is empty)."""
    result = list(cameras)
    if focus_camera_id is None:
        return result
    for i, (camera_id, _name) in enumerate(result):
        if camera_id == focus_camera_id:
            result.insert(0, result.pop(i))
            break
    return result


def event_nav_grace_seconds(speed: float, view_span_seconds: float) -> float:
    """How long after an event's start Previous event still counts as
    "just arrived" and goes on to the event before it, in recording
    seconds. Later than this, Previous returns to the start of the event
    being watched instead.

    A share of the visible timeline, so a wide view skips more, held to
    [_EVENT_NAV_GRACE_MIN_SECONDS, _EVENT_NAV_GRACE_MAX_SECONDS], then
    scaled up with speed: at 16x the same viewing time covers far more
    recording. 1 + ln(speed) grows slower than speed itself and never
    drops below 1, so slow motion keeps the 1x grace period. Events
    starting within this of each other also behave as one: Previous
    skips the whole cluster.
    """
    base = min(
        max(_EVENT_NAV_GRACE_VIEW_FRACTION * view_span_seconds, _EVENT_NAV_GRACE_MIN_SECONDS),
        _EVENT_NAV_GRACE_MAX_SECONDS,
    )
    return base * max(1.0, 1.0 + math.log(speed)) if speed > 0 else base


def pick_nav_target(
    events: Iterable[Event],
    reference: float,
    forward: bool,
    grace_seconds: float,
    latest_start: float,
    reverse: bool,
) -> float | None:
    """Where Previous/Next event (*forward* False/True) should seek to
    from *reference*, or None if no event in *events* qualifies.

    Playing forward, an event is entered at its start. Previous goes to
    the latest start at least *grace_seconds* before *reference* (see
    event_nav_grace_seconds), Next to the earliest more than
    _EVENT_NAV_NEXT_SKIP_SECONDS after it. Playing in reverse it's all
    mirrored: an event is entered at its end, the grace period applies
    to Next (now against the direction of play) and the short skip to
    Previous.

    Events starting after *latest_start* never count: a seek that close
    to wall clock is clamped back to the bridge's near-live floor (see
    WebSocketBridge._set_history_delta), which could otherwise mean
    landing on the same clamped position over and over.
    """
    anchors = [
        float(ev.stop_time if reverse and ev.stop_time else ev.start_time)
        for ev in events
        if ev.start_time <= latest_start
    ]
    if forward:
        if reverse:  # against the direction of play: the grace period
            later = [t for t in anchors if t >= reference + grace_seconds]
        else:
            later = [t for t in anchors if t > reference + _EVENT_NAV_NEXT_SKIP_SECONDS]
        return min(later, default=None)
    if reverse:  # with the direction of play: the short skip
        earlier = [t for t in anchors if t < reference - _EVENT_NAV_NEXT_SKIP_SECONDS]
    else:
        earlier = [t for t in anchors if t <= reference - grace_seconds]
    return max(earlier, default=None)


def event_nav_search_windows(
    reference: float, forward: bool, covered: tuple[float, float] | None, now: float
) -> list[tuple[int, int]]:
    """The (from, to) windows Previous/Next event searches in turn, past
    whatever *covered* range of events the timeline already has, out to
    each of _EVENT_NAV_SEARCH_STEPS from *reference* and never past
    *now*. Each window starts where the one before it ended, so no time
    is searched twice. *covered* only counts if it contains *reference*.
    """
    if covered is not None and not covered[0] <= reference <= covered[1]:
        covered = None
    windows: list[tuple[int, int]] = []
    if forward:
        edge = covered[1] if covered is not None else reference
        for step in _EVENT_NAV_SEARCH_STEPS:
            far = min(reference + step, now)
            if far > edge:
                windows.append((int(edge), int(far)))
                edge = far
    else:
        edge = covered[0] if covered is not None else reference
        for step in _EVENT_NAV_SEARCH_STEPS:
            far = reference - step
            if far < edge:
                windows.append((int(far), int(edge)))
                edge = far
    return windows


def compute_focus_marker_update(
    current_position: float | None,
    last_set_position: float | None,
    active_ticks: Sequence[int | None],
    gap_started_at: float | None,
    gap_reference_position: float,
    now: float,
    speed: str,
    reverse: bool,
) -> tuple[float | None, float | None, float]:
    """Pure decision core of LiveView._advance_focus_history_position --
    see that method's own docstring for the full rationale: the shared
    timeline marker takes whichever active camera actually has real
    data this tick, and only extrapolates from wall clock/speed once
    none of them did.

    Returns (new_position, new_gap_started_at, new_gap_reference_position)
    for the caller to apply to both the marker and its own state.
    new_position is None only when there's genuinely nothing to show yet
    (no real tick has ever arrived and there's no prior position to
    extrapolate from, e.g. History mode was just entered).

    *current_position* != *last_set_position* means something other than
    this function moved the focus slot's position since the last call --
    a seek, a fresh entry into History, or a focus switch onto a slot at
    a different point -- so any extrapolation in progress is measured
    from a now-irrelevant point and must restart from here instead of
    resuming as if a gap had been running since that earlier point.

    While a gap is in progress (gap_started_at is not None), a real tick
    is only trusted if it's at-or-after gap_reference_position -- the
    marker's own position at the moment the gap began. A tick at or
    before that point can only be a stale replay of whatever recording
    just stopped covering the target (e.g. a reconnect that -- absent
    find_covering_recording_at -- resolved back onto it instead of
    finding nothing): this is what actually produces the periodic
    backward jump, even after the extrapolation fallback below already
    handles the general case. Anything at or
    after gap_reference_position is genuine new data -- whether it's the
    actual resuming recording or something in between -- and wins over
    the extrapolated guess even if it lands a little behind where that
    guess had gotten to, same as real data always taking priority once
    it resumes. Outside of an active gap this check is skipped.

    Otherwise, as long as nothing else has moved the position, the marker
    never goes back against the direction of play: slots aren't in step
    (a few seconds apart is common), so when the furthest one delivers no
    frame for a second, the next furthest would pull the marker back.
    LiveView resets that on a direction change the same way as on a
    jump (see _on_timeline_reverse_selected).
    """
    if current_position != last_set_position:
        gap_started_at = None

    best_tick = (
        min((t for t in active_ticks if t is not None), default=None)
        if reverse
        else max((t for t in active_ticks if t is not None), default=None)
    )
    if best_tick is not None and gap_started_at is not None:
        stale = (
            best_tick >= gap_reference_position if reverse else best_tick <= gap_reference_position
        )
        if stale:
            best_tick = None

    if best_tick is not None:
        position = float(best_tick)
        if gap_started_at is None and current_position is not None:
            # Between jumps the marker only moves with the direction of
            # play: the furthest slot can go quiet for a second, and the
            # next furthest is often a few seconds behind it.
            position = (
                min(position, current_position) if reverse else max(position, current_position)
            )
        return position, None, gap_reference_position

    if current_position is None:
        return None, gap_started_at, gap_reference_position

    if gap_started_at is None:
        gap_started_at = now
        gap_reference_position = current_position
    elapsed = now - gap_started_at
    speed_signed = (-1.0 if reverse else 1.0) * float(speed)
    return gap_reference_position + elapsed * speed_signed, gap_started_at, gap_reference_position


# POS receipt overlay (Surveillance Station Transactions), tuned from the
# Settings page (settings_registry). Read fresh on every receipt, so a
# change applies to the next one without a restart.
_RECEIPT_ENABLED = True
_RECEIPT_SCALE_PERCENT = 100.0
_RECEIPT_MAX_LINES = 14
_RECEIPT_SECONDS = 60
# The Settings page's bounds, also held to by a value hand-edited into
# config.toml: a time on screen past GLib's 32-bit limit made
# timeout_add_seconds raise after the receipt was already shown.
RECEIPT_SCALE_RANGE = (25.0, 400.0)
RECEIPT_MAX_LINES_RANGE = (3, 40)
RECEIPT_SECONDS_RANGE = (5, 600)


def set_receipt_enabled(value: bool) -> None:
    global _RECEIPT_ENABLED
    _RECEIPT_ENABLED = value


def set_receipt_scale_percent(value: float) -> None:
    global _RECEIPT_SCALE_PERCENT
    low, high = RECEIPT_SCALE_RANGE
    _RECEIPT_SCALE_PERCENT = min(high, max(low, float(value)))


def set_receipt_max_lines(value: float) -> None:
    global _RECEIPT_MAX_LINES
    low, high = RECEIPT_MAX_LINES_RANGE
    _RECEIPT_MAX_LINES = min(high, max(low, int(value)))


def set_receipt_seconds(value: float) -> None:
    global _RECEIPT_SECONDS
    low, high = RECEIPT_SECONDS_RANGE
    _RECEIPT_SECONDS = min(high, max(low, int(value)))


def receipt_lines(text: str, max_lines: int) -> str:
    """Cap a receipt at *max_lines*, keeping the header and the last
    lines (total, payment, void) and eliding the items in between."""
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    tail = (max_lines - 1) // 2
    head = max_lines - 1 - tail
    hidden = len(lines) - head - tail
    return "\n".join([*lines[:head], f"… {hidden} more lines", *lines[len(lines) - tail :]])


class CameraSlot(Gtk.Box):
    """Self-contained camera slot with a header label, video player, and
    hover-revealed toolbar (see slot_toolbar.SlotToolbar)."""

    def __init__(self, index: int, tls_verify: bool = True) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.index = index
        self._display_index = index
        self.camera: Camera | None = None

        # Header bar (outside GL rendering area)
        self._header = Gtk.Label(label=f"Slot {index + 1}")
        self._header.add_css_class("slot-header")
        self._header.add_css_class("dim-label")
        self._header.add_css_class("caption")
        self._header.set_xalign(0.5)
        self.append(self._header)

        # Video player, muted by default (see clear()/CameraSlot policy —
        # MpvGLArea itself defaults unmuted since PlayerDialog wants that).
        self.player = MpvGLArea(tls_verify=tls_verify)
        self.player.set_vexpand(True)
        self.player.set_hexpand(True)
        self.player.set_mute(True)

        # Overlay instead of appending the player directly so the hover
        # toolbar can float on top of it.
        self._player_overlay = Gtk.Overlay()
        self._player_overlay.set_child(self.player)
        self.append(self._player_overlay)

        self._placeholder = Gtk.Label()
        self._placeholder.set_wrap(True)
        self._placeholder.set_justify(Gtk.Justification.CENTER)
        self._placeholder.set_halign(Gtk.Align.CENTER)
        self._placeholder.set_valign(Gtk.Align.CENTER)
        self._placeholder.set_can_target(False)
        self._placeholder.add_css_class("dim-label")
        self._placeholder.set_visible(False)
        self._player_overlay.add_overlay(self._placeholder)

        self._toolbar = SlotToolbar(index, self.player)
        self._toolbar.set_snapshot_trigger(self._take_snapshot)
        self._player_overlay.add_overlay(self._toolbar)

        # POS receipt (Surveillance Station Transactions) over the top-left
        # of the video, since the hover toolbar owns the bottom edge. Not a
        # pointer target, so hover, zoom/pan and the context menu still
        # reach the player underneath.
        self._receipt = Gtk.Label(xalign=0)
        self._receipt.add_css_class("slot-receipt")
        self._receipt.set_halign(Gtk.Align.START)
        self._receipt.set_valign(Gtk.Align.START)
        self._receipt.set_can_target(False)
        self._receipt.set_visible(False)
        self._player_overlay.add_overlay(self._receipt)
        # An overlay child is never allocated below its minimum size, so
        # a receipt taller than a small tile would run into the next slot.
        self._player_overlay.set_clip_overlay(self._receipt, True)
        self._receipt_hide_id = 0

        # On the player, not the overlay: the toolbar is an overlay child,
        # so a pointer crossing between the two never leaves the overlay
        # and it would emit nothing. Watching the video itself makes that
        # crossing a leave/enter pair the toolbar's own hover tracking
        # already knows how to handle.
        video_hover = Gtk.EventControllerMotion()
        video_hover.connect(
            "enter", lambda *_a: self._toolbar.notify_video_hover_enter(bool(self.camera))
        )
        video_hover.connect("leave", lambda *_a: self._toolbar.notify_video_hover_leave())
        self.player.add_controller(video_hover)

        # Click handlers — one on the header, one on the player.
        # GLArea consumes events so a CAPTURE gesture on the parent Box
        # only works for the first grid cell; direct gestures work for all.
        header_click = Gtk.GestureClick(button=1)
        header_click.connect("pressed", self._on_click)
        self._header.add_controller(header_click)

        # Scroll-to-zoom (centered on the cursor) and click-and-drag pan,
        # shared with the recording player dialog. The player uses a drag
        # gesture instead of a plain click, so a left-button drag can pan a
        # zoomed-in video — a small movement below the threshold is still
        # treated as a click (slot selection).
        attach_zoom_pan_controls(self.player, on_click=self._invoke_click_callback)

        # Right-click context menu — same header/player dual-gesture reason
        # as the left-click handlers above.
        self._menu_popover = Gtk.Popover()
        self._menu_popover.set_has_arrow(False)
        self._menu_popover.set_parent(self)
        menu_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        self._snapshot_menu_btn = Gtk.Button(label="Take Snapshot")
        self._snapshot_menu_btn.add_css_class("flat")
        self._snapshot_menu_btn.connect("clicked", self._on_menu_take_snapshot)
        menu_box.append(self._snapshot_menu_btn)

        self._open_1x1_menu_btn = Gtk.Button(label="Open in 1x1 Layout")
        self._open_1x1_menu_btn.add_css_class("flat")
        self._open_1x1_menu_btn.connect("clicked", self._on_menu_open_1x1)
        menu_box.append(self._open_1x1_menu_btn)

        self._fullscreen_menu_btn = Gtk.Button(label="Full Screen Camera")
        self._fullscreen_menu_btn.add_css_class("flat")
        self._fullscreen_menu_btn.connect("clicked", self._on_menu_fullscreen)
        menu_box.append(self._fullscreen_menu_btn)

        self._reload_menu_btn = Gtk.Button(label="Reload")
        self._reload_menu_btn.add_css_class("flat")
        self._reload_menu_btn.connect("clicked", self._on_menu_reload)
        menu_box.append(self._reload_menu_btn)

        self._clear_menu_btn = Gtk.Button(label="Clear Slot")
        self._clear_menu_btn.add_css_class("flat")
        self._clear_menu_btn.connect("clicked", self._on_menu_clear_slot)
        menu_box.append(self._clear_menu_btn)

        self._menu_popover.set_child(menu_box)

        header_right_click = Gtk.GestureClick(button=3)
        header_right_click.connect("pressed", self._on_right_click)
        self._header.add_controller(header_right_click)

        player_right_click = Gtk.GestureClick(button=3)
        player_right_click.connect("pressed", self._on_right_click)
        self.player.add_controller(player_right_click)

        self._ws_bridge: WebSocketBridge | None = None
        self._rtsp_monitor: RtspHealthMonitor | None = None
        self._ptt_session: PttSession | None = None
        # This slot's current position within History playback, unix
        # time — None whenever it's on Live (or RTSP, which has no
        # History at all). Set on every seek and ticked forward by
        # LiveView's own history-position timer while playing (see
        # _tick_history_positions); read back when this slot becomes
        # the timeline's focus slot, to show its position rather than
        # whichever slot had focus last (see _set_timeline_focus_slot).
        self._history_position: float | None = None
        # Set when a stream gives up while the camera is still reported
        # ENABLED (a transport-level failure, not a status change) — there's
        # no future status transition to retry on, so sync_camera_statuses()
        # retries this slot on every poll instead, until it recovers.
        self._stream_lost = False
        self._click_callback: object = None
        self._status = ""  # stream state shown after the camera name
        # While selected the header asks for a camera, and the status and
        # camera updates below must not write over that prompt.
        self._selected = False
        self._snapshot_callback: object = None
        self._open_1x1_callback: object = None
        self._reload_callback: object = None
        self._clear_slot_callback: object = None
        self._open_1x1_available_callback: object = None
        self._fullscreen_callback: object = None
        self._last_click_time = 0.0

    def set_click_callback(self, callback: object) -> None:
        self._click_callback = callback

    def set_fullscreen_callback(self, callback: object) -> None:
        self._fullscreen_callback = callback

    def set_placeholder(self, text: str) -> None:
        self._placeholder.set_label(text)
        self._placeholder.set_visible(bool(text))

    def set_snapshot_callback(self, callback: object) -> None:
        self._snapshot_callback = callback

    def set_open_1x1_callback(self, callback: object) -> None:
        self._open_1x1_callback = callback

    def set_reload_callback(self, callback: object) -> None:
        self._reload_callback = callback

    def set_clear_slot_callback(self, callback: object) -> None:
        self._clear_slot_callback = callback

    def set_open_1x1_available_callback(self, callback: object) -> None:
        """Callback returning bool: whether "Open in 1x1 Layout" makes
        sense right now (False when the grid is already showing just this
        one slot in 1x1 — there'd be nothing to do)."""
        self._open_1x1_available_callback = callback

    # -- Thin forwarders to the toolbar, keeping LiveView's own call sites
    # unaware of the CameraSlot/SlotToolbar split. --

    def set_volume_changed_callback(self, callback: object) -> None:
        self._toolbar.set_volume_changed_callback(callback)

    def set_saved_volume(self, volume: int) -> None:
        self._toolbar.set_saved_volume(volume)

    def set_mute_changed_callback(self, callback: object) -> None:
        self._toolbar.set_mute_changed_callback(callback)

    def set_saved_mute(self, muted: bool) -> None:
        self._toolbar.set_saved_mute(muted)

    def set_audio_playable(self, playable: bool) -> None:
        self._toolbar.set_audio_playable(playable)

    def set_history_mode(self, is_history: bool) -> None:
        self._toolbar.set_history_mode(is_history)
        if is_history:
            # A live receipt over recorded video would be misleading.
            self.hide_receipt()

    def show_receipt(self, text: str) -> None:
        """Show a POS receipt over the video, live only, sized and timed
        by the Settings page values."""
        if not _RECEIPT_ENABLED or self.camera is None or self._history_position is not None:
            return
        attrs = Pango.AttrList()
        attrs.insert(Pango.attr_scale_new(_RECEIPT_SCALE_PERCENT / 100.0))
        self._receipt.set_attributes(attrs)
        self._receipt.set_text(receipt_lines(text, _RECEIPT_MAX_LINES))
        self._receipt.set_visible(True)
        if self._receipt_hide_id:
            GLib.source_remove(self._receipt_hide_id)
        self._receipt_hide_id = GLib.timeout_add_seconds(_RECEIPT_SECONDS, self._on_receipt_timeout)

    def _on_receipt_timeout(self) -> bool:
        self._receipt_hide_id = 0
        self._receipt.set_visible(False)
        return False

    def hide_receipt(self) -> None:
        if self._receipt_hide_id:
            GLib.source_remove(self._receipt_hide_id)
            self._receipt_hide_id = 0
        self._receipt.set_visible(False)

    def set_mic_callback(self, callback: object) -> None:
        self._toolbar.set_mic_callback(callback)

    def set_mic_active(self, active: bool) -> None:
        self._toolbar.set_mic_active(active)

    def _update_mute_icon(self) -> None:
        self._toolbar.update_mute_icon()

    def set_zoom_callback(self, callback: object) -> None:
        self._toolbar.set_zoom_callback(callback)

    def set_focus_callback(self, callback: object) -> None:
        self._toolbar.set_focus_callback(callback)

    def set_ptz_callback(self, callback: object) -> None:
        self._toolbar.set_ptz_callback(callback)

    def set_preset_callback(self, callback: object) -> None:
        self._toolbar.set_preset_callback(callback)

    def set_patrol_callback(self, callback: object) -> None:
        self._toolbar.set_patrol_callback(callback)

    def set_presets(self, presets: list[PtzPreset]) -> None:
        self._toolbar.set_presets(presets)

    def set_patrols(self, patrols: list[PtzPatrol]) -> None:
        self._toolbar.set_patrols(patrols)

    def _take_snapshot(self) -> None:
        if self._snapshot_callback and callable(self._snapshot_callback):
            self._snapshot_callback(self.index)

    def _on_right_click(self, gesture: Gtk.GestureClick, n_press: int, x: float, y: float) -> None:
        if n_press != 1:
            return
        has_camera = self.camera is not None
        self._snapshot_menu_btn.set_sensitive(has_camera)
        self._reload_menu_btn.set_sensitive(has_camera)
        self._clear_menu_btn.set_sensitive(has_camera)
        self._fullscreen_menu_btn.set_sensitive(has_camera)

        show_open_1x1 = True
        if self._open_1x1_available_callback and callable(self._open_1x1_available_callback):
            show_open_1x1 = self._open_1x1_available_callback()
        self._open_1x1_menu_btn.set_visible(show_open_1x1)
        self._open_1x1_menu_btn.set_sensitive(has_camera)

        widget = gesture.get_widget()
        if widget is not None:
            # Despite gi's stub claiming a (bool, x, y) triple, this
            # actually returns a plain (x, y) tuple at runtime (confirmed
            # directly) — unpacking a third "ok" value here raised
            # ValueError on every right-click, silently aborting before
            # the popover's popup() call below ever ran.
            coords = widget.translate_coordinates(self, x, y)
            if coords is not None:
                px, py = coords
                rect = Gdk.Rectangle()
                rect.x, rect.y, rect.width, rect.height = int(px), int(py), 1, 1
                self._menu_popover.set_pointing_to(rect)
        self._menu_popover.popup()

    def _on_menu_take_snapshot(self, btn: Gtk.Button) -> None:
        self._menu_popover.popdown()
        self._take_snapshot()

    def _on_menu_open_1x1(self, btn: Gtk.Button) -> None:
        self._menu_popover.popdown()
        if self._open_1x1_callback and callable(self._open_1x1_callback):
            self._open_1x1_callback(self.index)

    def _on_menu_reload(self, btn: Gtk.Button) -> None:
        self._menu_popover.popdown()
        if self._reload_callback and callable(self._reload_callback):
            self._reload_callback(self.index)

    def _on_menu_fullscreen(self, _btn: Gtk.Button) -> None:
        self._menu_popover.popdown()
        self._invoke_fullscreen_callback()

    def _invoke_fullscreen_callback(self) -> None:
        if self.camera is not None and callable(self._fullscreen_callback):
            self._fullscreen_callback(self.index)

    def _on_menu_clear_slot(self, btn: Gtk.Button) -> None:
        self._menu_popover.popdown()
        if self._clear_slot_callback and callable(self._clear_slot_callback):
            self._clear_slot_callback(self.index)

    def _on_click(self, gesture: Gtk.GestureClick, n_press: int, x: float, y: float) -> None:
        if n_press == 1:
            self._invoke_click_callback()
        elif n_press == 2:
            self._last_click_time = 0.0
            self._invoke_fullscreen_callback()

    def _invoke_click_callback(self) -> None:
        now = time.monotonic()
        if now - self._last_click_time < 0.35:
            self._last_click_time = 0.0
            self._invoke_fullscreen_callback()
            return
        self._last_click_time = now
        if self._click_callback and callable(self._click_callback):
            self._click_callback(self.index)

    def set_display_index(self, display_idx: int) -> None:
        self._display_index = display_idx
        if not self.camera:
            self._header.set_label(f"Slot {display_idx + 1}")

    def _camera_label(self) -> str:
        """Header text for an assigned camera, with its stream state."""
        name = self.camera.name if self.camera else ""
        return f"{name} ({self._status})" if self._status else name

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        if selected:
            self._header.remove_css_class("dim-label")
            self._header.add_css_class("slot-selected-label")
            self._header.set_label(f"▶ Slot {self._display_index + 1} — click a camera")
        elif self.camera:
            self._header.remove_css_class("slot-selected-label")
            self._header.add_css_class("dim-label")
            self._header.set_label(self._camera_label())
        else:
            self._header.remove_css_class("slot-selected-label")
            self._header.add_css_class("dim-label")
            self._header.set_label(f"Slot {self._display_index + 1}")

    def set_timeline_focus(self, focused: bool) -> None:
        """Toggle the border marking this as the timeline's reference
        camera — independent of set_selected(), which changes the
        header text for the unrelated camera-assignment click flow."""
        if focused:
            self.add_css_class("timeline-focus-frame")
        else:
            self.remove_css_class("timeline-focus-frame")

    def set_status(self, status: str) -> None:
        """Show the stream state next to the camera name, "" once playing."""
        self._status = status
        if self.camera and not self._selected:
            self._header.set_label(self._camera_label())

    def assign(self, camera: Camera) -> None:
        self.set_placeholder("")
        # The toolbar below turns the mic indicator off, so a session
        # left running would go on talking through the previous camera
        # with nothing on screen to say so.
        self.stop_ptt()
        self.hide_receipt()
        self.camera = camera
        self._status = ""
        self._selected = False
        self._header.set_label(camera.name)
        self._header.remove_css_class("slot-selected-label")
        self._header.add_css_class("dim-label")
        self._toolbar.assign(camera)

    def update_camera(self, camera: Camera) -> None:
        """Refresh this slot's camera data (e.g. a status change) without
        resetting stream state or selection UI, unlike assign()."""
        self.camera = camera
        if not self._selected:
            self._header.set_label(self._camera_label())

    def stop_stream(self) -> None:
        """Stop playback, then tear down the WebSocket bridge / RTSP monitor.

        mpv has to let go of the pipe before the bridge closes it. The next
        bridge calls os.pipe() and gets the very same descriptor numbers
        back, so a demuxer still holding the old ones would read the new
        stream out from under it and never decode a frame.
        """
        self.player.stop()
        if self._rtsp_monitor is not None:
            self._rtsp_monitor.stop()
            self._rtsp_monitor = None
        if self._ws_bridge is not None:
            bridge = self._ws_bridge
            self._ws_bridge = None
            bridge.close_write_end()
            run_async(bridge.stop())

    def stop_ptt(self) -> None:
        """End any push-to-talk session on this slot.

        Deliberately separate from stop_stream(): push-to-talk is its own
        audio-out channel to the camera, so a routine video restart (a
        protocol change, a status flap, a new stream URL) must not cut a
        conversation short. Only the paths where the slot itself stops
        being used call this.
        """
        if self._ptt_session is not None:
            self._ptt_session.stop()
            self._ptt_session = None
            self.set_mic_active(False)

    def clear(self) -> None:
        self.set_placeholder("")
        self.stop_stream()
        self.stop_ptt()
        self.hide_receipt()
        self.player.set_dewarp("")
        self.player.reset_zoom()
        self._toolbar.clear()
        self.set_history_mode(False)
        self._history_position = None
        self.camera = None
        self._status = ""
        self._stream_lost = False
        self._selected = False
        self._header.set_label(f"Slot {self._display_index + 1}")
        self._header.remove_css_class("slot-selected-label")
        self._header.add_css_class("dim-label")


class LiveView(Gtk.Box):
    """Live camera view with configurable grid layout."""

    def __init__(self, window: MainWindow) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self.app = window.app
        self._selected_slot: int | None = None
        # Slot whose camera the timeline previews on hover — independent
        # of _selected_slot (that one's for the camera-assignment click
        # flow and can be unset; this one always points at a real slot).
        self._timeline_focus_slot: int = 0
        self._timeline_last_activity: float = 0.0
        # Back/Forward 10s coalescing -- see _flush_timeline_nudge.
        self._pending_nudge_seconds: float = 0.0
        self._nudge_seek_in_flight: bool = False
        # Bumped once per _seek_slot_to_time batch (see _on_timeline_seek)
        # so _on_recording_resolved can tell a lookup superseded by a
        # newer seek -- landing late, after that newer one already
        # applied -- from one still worth acting on.
        self._seek_generation: int = 0
        # Which of those generations each slot's own newest lookup
        # belongs to. Recorded per slot rather than compared against
        # the counter itself, because not every seek covers every slot:
        # _assign_to_slot seeks the one slot it just filled, and if
        # that were allowed to move the shared counter it would
        # supersede a timeline click's whole batch -- which is staggered
        # across slots and so is genuinely still in flight for a couple
        # of seconds -- leaving the rest of the layout on Live while
        # part of it had gone to History.
        self._slot_seek_generation: dict[int, int] = {}
        # Bumped per Previous/Next event click so a slower/older search
        # resolving after a newer one can't undo it -- see
        # _search_event_window.
        self._event_nav_generation: int = 0
        # Whether a Previous/Next search is running, and so whether the
        # timeline shows that button busy -- see _set_event_search_busy.
        self._event_search_running = False
        # One per camera, so its PTZ commands reach the NAS in the order
        # they were sent (see _ptz_in_order).
        self._ptz_locks: dict[int, asyncio.Lock] = {}
        # Bumped per calendar-popover month view so a slower/older
        # availability fetch resolving after a newer one (fast month
        # navigation) can't apply stale marks to the now-different
        # month -- see _on_calendar_availability_fetched.
        self._calendar_generation: int = 0
        # Bumped per Filter-events popover open so a slower/older
        # per-camera history scan resolving after the popover was
        # reopened or cancelled can't keep going or apply stale
        # progress -- see _on_filter_popover_show/_scan_next_camera_
        # for_event_types.
        self._filter_scan_generation: int = 0
        # Selected event-type filter keys (see services.event_backend) --
        # None means "All Event Types", the same no-filtering
        # convention AdvancedSearchDialog's own event-type filter uses.
        # Session-only (not persisted): only the per-camera scan cache
        # (the event backend's type_history) survives a restart.
        self._event_filter_keys: set[str] | None = None
        self._event_filter_match_all: bool = False
        # Timeline Pause/Play's own state -- distinct from
        # _streams_paused below (that one's for navigating away from
        # Live View entirely, this one's a deliberate user action that
        # persists while the page stays open; see _pause_all_slots).
        self._timeline_paused: bool = False
        # Timeline speed dropdown's own state -- DSM's literal
        # multiplier string (see WebSocketBridge.set_speed), applied to
        # every active History slot the same way Pause is, and reset to
        # "1" wherever Pause's own state is (leaving History, switching
        # layout): see _return_all_to_live/_apply_layout.
        self._timeline_speed: str = "1"
        # Timeline Fwd/Rev toggle's own state -- same scope/reset as
        # _timeline_speed (see WebSocketBridge.set_reverse).
        self._timeline_reverse: bool = False
        # _advance_focus_history_position's own state, for extrapolating
        # the shared marker from wall clock/speed when no active camera
        # has delivered a real frame in the last tick: a recording gap
        # or outage covering every active camera at once).
        # None whenever the marker is currently tracking real data.
        # _history_gap_started_at is when that extrapolation began (wall
        # clock, for computing elapsed time each tick, not accumulated
        # tick-by-tick so a delayed GLib tick can't drift it);
        # _history_gap_reference_position is the marker's own position at
        # that moment, the base the extrapolation adds elapsed*speed to;
        # _history_gap_last_set_position is whatever this method itself
        # last wrote, so the next tick can tell a seek/focus-switch moved
        # the focus slot's position out from under it (see the method's
        # own docstring for why that has to restart the extrapolation).
        self._history_gap_started_at: float | None = None
        self._history_gap_reference_position: float = 0.0
        self._history_gap_last_set_position: float | None = None
        # Slots _return_all_to_live has told to leave History, whose old
        # bridge object may still be alive and delivering real ticks until
        # its own staggered restart actually replaces it (that replacement
        # is what clears a slot from this set again -- see _start_bridge).
        # _tick_history_positions/_advance_focus_history_position both skip
        # any slot listed here, since is_history alone can't tell a bridge
        # that is genuinely still in History apart from one that is on its
        # way out but has not been superseded yet -- without this, a real
        # tick from that stale bridge can resurrect a _history_position
        # (and the shared canvas marker, if it lands on the focus slot's
        # tick-collection pass) moments after the return-to-live reset.
        self._leaving_history_slots: set[int] = set()
        self._active: list[int] = []  # physical indices of visible slots
        # Recording-presence cache: camera_id -> (covered_start,
        # covered_end, spans). A view fully within [covered_start,
        # covered_end] is served from cache; anything else triggers a
        # fetch of the view padded by one window's width on each side,
        # which replaces the entry (see _presence_covers/_refresh_timeline_data)
        # -- not a general interval-coverage set, just enough to avoid
        # re-fetching on the small pans/zooms this bar is actually used for.
        # Deliberately NOT consulted at all while following "now" (see
        # _on_timeline_view_changed's force=True) -- a live fetch's own
        # padding reaches past "now" into a future with no recordings
        # yet, so treating that as durable coverage would freeze the
        # trailing edge at whatever was true the first time it was ever
        # fetched, for every camera sharing that cache entry.
        self._presence_cache: dict[int, tuple[float, float, list[tuple[int, int]]]] = {}
        # Event-marker cache, same shape/coverage rules as the presence
        # cache above -- populated together from the same EnumInterval
        # fetch (see _on_timeline_data_fetched), never independently --
        # except that its covered end stops at the time of the request:
        # Previous/Next event trusts it, and a later event is not in it.
        self._event_cache: dict[int, tuple[float, float, list[Event]]] = {}
        self._presence_debounce_id = 0
        # Bumped per fetch batch so a slower-landing fetch superseded by
        # a newer view change never overwrites the cache with stale data
        # -- same technique as _seek_generation/_timeline_thumbnail_generation.
        self._timeline_data_generation = 0
        self._presence_last_live_fetch = 0.0
        # One EnumInterval fetch at a time. The generation above only
        # discards a stale *result*; nothing stopped the requests
        # themselves piling up, and this one is not cheap -- it is the
        # same call services.event gives a 120s timeout because a wide
        # range across many cameras has been seen to outlast the
        # client's own 30s default. While following "now" it is issued
        # on a timer, so a fetch slower than that timer would have
        # stacked without bound. A request wanted while one is in
        # flight is remembered and re-issued when that one settles,
        # rather than dropped: the live-follow path would ask again on
        # its next tick, but a settled pan/zoom (which stops the ticks)
        # would never get another chance.
        self._timeline_fetch_in_flight = False
        self._timeline_fetch_pending: tuple[float, float, bool] | None = None
        self._current_layout: str = valid_layout(self.app.config.grid_layout)
        self._server_layout: ServerLayout | None = None
        self._server_camera_ids: list[int] = []
        self._layout_positions: dict[int, tuple[int, int, int, int]] = {}
        self._presentation_mode = False
        self.fullscreen_focus: int | None = None
        self._layout_stream_generation = 0
        self._slot_stream_requests: dict[int, object] = {}
        # Full live-edge recoveries are staggered and superseded by any
        # later camera/layout/History action, just like ordinary starts.
        self._live_resync_pending: dict[int, object] = {}
        self._live_resync_next_at = 0.0
        self._slot_stream_profiles: dict[int, StreamProfile | None] = {}
        self._cameras: list[Camera] = []  # last known camera list
        self._streams_paused = False  # true while another page is shown

        self.set_hexpand(True)
        self.set_vexpand(True)

        self.layout_notice = Gtk.Label(xalign=0)
        self.layout_notice.set_wrap(True)
        self.layout_notice.set_margin_start(10)
        self.layout_notice.set_margin_end(10)
        self.layout_notice.set_margin_top(6)
        self.layout_notice.set_margin_bottom(6)
        self.layout_notice.add_css_class("dim-label")
        self.layout_notice.set_visible(False)
        self.append(self.layout_notice)

        # Grid container
        self.grid = Gtk.Grid()
        self.grid.add_css_class("live-grid")
        self.grid.set_row_spacing(2)
        self.grid.set_column_spacing(2)
        self.grid.set_row_homogeneous(True)
        self.grid.set_column_homogeneous(True)
        self.grid.set_hexpand(True)
        self.grid.set_vexpand(True)
        self.grid.set_overflow(Gtk.Overflow.HIDDEN)

        # Pre-create all 16 slots (max for 4x4) and attach to the grid.
        # Slots are never removed — only shown/hidden on layout change.
        tls_verify = self.app.api.profile.verify_ssl if self.app.api else True
        self._slots: list[CameraSlot] = []
        for i in range(_MAX_SLOTS):
            r, c = divmod(i, _GRID_COLS)
            slot = CameraSlot(i, tls_verify=tls_verify)
            slot.set_click_callback(self._on_slot_clicked)
            slot.set_fullscreen_callback(self.window.focus_camera_fullscreen)
            slot.set_snapshot_callback(self._on_slot_take_snapshot)
            slot.set_open_1x1_callback(self._on_slot_open_1x1)
            slot.set_reload_callback(self._on_slot_reload)
            slot.set_clear_slot_callback(self._on_slot_clear)
            slot.set_open_1x1_available_callback(lambda: self._current_layout != "1x1")
            slot.set_volume_changed_callback(self._on_slot_volume_changed)
            slot.set_mute_changed_callback(self._on_slot_mute_changed)
            slot.set_mic_callback(self._on_slot_mic_toggle)
            slot.set_zoom_callback(self._on_slot_zoom)
            slot.set_focus_callback(self._on_slot_focus)
            slot.set_ptz_callback(self._on_slot_ptz_move)
            slot.set_preset_callback(self._on_slot_preset)
            slot.set_patrol_callback(self._on_slot_patrol)
            self.grid.attach(slot, c, r, 1, 1)
            self._slots.append(slot)

        # Apply initial layout (show/hide slots)
        self._apply_layout()

        self.timeline = Timeline()
        self.timeline.set_visible(self.app.config.timeline_visible)
        # _apply_layout above ran before this existed, so it could not
        # do this itself.
        self.timeline.set_active_slot_count(len(self._active))
        self.timeline.canvas.set_hover_callback(self._on_timeline_hover)
        self.timeline.canvas.set_hover_leave_callback(self._on_timeline_hover_leave)
        self.timeline.canvas.set_seek_callback(self._on_timeline_seek)
        self.timeline.canvas.set_view_changed_callback(self._on_timeline_view_changed)
        self.timeline.live_btn.connect("clicked", self._on_timeline_live_clicked)
        self.timeline.back_10s_btn.connect("clicked", self._on_timeline_back_10s)
        self.timeline.forward_10s_btn.connect("clicked", self._on_timeline_forward_10s)
        self.timeline.prev_event_btn.connect("clicked", self._on_timeline_prev_event)
        self.timeline.next_event_btn.connect("clicked", self._on_timeline_next_event)
        self.timeline.pause_btn.connect("clicked", self._on_timeline_pause_play)
        self.timeline.set_speed_callback(self._on_timeline_speed_selected)
        self.timeline.set_reverse_callback(self._on_timeline_reverse_selected)
        self.timeline.set_jump_callback(self._on_calendar_jump)
        self.timeline.set_calendar_initial_datetime_callback(self._calendar_initial_datetime)
        self.timeline.set_calendar_month_changed_callback(self._on_calendar_month_changed)
        self.timeline.set_filter_popover_show_callback(self._on_filter_popover_show)
        self.timeline.set_filter_cancel_callback(self._on_filter_cancel)
        self.timeline.set_filter_apply_callback(self._on_filter_apply)
        self.timeline.set_download_populate_callback(self._download_available_cameras)
        self.timeline.set_download_initial_datetime_callback(self._calendar_initial_datetime)
        self.timeline.set_download_callback(self._on_timeline_download)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        content.append(self.grid)
        content.append(self.timeline)

        # A Gtk.Overlay rather than a Gtk.Popover for the hover-preview
        # thumbnail: a popover is a separate native surface, and one
        # positioned to appear over the grid never actually became
        # visible in testing — the grid's video slots are GL-rendered
        # (MpvGLArea) and paint over it regardless of its own reported
        # visible/mapped state. An overlay child is composited in the
        # same render tree as its base, same as each slot's own
        # hover toolbar already floats over its GL video correctly (see
        # CameraSlot._player_overlay) — the same fix applied one level
        # up, spanning the whole grid+timeline rather than one slot.
        self._thumbnail_picture = Gtk.Picture()
        self._thumbnail_picture.set_size_request(
            _TIMELINE_THUMBNAIL_WIDTH, _TIMELINE_THUMBNAIL_HEIGHT
        )
        self._thumbnail_picture.add_css_class("timeline-thumbnail")

        # Date/time overlaid on the thumbnail itself, matching DSM's own
        # hover preview. A second, inner Overlay (its size follows the
        # picture, the base child — the label is just floated on top,
        # same as the picture is floated on the grid+timeline below).
        self._thumbnail_time_label = Gtk.Label()
        self._thumbnail_time_label.add_css_class("timeline-thumbnail-time")
        self._thumbnail_time_label.set_justify(Gtk.Justification.CENTER)
        self._thumbnail_time_label.set_halign(Gtk.Align.CENTER)
        self._thumbnail_time_label.set_valign(Gtk.Align.END)
        self._thumbnail_time_label.set_margin_bottom(4)

        self._thumbnail_frame = Gtk.Overlay()
        self._thumbnail_frame.set_child(self._thumbnail_picture)
        self._thumbnail_frame.add_overlay(self._thumbnail_time_label)
        self._thumbnail_frame.set_halign(Gtk.Align.START)
        self._thumbnail_frame.set_valign(Gtk.Align.START)
        self._thumbnail_frame.set_visible(False)
        # Input-transparent: sitting over the ruler, it would otherwise
        # swallow the very motion events that keep it positioned.
        self._thumbnail_frame.set_can_target(False)
        self._timeline_thumbnail_generation = 0

        self._overlay = Gtk.Overlay()
        self._overlay.set_child(content)
        self._overlay.add_overlay(self._thumbnail_frame)
        # Without this, Gtk.Overlay measures the child within whatever
        # space is left after its margin, shrinking it near the right
        # edge instead of keeping its requested size — our own margin
        # clamp in _show_timeline_thumbnail is what actually keeps it
        # on-screen, so the overlay doesn't need to constrain it too.
        self._overlay.set_clip_overlay(self._thumbnail_frame, False)
        self.append(self._overlay)

        # These tickers run only while this page is on screen, started on
        # map and stopped on unmap like TimelineCanvas's own tick. A page
        # another one covers is unmapped but stays realized, and a login
        # builds a fresh LiveView in place of this one, so a timer bound
        # to nothing would keep the old page alive and ticking for the
        # rest of the process.
        self._focus_idle_id = 0
        self._history_tick_id = 0
        self._live_health_tick_id = 0
        self.connect("map", self._on_map)
        self.connect("unmap", self._on_unmap)

    def _on_map(self, _widget: Gtk.Widget) -> None:
        if not self._focus_idle_id:
            self._focus_idle_id = GLib.timeout_add(1000, self._check_timeline_focus_idle)
        if not self._history_tick_id:
            self._history_tick_id = GLib.timeout_add(1000, self._tick_history_positions)
        if not self._live_health_tick_id:
            self._live_health_tick_id = GLib.timeout_add(1000, self._check_live_latency)

    def _on_unmap(self, _widget: Gtk.Widget) -> None:
        if self._focus_idle_id:
            GLib.source_remove(self._focus_idle_id)
            self._focus_idle_id = 0
        if self._history_tick_id:
            GLib.source_remove(self._history_tick_id)
            self._history_tick_id = 0
        if self._live_health_tick_id:
            GLib.source_remove(self._live_health_tick_id)
            self._live_health_tick_id = 0

    def _check_live_latency(self) -> bool:
        """Poll cached player observations; never issue blocking mpv queries.

        The transport separately watches source-clock/pipe age. Together
        they cover backlog before and after the WebSocket bridge. Raw
        video's synthetic player clock is deliberately not interpreted as
        source time by live_backlog_reason().
        """
        if self._streams_paused or self._timeline_paused or not self.app.api:
            return True
        for index in tuple(self._active):
            slot = self._slots[index]
            if (slot.camera is None or self._history_target(slot) is not None
                    or (slot._ws_bridge is not None and slot._ws_bridge.is_history)):
                continue
            # Retry a notification that arrived just as the user paused.
            # The bridge deliberately keeps its old pipe open until this
            # UI-side stop can run in the safe order.
            bridge_reason = getattr(slot._ws_bridge, "live_lag_reason", "")
            if bridge_reason:
                self._recover_live_slot(index, slot.camera.id, slot._ws_bridge, bridge_reason)
                continue
            reason = slot.player.live_backlog_reason()
            if reason:
                self._recover_live_slot(index, slot.camera.id, slot.player, reason)
        return True

    def _recover_live_slot(
        self, slot_idx: int, cam_id: int, source: object, reason: str
    ) -> bool:
        """Abandon an old live session and obtain a fresh one safely.

        A socket-only reconnect retains stale pipe/mux/player buffers.
        stop_stream() instead stops mpv FIRST, then closes the bridge;
        that ordering avoids exposing raw-pipe EOF to a running player.
        A new URL request then constructs a new bridge, socket and mux.
        """
        if (not reason or self._streams_paused or self._timeline_paused
                or self.app.api is None or slot_idx not in self._active):
            return False
        slot = self._slots[slot_idx]
        if (slot.camera is None or slot.camera.id != cam_id
                or all(source is not item for item in (slot.player, slot._ws_bridge, slot._rtsp_monitor))
                or self._history_target(slot) is not None
                or (slot._ws_bridge is not None and slot._ws_bridge.is_history)
                or slot_idx in self._live_resync_pending):
            return False
        api = self.app.api
        generation = self._layout_stream_generation
        seek_generation = self._slot_seek_generation.get(slot_idx)
        ticket = object()
        self._invalidate_live_start(slot_idx)
        self._slot_stream_requests[slot_idx] = ticket
        self._live_resync_pending[slot_idx] = ticket
        log.warning("Returning camera %s to live: %s", slot.camera.name, reason)
        slot.stop_stream()
        # Keep camera-poll recovery armed if getting the fresh URL fails.
        slot._stream_lost = True
        slot.set_status("returning to live")
        now = time.monotonic()
        start_at = max(now, self._live_resync_next_at)
        self._live_resync_next_at = start_at + _HISTORY_TRANSITION_STAGGER_MS / 1000.0

        def restart() -> bool:
            if self._live_resync_pending.get(slot_idx) is not ticket:
                return False
            self._live_resync_pending.pop(slot_idx, None)
            current = self._slots[slot_idx]
            if (generation == self._layout_stream_generation
                    and self._slot_stream_requests.get(slot_idx) is ticket
                    and self._slot_seek_generation.get(slot_idx) == seek_generation
                    and self.app.api is api and not self._streams_paused
                    and not self._timeline_paused and slot_idx in self._active
                    and current.camera is not None and current.camera.id == cam_id
                    and self._history_target(current) is None
                    and (current._ws_bridge is None or not current._ws_bridge.is_history)):
                self._start_stream(slot_idx, current.camera)
            return False

        delay_ms = max(0, round((start_at - now) * 1000))
        if delay_ms:
            GLib.timeout_add(delay_ms, restart)
        else:
            restart()
        return True

    # ------------------------------------------------------------------
    # Layout management
    # ------------------------------------------------------------------

    def set_layout_notice(self, text: str) -> None:
        self.layout_notice.set_label(text)
        self.layout_notice.set_visible(bool(text) and not self._presentation_mode)

    def _ensure_slot_count(self, count: int) -> None:
        """Grow only when a NAS layout needs more than the original 16 slots."""
        if count > 100:
            raise ValueError("A layout can contain at most 100 channels")
        tls_verify = self.app.api.profile.verify_ssl if self.app.api else True
        while len(self._slots) < count:
            i = len(self._slots)
            slot = CameraSlot(i, tls_verify=tls_verify)
            slot.set_click_callback(self._on_slot_clicked)
            slot.set_fullscreen_callback(self.window.focus_camera_fullscreen)
            slot.set_snapshot_callback(self._on_slot_take_snapshot)
            slot.set_open_1x1_callback(self._on_slot_open_1x1)
            slot.set_reload_callback(self._on_slot_reload)
            slot.set_clear_slot_callback(self._on_slot_clear)
            slot.set_open_1x1_available_callback(lambda: self._current_layout != "1x1")
            slot.set_volume_changed_callback(self._on_slot_volume_changed)
            slot.set_mute_changed_callback(self._on_slot_mute_changed)
            slot.set_mic_callback(self._on_slot_mic_toggle)
            slot.set_zoom_callback(self._on_slot_zoom)
            slot.set_focus_callback(self._on_slot_focus)
            slot.set_ptz_callback(self._on_slot_ptz_move)
            slot.set_preset_callback(self._on_slot_preset)
            slot.set_patrol_callback(self._on_slot_patrol)
            slot.set_visible(False)
            self.grid.attach(slot, 0, 100 + i, 1, 1)
            self._slots.append(slot)

    def _position_slots(self) -> None:
        """Resize existing grid children without destroying their video players."""
        manager = self.grid.get_layout_manager()
        for i, slot in enumerate(self._slots):
            # Shrinking many HD frames is materially more work than
            # presenting one near its native size. Keep the same player
            # and source; use its lightweight scaler only for grid tiles.
            slot.player.set_grid_mode(len(self._active) > 1 and self.fullscreen_focus != i)
            visible = i in self._active and (
                self.fullscreen_focus is None or self.fullscreen_focus == i
            )
            slot.set_visible(visible)
            if not visible:
                continue
            column, row, width, height = (
                (0, 0, 1, 1) if self.fullscreen_focus == i
                else self._layout_positions[i]
            )
            child = manager.get_layout_child(slot)
            child.set_column(column)
            child.set_row(row)
            child.set_column_span(width)
            child.set_row_span(height)
            slot._header.set_visible(not self._presentation_mode)

    def set_presentation_mode(self, enabled: bool) -> None:
        self._presentation_mode = enabled
        if not enabled:
            self.set_fullscreen_focus(None)
        self.timeline.set_visible(not enabled and self.app.config.timeline_visible)
        self.layout_notice.set_visible(not enabled and bool(self.layout_notice.get_label()))
        self._position_slots()

    def set_fullscreen_focus(self, slot_index: int | None) -> None:
        if slot_index is not None and slot_index not in self._active:
            return
        previous = self.fullscreen_focus
        if previous == slot_index:
            return
        self.fullscreen_focus = slot_index
        self._position_slots()
        # Only the enlarged live camera changes quality. Other grid feeds
        # stay running at their grid quality, and recorded playback keeps
        # its position and stream. Esc follows this same path.
        starts: list[tuple[int, Camera]] = []
        for index in dict.fromkeys((previous, slot_index)):
            if index is None or index not in self._active:
                continue
            slot = self._slots[index]
            if (slot.camera is None or self._history_target(slot) is not None
                    or (slot._ws_bridge is not None and slot._ws_bridge.is_history)):
                continue
            if (index not in self._slot_stream_profiles or
                    self._slot_stream_profiles[index] != self._live_profile(index, slot.camera)
                    or not LiveView._ws_audio_policy_matches(self, slot)):
                starts.append((index, slot.camera))
        self._queue_live_starts(starts)

    def set_server_layout(self, layout: ServerLayout) -> None:
        """Display the NAS's camera order and merged cells without changing the NAS."""
        self._save_layout_cameras()
        streaming = frozenset(self._active)
        self._server_layout = layout
        self._current_layout = f"nas:{layout.id}"
        self._server_camera_ids = [tile.camera_id or 0 for tile in layout.tiles]
        self._ensure_slot_count(max(1, len(layout.tiles)))
        self._apply_layout()
        self._restore_layout_cameras(streaming)
        cameras = {camera.id: camera for camera in self.window.sidebar.cameras or self._cameras}
        missing = []
        for index, tile in enumerate(layout.tiles):
            if tile.camera_id is not None and tile.camera_id not in cameras:
                self._slots[index].set_placeholder("Camera unavailable to this account")
                missing.append(str(tile.camera_id))
            elif tile.camera_id is None and tile.label:
                self._slots[index].set_placeholder(tile.label)
        notices = list(layout.warnings)
        if missing:
            notices.append(f"{len(missing)} camera(s) are unavailable to this account.")
        self.set_layout_notice(" ".join(dict.fromkeys(notices)))
        self._save_session()

    def _apply_layout(self) -> None:
        """Show/hide slots to match the current layout."""
        # History mode is scoped to the layout it was entered in -- a
        # switch always leaves it, on every slot, not just ones becoming
        # hidden (see _return_all_to_live). Before self._active changes
        # below, since that's what it reads to know which slots to check.
        self._return_all_to_live()
        # Cancel starts queued for the outgoing layout. In-flight URL
        # replies may be reused only when camera and requested quality
        # still agree (see the callback in _start_stream).
        self._layout_stream_generation += 1
        # Same scoping for a Pause left active: _return_all_to_live has
        # resumed the active slots, and this clears the local mpv pause
        # on every slot in the pool. Slot objects are reused across
        # layout switches, not recreated, and mpv.play() never resets
        # mpv.pause on its own, so a slot paused in the old layout would
        # otherwise show a frozen picture under whatever camera a later
        # layout puts on it, with the toolbar reading "playing".
        self._end_timeline_pause()
        # A seek still resolving belongs to the outgoing layout too. Its
        # lookups land over the next seconds, staggered, and one for a
        # slot this switch hides would open a History session nobody
        # sees, then flip the toolbar into History mode over a layout
        # that is all Live. Forgetting every slot's generation makes each
        # of those results stale on arrival.
        self._slot_seek_generation.clear()
        self.fullscreen_focus = None
        if self._server_layout is not None and self._current_layout.startswith("nas:"):
            self._layout_positions = {
                i: (tile.column, tile.row, tile.column_span, tile.row_span)
                for i, tile in enumerate(self._server_layout.tiles)
            } or {0: (0, 0, 1, 1)}
            new_active = list(self._layout_positions)
        else:
            self._server_layout = None
            new_active = list(LAYOUT_VISIBLE[self._current_layout])
            self._layout_positions = {
                i: (i % _GRID_COLS, i // _GRID_COLS, 1, 1) for i in new_active
            }
        self._select_slot(None)

        # Stop streams on slots that are becoming hidden. Zoom is reset for
        # every slot on every layout switch, not just ones changing camera —
        # deliberately not "remembered per camera" across layouts (unlike
        # DSM's own Monitor Center) since a slot showing the same camera in
        # two layouts wouldn't otherwise get a fresh stream to reset it on.
        # Mute, by contrast, auto-mutes only the slots actually losing
        # visibility here — one staying visible with the same camera
        # shouldn't have its manual mute/volume choice clobbered by an
        # unrelated layout switch. A newly-shown slot gets its camera's
        # mute/volume restored separately, via _restore_saved_audio_state()
        # in _restore_layout_cameras().
        for i, slot in enumerate(self._slots):
            slot.player.reset_zoom()
            if i in new_active:
                slot.set_visible(True)
                display_idx = new_active.index(i)
                slot.set_display_index(display_idx)
            else:
                slot.set_visible(False)
                if slot.camera:
                    slot.player.set_mute(True)
                    slot._update_mute_icon()
                    slot.stop_stream()
                    slot.stop_ptt()
                self._invalidate_live_start(i)

        self._active = new_active
        self._position_slots()
        if hasattr(self, "timeline"):
            # How many slots would decode at once caps the playback
            # speeds on offer -- see Timeline.set_active_slot_count.
            # _return_all_to_live above has already reset the speed to
            # 1x, which every layout allows.
            self.timeline.set_active_slot_count(len(new_active))
        self._set_timeline_focus_slot(new_active[0])

    def register_timeline_activity(self) -> None:
        """Record mouse activity anywhere in the app window.

        Called from MainWindow's window-level motion controller. Keeps
        the current timeline-focus slot's frame lit as long as there's
        been activity within the last 10s, and revives it on the next
        activity even after it's already faded — so moving toward and
        hovering the timeline re-lights whichever slot it previews,
        with nothing timeline-specific needed here to make that happen.
        """
        self._timeline_last_activity = time.time()
        self._slots[self._timeline_focus_slot].set_timeline_focus(True)

    def _check_timeline_focus_idle(self) -> bool:
        if time.time() - self._timeline_last_activity >= 10.0:
            self._slots[self._timeline_focus_slot].set_timeline_focus(False)
        return True  # continue ticking

    def _set_timeline_focus_slot(self, slot_idx: int) -> None:
        if slot_idx != self._timeline_focus_slot:
            self._slots[self._timeline_focus_slot].set_timeline_focus(False)
            self._timeline_focus_slot = slot_idx
            if hasattr(self, "timeline"):
                # __init__ calls _apply_layout() before self.timeline
                # exists, same as _return_all_to_live guards for. Only
                # unreachable today because every layout's first visible
                # slot happens to be the one this starts on, which is
                # not something the rest of this file should depend on.
                #
                # The shared marker follows whichever slot the timeline
                # focuses on (see _set_history_position) — switching
                # focus has to resync it to the new slot's own position,
                # History or not, rather than leaving the previous
                # slot's marker up.
                self.timeline.canvas.set_history_position(self._slots[slot_idx]._history_position)
                # The presence bar's own focus row follows the same switch.
                self._request_presence_refresh()
        self.register_timeline_activity()

    def _tick_history_positions(self) -> bool:
        """Refresh every non-focus slot's History playback position from
        its own bridge's actual last-received frame (see
        WebSocketBridge.current_history_position) rather than assuming
        forward progress ourselves -- a theoretical wall-clock-based
        estimate drifts from real playback at any speed but 1x, since
        DSM needs real time to ramp delivery up (or down) to a new
        rate rather than changing it instantly, and stays wrong
        afterwards for as long as the estimate's own assumptions don't
        match what's actually playing. Skipped for a paused slot: its
        position is frozen by WebSocketBridge.pause() itself.

        The focus slot -- the one the shared timeline marker actually
        shows -- is handled separately, by _advance_focus_history_position:
        a real recording gap in that one camera alone must not freeze
        the shared marker while every other active camera keeps playing,
        so it can't just trust this slot's own bridge the same way the
        others here do. Both skip a slot in _leaving_history_slots
        (see that field's own comment).
        """
        for slot_idx in self._active:
            if slot_idx == self._timeline_focus_slot or slot_idx in self._leaving_history_slots:
                continue
            slot = self._slots[slot_idx]
            if slot._ws_bridge is None or slot._ws_bridge.is_paused:
                continue
            position = slot._ws_bridge.current_history_position
            if position is not None:
                self._set_history_position(slot, position)
        self._advance_focus_history_position()
        return True  # continue ticking

    def _advance_focus_history_position(self) -> None:
        """Update the focus slot's own position (and, via
        _set_history_position, the shared canvas marker) from whichever
        active camera actually delivered real data in the last tick --
        it doesn't matter which one, since every active slot is playing
        toward the same target -- falling back to a wall-clock/speed
        estimate only once every active camera has gone quiet at once:
        a real recording gap in just the focus camera is masked for
        free as long as any other active camera keeps delivering, which
        is the common case and needs no estimation at all, only a
        genuine gap or outage covering the whole layout at
        the same instant ever reaches the fallback below.

        See WebSocketBridge.consume_last_real_tick for why this is safe
        to call once a second across every active bridge without missing
        real data: each one accumulates its own highest tick between
        calls, this just drains and compares them. The actual decision
        is pulled out into compute_focus_marker_update so it's testable
        without a live CameraSlot/WebSocketBridge (GTK widgets segfault
        without a display in this test environment).
        """
        # Only the timeline's own Pause stops the marker: with every slot
        # frozen, the fallback would otherwise estimate it onwards. Not
        # the focus slot losing its History stream: the other slots still
        # play, and the marker follows them.
        if self._timeline_paused:
            return
        focus_slot = self._slots[self._timeline_focus_slot]
        # A focus slot playing live on RTSP or a direct URL has no bridge
        # and no History position. Given one, it would come back in
        # recorded video once its stream gave up (see sync_camera_statuses).
        if focus_slot._ws_bridge is None and focus_slot._history_position is None:
            return

        ticks: list[int | None] = []
        for i in self._active:
            if i in self._leaving_history_slots:
                continue
            bridge = self._slots[i]._ws_bridge
            if bridge is None:
                continue
            ticks.append(bridge.consume_last_real_tick())

        new_position, self._history_gap_started_at, self._history_gap_reference_position = (
            compute_focus_marker_update(
                focus_slot._history_position,
                self._history_gap_last_set_position,
                ticks,
                self._history_gap_started_at,
                self._history_gap_reference_position,
                time.time(),
                self._timeline_speed,
                self._timeline_reverse,
            )
        )
        if new_position is None:
            return  # nothing to extrapolate from yet
        self._set_history_position(focus_slot, new_position)
        self._history_gap_last_set_position = new_position

    def _on_timeline_hover(self, local_x: float, timestamp: float) -> None:
        """TimelineCanvas.set_hover_callback target.

        Empty and offline slots both just mean "no thumbnail" — same as
        fetch_camera_thumbnail_at's own empty-result case for a camera
        with nothing recorded at that time, so nothing further needs to
        distinguish them here.
        """
        camera = self._slots[self._timeline_focus_slot].camera
        if camera is None or not self.app.api:
            self._thumbnail_frame.set_visible(False)
            return

        # PyGObject versions disagree on whether this returns (ok, x, y)
        # or just (x, y) on success / None on failure — handle both
        # rather than pin to whichever shape this system happens to use.
        translated = self.timeline.canvas.translate_coordinates(self._overlay, local_x, 0)
        if translated is None:
            return
        if len(translated) == 3:
            ok, overlay_x, overlay_y = translated
            if not ok:
                return
        else:
            overlay_x, overlay_y = translated

        self._timeline_thumbnail_generation += 1
        generation = self._timeline_thumbnail_generation

        run_async(
            fetch_camera_thumbnail_at(self.app.api, camera.id, int(timestamp)),
            callback=lambda data: self._show_timeline_thumbnail(
                generation, overlay_x, overlay_y, timestamp, data
            ),
            error_callback=lambda exc: log.debug("Timeline thumbnail fetch failed: %s", exc),
        )

    def _on_timeline_hover_leave(self) -> None:
        self._timeline_thumbnail_generation += 1  # orphan any fetch already in flight
        self._thumbnail_frame.set_visible(False)

    # ------------------------------------------------------------------
    # Recording presence and event markers
    # ------------------------------------------------------------------

    def _on_timeline_view_changed(self, start: float, end: float, following: bool) -> None:
        """TimelineCanvas.set_view_changed_callback target.

        Two very different cadences share this one callback: a settled
        pan/zoom (following=False) is debounced like the hover thumbnail,
        but following=True fires on every one-second tick by design (see
        TimelineCanvas._on_tick) and would mean a fetch a second if
        treated the same way -- throttled instead to an occasional
        trailing-edge refresh.
        """
        if following:
            if time.time() - self._presence_last_live_fetch < _PRESENCE_LIVE_REFRESH_SEC:
                return
            self._presence_last_live_fetch = time.time()
            # force=True: see _presence_cache's own comment for why the
            # live-follow path can't rely on the coverage cache.
            self._refresh_timeline_data(start, end, force=True)
            return
        if self._presence_debounce_id:
            GLib.source_remove(self._presence_debounce_id)
        self._presence_debounce_id = GLib.timeout_add(
            _PRESENCE_DEBOUNCE_MS, self._on_presence_debounce_fire, start, end
        )

    def _on_presence_debounce_fire(self, start: float, end: float) -> bool:
        self._presence_debounce_id = 0
        self._refresh_timeline_data(start, end)
        return False  # one-shot timeout, don't repeat

    def _request_presence_refresh(self) -> None:
        """Re-derive presence/events for whatever the timeline's current
        view covers, for a change to which cameras are active/focused
        rather than to the view itself -- see the call sites in
        _set_timeline_focus_slot, _save_session, and
        _restore_layout_cameras.
        """
        if not hasattr(self, "timeline"):
            return  # still constructing -- _apply_layout runs before self.timeline exists
        start, end = self.timeline.canvas.get_view_range()
        self._refresh_timeline_data(start, end)

    def _active_timeline_cameras(self) -> tuple[int | None, list[int]]:
        """(focus_camera_id, active_camera_ids) for the current layout --
        an empty slot contributes nothing to either."""
        active_ids = []
        seen: set[int] = set()
        for i in self._active:
            camera = self._slots[i].camera
            if camera is not None and camera.id not in seen:
                seen.add(camera.id)
                active_ids.append(camera.id)
        focus_camera = self._slots[self._timeline_focus_slot].camera
        return (focus_camera.id if focus_camera else None), active_ids

    def _presence_covers(self, camera_id: int, start: float, end: float) -> bool:
        cached = self._presence_cache.get(camera_id)
        return cached is not None and cached[0] <= start and cached[1] >= end

    def _refresh_timeline_data(self, start: float, end: float, force: bool = False) -> None:
        """Fetch/update presence and event markers for whatever cameras
        are focused/active, for the [start, end] view range. *force*
        skips the cache-coverage check (see _presence_cache's own
        comment for why the live-follow path needs this) -- callers
        other than the live-follow path leave it False so a settled
        pan/zoom over already-covered territory stays a cache hit."""
        if not self.app.api:
            return
        if self._timeline_fetch_in_flight:
            # Coalesced rather than queued: only the newest view
            # matters by the time the in-flight one lands.
            self._timeline_fetch_pending = (start, end, force)
            return
        focus_camera_id, active_camera_ids = self._active_timeline_cameras()
        focus_id_list = [focus_camera_id] if focus_camera_id is not None else []
        all_ids = list(dict.fromkeys([*active_camera_ids, *focus_id_list]))
        if not all_ids:
            self.timeline.canvas.set_presence_data([], [])
            self.timeline.canvas.set_event_markers([], [])
            return

        if force:
            needed = all_ids
        else:
            needed = [cid for cid in all_ids if not self._presence_covers(cid, start, end)]
        if not needed:
            self._apply_timeline_data_to_canvas(focus_camera_id, active_camera_ids)
            return

        # Padded by one window's width on each side so re-panning by up
        # to a screen's worth in either direction stays a cache hit
        # instead of a network round trip -- see _presence_cache's own
        # comment for what this caching scheme deliberately doesn't do.
        pad = end - start
        fetch_start, fetch_end = start - pad, end + pad
        camera_names = {cid: self._camera_name(cid) for cid in needed}

        self._timeline_data_generation += 1
        generation = self._timeline_data_generation
        self._timeline_fetch_in_flight = True
        requested_at = time.time()
        run_async(
            self.app.event_backend.list_presence_and_events(
                self.app.api, needed, camera_names, int(fetch_start), int(fetch_end)
            ),
            callback=lambda result: self._on_timeline_data_fetched(
                generation,
                needed,
                fetch_start,
                fetch_end,
                requested_at,
                result,
                focus_camera_id,
                active_camera_ids,
            ),
            error_callback=self._on_timeline_data_failed,
        )

    def _on_timeline_data_failed(self, exc: BaseException) -> None:
        log.debug("Timeline data fetch failed: %s", exc)
        self._settle_timeline_fetch()

    def _settle_timeline_fetch(self) -> None:
        """Release the one-at-a-time slot and run whatever view change
        arrived while the fetch was out -- see _timeline_fetch_in_flight.
        Called down both the success and the failure path: a failed
        fetch that left the flag set would wedge the presence bar for
        the rest of the session."""
        self._timeline_fetch_in_flight = False
        pending, self._timeline_fetch_pending = self._timeline_fetch_pending, None
        if pending is not None:
            start, end, force = pending
            self._refresh_timeline_data(start, end, force=force)

    def _camera_name(self, camera_id: int) -> str:
        return next((c.name for c in self._cameras if c.id == camera_id), str(camera_id))

    def _on_timeline_data_fetched(
        self,
        generation: int,
        requested_ids: list[int],
        fetch_start: float,
        fetch_end: float,
        requested_at: float,
        result: tuple[dict[int, list[tuple[int, int]]], list[Event]],
        focus_camera_id: int | None,
        active_camera_ids: list[int],
    ) -> None:
        # Applied before the slot is released, not after: releasing it
        # can start the next fetch straight away, and that bumps the
        # generation this result is checked against.
        if generation == self._timeline_data_generation:
            presence, events = result
            events_by_camera: dict[int, list[Event]] = {}
            for ev in events:
                events_by_camera.setdefault(ev.camera_id, []).append(ev)
            for cid in requested_ids:
                self._presence_cache[cid] = (fetch_start, fetch_end, presence.get(cid, []))
                self._event_cache[cid] = (
                    fetch_start,
                    min(fetch_end, requested_at),
                    events_by_camera.get(cid, []),
                )
            self._apply_timeline_data_to_canvas(focus_camera_id, active_camera_ids)
        self._settle_timeline_fetch()

    def _apply_timeline_data_to_canvas(
        self, focus_camera_id: int | None, active_camera_ids: list[int]
    ) -> None:
        focus_spans = (
            self._presence_cache[focus_camera_id][2]
            if focus_camera_id is not None and focus_camera_id in self._presence_cache
            else []
        )
        layout_spans = merge_intervals(
            [
                span
                for cid in active_camera_ids
                for span in self._presence_cache.get(cid, (0.0, 0.0, []))[2]
            ]
        )
        self.timeline.canvas.set_presence_data(focus_spans, layout_spans)

        focus_events = (
            [
                (ev.start_time, ev.stop_time)
                for ev in self._event_cache[focus_camera_id][2]
                if self._event_passes_filter(ev)
            ]
            if focus_camera_id is not None and focus_camera_id in self._event_cache
            else []
        )
        layout_events = [
            (ev.start_time, ev.stop_time)
            for cid in active_camera_ids
            for ev in self._event_cache.get(cid, (0.0, 0.0, []))[2]
            if self._event_passes_filter(ev)
        ]
        self.timeline.canvas.set_event_markers(focus_events, layout_events)

    def _camera_vendor(self, camera_id: int) -> str:
        return next((c.vendor for c in self._cameras if c.id == camera_id), "")

    def _event_passes_filter(self, ev: Event) -> bool:
        """True unless the Filter-events popover has narrowed things
        down and this event's classified type isn't one of the selected
        keys -- see services.event_backend and _on_filter_apply. Applies
        equally to the presence bar's own markers and to Previous/Next
        event navigation, so both always agree on what counts."""
        if self._event_filter_keys is None:
            return True
        vendor = self._camera_vendor(ev.camera_id)
        return self.app.event_backend.matches(
            ev, vendor, self._event_filter_keys, self._event_filter_match_all
        )

    def _on_timeline_prev_event(self, _btn: Gtk.Button) -> None:
        """Timeline's Previous event button -- always live (see
        Timeline._build_toolbar), so a click while on Live drops the
        whole layout into History mode first, the same as Back 10s."""
        self._seek_to_nearest_event(forward=False)

    def _on_timeline_next_event(self, _btn: Gtk.Button) -> None:
        """Timeline's Next event button -- only reachable in History
        mode (see Timeline.set_history_active), so there's always a
        History position to search forward from."""
        self._seek_to_nearest_event(forward=True)

    def _seek_to_nearest_event(self, forward: bool) -> None:
        """Seek the whole layout to the nearest real event before/after
        the focus slot's current position (or "now" if it's on Live),
        across every camera in the active layout -- same scope as the
        presence bar's own layout-accumulated row -- the same way a
        ruler click does, including dropping Live into History. Which
        event counts as nearest, and where in it to land: see
        pick_nav_target and event_nav_grace_seconds.

        Picked from the events the timeline already has when they hold
        one, with no request at all. Only past those does it search, in
        widening steps (event_nav_search_windows), showing the button
        busy meanwhile. A newer click supersedes a search still running.
        """
        if not self.app.api or not self._active:
            return
        _, active_camera_ids = self._active_timeline_cameras()
        if not active_camera_ids:
            return
        reference = self._focus_reference_time()
        view_start, view_end = self.timeline.canvas.get_view_range()
        grace = event_nav_grace_seconds(float(self._timeline_speed), view_end - view_start)
        self._event_nav_generation += 1
        generation = self._event_nav_generation

        covered = self._cached_event_coverage(active_camera_ids)
        if covered is not None and covered[0] <= reference <= covered[1]:
            cached = [
                ev
                for cid in active_camera_ids
                for ev in self._event_cache[cid][2]
                if self._event_passes_filter(ev)
            ]
            target = pick_nav_target(
                cached,
                reference,
                forward,
                grace,
                time.time() - MIN_HISTORY_DELTA_SECONDS,
                self._timeline_reverse,
            )
            if target is not None:
                self._set_event_search_busy(None)
                self._on_timeline_seek(target)
                return
        windows = event_nav_search_windows(reference, forward, covered, time.time())
        self._set_event_search_busy(forward)
        self._search_event_window(generation, forward, reference, grace, active_camera_ids, windows)

    def _set_event_search_busy(self, forward: bool | None) -> None:
        """Show Previous/Next (*forward* False/True) busy on the timeline
        while it searches, or neither for None. Only touches the timeline
        when that changes, so this is safe before the timeline exists."""
        if forward is None and not self._event_search_running:
            return
        self._event_search_running = forward is not None
        self.timeline.set_event_search_busy(forward)

    def _cached_event_coverage(self, camera_ids: list[int]) -> tuple[float, float] | None:
        """The time range the event cache covers for every one of
        *camera_ids* at once, or None if any of them has no entry."""
        entries = [self._event_cache.get(cid) for cid in camera_ids]
        if not all(entries):
            return None
        return (
            max(entry[0] for entry in entries if entry),
            min(entry[1] for entry in entries if entry),
        )

    def _search_event_window(
        self,
        generation: int,
        forward: bool,
        reference: float,
        grace: float,
        camera_ids: list[int],
        windows: list[tuple[int, int]],
    ) -> None:
        """Search the first of *windows* for the event Previous/Next
        should go to, and the rest in turn while none is found."""
        if generation != self._event_nav_generation or not self.app.api:
            return
        if not windows:
            self._set_event_search_busy(None)
            log.info("No %s event found", "next" if forward else "previous")
            return
        (from_time, to_time), rest = windows[0], windows[1:]
        camera_names = {cid: self._camera_name(cid) for cid in camera_ids}

        def _on_listed(events: list[Event]) -> None:
            if generation != self._event_nav_generation:
                return  # a newer click owns the search, and the busy indicator
            target = pick_nav_target(
                (ev for ev in events if self._event_passes_filter(ev)),
                reference,
                forward,
                grace,
                time.time() - MIN_HISTORY_DELTA_SECONDS,
                self._timeline_reverse,
            )
            if target is None:
                self._search_event_window(generation, forward, reference, grace, camera_ids, rest)
                return
            self._set_event_search_busy(None)
            self._on_timeline_seek(target)

        def _on_failed(exc: BaseException) -> None:
            if generation == self._event_nav_generation:
                self._set_event_search_busy(None)
            log.error("Event lookup failed: %s", exc)

        run_async(
            self.app.event_backend.list_events(
                self.app.api, camera_ids, camera_names, from_time, to_time
            ),
            callback=_on_listed,
            error_callback=_on_failed,
        )

    # ------------------------------------------------------------------
    # Calendar jump
    # ------------------------------------------------------------------

    def _calendar_initial_datetime(self) -> datetime:
        """Timeline.set_calendar_initial_datetime_callback target -- the
        popover opens to wherever the focus slot currently is, same
        reference point as Back/Forward 10s and Previous/Next event."""
        return datetime.fromtimestamp(self._focus_reference_time())

    def _on_calendar_jump(self, dt: datetime) -> None:
        """Timeline.set_jump_callback target -- seeks the whole layout
        there the same way a ruler click does, including dropping Live
        into History. No day-existence re-check here: the picker itself
        already refused any day without a layout-accumulated recording
        (see _on_calendar_month_changed), and a specific time of day
        within an available day is deliberately never checked (a click
        landing in a same-day gap is exactly what a ruler click already
        handles -- nearest recording, or nothing found).

        Unlike a ruler click, this can land far outside whatever the
        timeline currently shows -- normalizes zoom and centers the
        view on the target first (see TimelineCanvas.center_on) so the
        jump doesn't leave the marker off-screen, or inherit whatever
        zoom/pan the timeline happened to be left at.
        """
        self.timeline.canvas.center_on(dt.timestamp())
        self._on_timeline_seek(dt.timestamp())

    def _on_calendar_month_changed(self, year: int, month: int) -> None:
        """Timeline.set_calendar_month_changed_callback target -- fetch
        which days of (year, month) have any recording, and the merged
        recording spans themselves, across every camera in the active
        layout, for the picker's own day-existence marking/refusal and
        exact-time Jump validation (see DateTimePicker.
        set_month_availability)."""
        if not self.app.api:
            return
        _, active_camera_ids = self._active_timeline_cameras()
        if not active_camera_ids:
            self.timeline.set_calendar_month_unknown(year, month, "No cameras in this layout")
            return
        month_start = datetime(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        month_end = datetime(year, month, last_day, 23, 59, 59)

        self._calendar_generation += 1
        generation = self._calendar_generation
        run_async(
            list_recording_presence(
                self.app.api,
                active_camera_ids,
                int(month_start.timestamp()),
                int(month_end.timestamp()),
            ),
            callback=lambda result, gen=generation: self._on_calendar_availability_fetched(
                gen, year, month, result
            ),
            error_callback=lambda exc, gen=generation: self._on_calendar_availability_failed(
                gen, year, month, exc
            ),
        )

    def _on_calendar_availability_failed(
        self, generation: int, year: int, month: int, exc: BaseException
    ) -> None:
        log.debug("Calendar availability fetch failed: %s", exc)
        if generation != self._calendar_generation:
            return  # superseded by a newer month view
        self.timeline.set_calendar_month_unknown(
            year, month, "Could not check recordings for this month"
        )

    def _on_calendar_availability_fetched(
        self,
        generation: int,
        year: int,
        month: int,
        result: dict[int, list[tuple[int, int]]],
    ) -> None:
        if generation != self._calendar_generation:
            return  # superseded by a newer month view
        days: set[int] = set()
        all_spans: list[tuple[int, int]] = []
        for spans in result.values():
            all_spans.extend(spans)
            for span_start, span_stop in spans:
                day = datetime.fromtimestamp(span_start).date()
                end_day = datetime.fromtimestamp(span_stop).date()
                while day <= end_day:
                    if day.year == year and day.month == month:
                        days.add(day.day)
                    day += timedelta(days=1)
        self.timeline.set_calendar_month_availability(year, month, days, merge_intervals(all_spans))

    # ------------------------------------------------------------------
    # Download
    # ------------------------------------------------------------------

    def _download_available_cameras(self) -> list[tuple[int, str]]:
        """Timeline.set_download_populate_callback target -- (camera_id,
        name) for every camera actually assigned to a slot in the active
        layout, pulled fresh each time the Download popover opens rather
        than tracked as slots change (see the callback's own docstring).
        The timeline's own tracked camera (see _timeline_focus_slot) comes
        first, so the popover's dropdown -- which always defaults to
        position 0 -- opens on the camera the timeline is already showing,
        the same reference point as the calendar jump and Back/Forward 10s."""
        cameras = list(
            dict.fromkeys(
                (slot.camera.id, slot.camera.name)
                for i, slot in enumerate(self._slots)
                if i in self._active and slot.camera
            )
        )
        focus_camera = self._slots[self._timeline_focus_slot].camera
        return order_cameras_focus_first(cameras, focus_camera.id if focus_camera else None)

    def _on_timeline_download(self, camera_id: int, start: datetime, end: datetime) -> None:
        """Timeline.set_download_callback target -- resolves the covering
        recording for *camera_id* at *start* and streams the [start, end)
        slice to a user-chosen file, mirroring RecordingsView._on_download's
        FileDialog/status/error handling."""
        api = self.app.api
        if not api:
            return
        camera_name = next((c.name for c in self._cameras if c.id == camera_id), str(camera_id))

        dialog = Gtk.FileDialog()
        safe_name = re.sub(r'[/\\<>:"|?*]', "_", camera_name)
        dialog.set_initial_name(f"{safe_name}_{start:%Y%m%d_%H%M%S}.mp4")

        def _on_save(d: Gtk.FileDialog, result: object) -> None:
            try:
                gfile = d.save_finish(result)
            except Exception:
                return  # Cancelled
            if gfile is None:
                return
            path = gfile.get_path()
            if not path or self.app.api is None:
                return

            async def _do_download() -> Path:
                rec = await find_recording_in_range(
                    api, camera_id, start.timestamp(), end.timestamp()
                )
                if rec is None:
                    raise ValueError("No recording found for that camera/time range")
                return await download_recording_range(
                    api, rec, start.timestamp(), end.timestamp(), Path(path)
                )

            def _on_success(p: Path) -> None:
                log.info("Downloaded %s [%s - %s] to %s", camera_name, start, end, p)
                info = Gtk.AlertDialog()
                info.set_message("Download complete")
                info.set_detail(f"Saved to {p}")
                info.set_buttons(["OK"])
                info.show(self.window)

            def _on_error(exc: Exception) -> None:
                log.error("Download failed for %s [%s - %s]: %s", camera_name, start, end, exc)
                err = Gtk.AlertDialog()
                err.set_message("Download failed")
                err.set_detail(f"Could not download from '{camera_name}'.\n\n{exc}")
                err.set_buttons(["OK"])
                err.show(self.window)

            run_async(_do_download(), callback=_on_success, error_callback=_on_error)

        dialog.save(self.window, None, _on_save)

    # ------------------------------------------------------------------
    # Event-type filter
    # ------------------------------------------------------------------

    def _on_filter_popover_show(self) -> None:
        """Timeline.set_filter_popover_show_callback target -- start (or
        restart) the per-camera history scan the Filter-events checklist
        is built from, through the event backend's list_type_signatures,
        one camera at a time and merged into a persisted cache (the
        backend's type_history)
        rather than the presence bar's own short-lived one, so it must
        never be redone for a camera once known, only brought forward
        from wherever it was last checked. See
        AppConfig.legacy_event_type_history's own comment for why
        this is spread out one camera at a time
        (_scan_next_camera_for_event_types) rather than combined into
        one request.
        """
        if not self.app.api:
            return
        _, active_camera_ids = self._active_timeline_cameras()
        self._filter_scan_generation += 1
        generation = self._filter_scan_generation
        fixed = self.app.event_backend.fixed_filter_options()
        if fixed is not None:
            # Every type is known up front: nothing to scan for.
            self._show_filter_options(fixed)
            return
        if not active_camera_ids:
            self._show_filter_options([])
            return
        names = [self._camera_name(cid) for cid in active_camera_ids]
        self.timeline.show_filter_scanning(names)
        self._scan_next_camera_for_event_types(generation, active_camera_ids, 0)

    def _scan_next_camera_for_event_types(
        self, generation: int, camera_ids: list[int], index: int
    ) -> None:
        """One list_type_signatures request per camera, strictly sequential --
        never combined into one multi-camera request, which is what
        risks a timeout on a wide range (see services.event's own
        _ENUM_INTERVAL_REQUEST_TIMEOUT comment), not the per-camera cost
        itself. A camera already in the cache only needs the gap since
        its own checked_until brought forward, not a fresh full scan.
        """
        if generation != self._filter_scan_generation or not self.app.api:
            return
        if index >= len(camera_ids):
            self._finish_event_type_scan(generation, camera_ids)
            return
        camera_id = camera_ids[index]
        history = self.app.event_backend.type_history(self.app.config).get(camera_id)
        now = int(time.time())
        from_time = (
            history.checked_until
            if history is not None
            else now - _EVENT_TYPE_SCAN_MAX_LOOKBACK_SECONDS
        )

        def _on_scanned(signatures: set[TypeSignature]) -> None:
            self._on_camera_event_types_scanned(
                generation, camera_id, index, camera_ids, now, signatures
            )

        def _on_failed(exc: BaseException) -> None:
            self._on_camera_event_type_scan_failed(generation, camera_id, index, camera_ids, exc)

        run_async(
            self.app.event_backend.list_type_signatures(self.app.api, camera_id, from_time, now),
            callback=_on_scanned,
            error_callback=_on_failed,
        )

    def _on_camera_event_types_scanned(
        self,
        generation: int,
        camera_id: int,
        index: int,
        camera_ids: list[int],
        cutoff: int,
        signatures: set[TypeSignature],
    ) -> None:
        if generation != self._filter_scan_generation:
            return  # popover closed/reopened since this camera's scan started
        histories = self.app.event_backend.type_history(self.app.config)
        history = histories.setdefault(camera_id, EventTypeHistory())
        seen = set(history.types)
        seen.update(signatures)
        history.types = sorted(seen)
        history.checked_until = cutoff
        save_config(self.app.config)
        self.timeline.mark_filter_camera_scanned(self._camera_name(camera_id))
        self._scan_next_camera_for_event_types(generation, camera_ids, index + 1)

    def _on_camera_event_type_scan_failed(
        self,
        generation: int,
        camera_id: int,
        index: int,
        camera_ids: list[int],
        exc: BaseException,
    ) -> None:
        if generation != self._filter_scan_generation:
            return
        log.debug("Event-type scan failed for %s: %s", self._camera_name(camera_id), exc)
        # Skip it for this round -- its cache entry (if any) is left
        # untouched, so the next popover open just retries from the
        # same checked_until instead of the whole scan getting stuck.
        self.timeline.mark_filter_camera_scanned(self._camera_name(camera_id))
        self._scan_next_camera_for_event_types(generation, camera_ids, index + 1)

    def _finish_event_type_scan(self, generation: int, camera_ids: list[int]) -> None:
        if generation != self._filter_scan_generation:
            return
        backend = self.app.event_backend
        histories = backend.type_history(self.app.config)
        occurrences: list[tuple[TypeSignature, str]] = []
        for cid in camera_ids:
            history = histories.get(cid)
            if history is None:
                continue
            vendor = self._camera_vendor(cid)
            occurrences.extend((signature, vendor) for signature in history.types)
        self._show_filter_options(backend.filter_options(occurrences))

    def _show_filter_options(self, options: list[tuple[str, str, str]]) -> None:
        supports_match_all = self.app.event_backend.supports_match_all
        self.timeline.show_filter_options(
            options,
            self._event_filter_keys,
            self._event_filter_match_all and supports_match_all,
            show_match_all=supports_match_all,
        )

    def _on_filter_cancel(self) -> None:
        """Timeline.set_filter_cancel_callback target -- fires on any
        popover dismissal (Cancel click, click-outside, Escape; see
        Timeline._on_filter_popover_closed). Bumping the generation is
        enough: every in-flight scan step already checks it before
        doing anything further (see _scan_next_camera_for_event_types
        and friends), so the abandoned chain just stops on its own
        rather than continuing to populate the cache in the
        background."""
        self._filter_scan_generation += 1

    def _on_filter_apply(self, selected_keys: set[str] | None, match_all: bool) -> None:
        """Timeline.set_filter_apply_callback target -- narrows the
        presence bar's own event markers and Previous/Next event
        navigation to the chosen types (see _event_passes_filter).
        Reuses whatever's already cached rather than re-fetching: the
        underlying Event data doesn't change just because the filter
        did."""
        self._event_filter_keys = selected_keys
        self._event_filter_match_all = match_all
        self.timeline.set_filter_active(selected_keys is not None)
        focus_camera_id, active_camera_ids = self._active_timeline_cameras()
        self._apply_timeline_data_to_canvas(focus_camera_id, active_camera_ids)

    def _on_timeline_seek(self, timestamp: float) -> None:
        """TimelineCanvas.set_seek_callback target — seeks every active
        slot with a camera into History mode at *timestamp*, each
        resolving its own camera's covering recording independently.
        The timeline is one shared display, not a shared stream: it
        tells each slot what to play, the same way Live already works.
        Staggered across slots (see _HISTORY_TRANSITION_STAGGER_MS)
        rather than all fired in the same instant.

        One generation (see _seek_generation) for the whole batch, not
        one per slot -- slots within the same batch must not supersede
        each other, only a *later* call to this method should. Stamped
        onto every slot up front rather than as each staggered action
        fires, so a second click landing mid-stagger supersedes the
        whole of the first batch and not just the part of it that had
        got going.

        Also ends a pending Pause, the same as WebSocketBridge.seek()
        does at its own level: a seek is "go here and play", so leaving
        the toolbar showing Play (and every slot's own player still
        locally paused) after this would read as still paused when it
        isn't. The bridges are resumed too, not only the players: a slot
        whose lookup finds no recording keeps the Live bridge it has,
        and one left paused behind an unpaused mpv stays frozen with
        nothing on screen saying so.

        Pans (without changing zoom) to keep the target visible -- see
        TimelineCanvas.ensure_visible -- so Back/Forward 10s and
        Previous/Next event, which can each land outside whatever the
        timeline currently shows, never leave the marker off-screen. A
        no-op for a ruler click, which can only ever target something
        already visible.
        """
        self._resume_all_slots()
        self.timeline.canvas.ensure_visible(timestamp)
        target_unix = int(timestamp)
        self._seek_generation += 1
        generation = self._seek_generation
        for slot_idx in self._active:
            self._slot_seek_generation[slot_idx] = generation
            # Every slot at once, not as each seek lands: a slot whose
            # seek is still waiting its turn keeps playing the old
            # position meanwhile, and its frames would otherwise pull
            # the shared marker back there (see expect_history_position).
            bridge = self._slots[slot_idx]._ws_bridge
            if bridge is not None and bridge.is_history:
                bridge.expect_history_position(target_unix)
        actions: list[Callable[[], None]] = [
            partial(self._seek_slot_to_time, self._slots[slot_idx], target_unix, generation)
            for slot_idx in self._active
        ]
        self._run_staggered(actions)

    def _run_staggered(self, actions: list[Callable[[], None]]) -> None:
        """Run each of *actions* in order, _HISTORY_TRANSITION_STAGGER_MS
        apart across GTK main-loop iterations instead of all in the same
        one -- see that constant for why. The first runs immediately."""
        generation = self._layout_stream_generation
        for i, action in enumerate(actions):
            def run_current(action=action) -> bool:
                if (generation == self._layout_stream_generation and not self._streams_paused):
                    action()
                return False

            if i == 0:
                run_current()
            else:
                GLib.timeout_add(i * _HISTORY_TRANSITION_STAGGER_MS, run_current)

    def _seek_slot_to_time(self, slot: CameraSlot, target_unix: int, generation: int) -> None:
        """Resolve which recording covers *target_unix* for *slot*'s
        camera and enter (or continue) History mode there.

        Shared by _on_timeline_seek (once per active slot on a timeline
        click, all sharing one generation) and _assign_to_slot (a
        camera picked into a slot that was already in History mode
        keeps playing recorded video for the newly picked camera too,
        at the same point in time, rather than silently dropping back
        to live -- its own fresh generation, a batch of one)."""
        if generation != self._slot_seek_generation.get(slot.index):
            # Superseded while waiting its turn in the stagger, by a
            # newer seek or a layout switch: the lookup would only be
            # discarded on arrival, so skip it, but release the nudge
            # tracking the way a discarded result does.
            self._finish_timeline_seek(slot.index)
            return
        if not self.app.api or slot.camera is None:
            return
        api = self.app.api
        camera = slot.camera
        slot_idx = slot.index
        cam_id = camera.id
        run_async(
            find_recording_at(api, camera.id, target_unix),
            callback=lambda rec, i=slot_idx, c=cam_id: self._on_recording_resolved(
                generation, i, c, target_unix, rec
            ),
            error_callback=lambda exc, i=slot_idx, name=camera.name: self._on_history_lookup_failed(
                i, name, exc
            ),
        )

    def _on_history_lookup_failed(
        self, slot_idx: int, camera_name: str, exc: BaseException
    ) -> None:
        log.error("History lookup failed for %s: %s", camera_name, exc)
        self._finish_timeline_seek(slot_idx)

    def _on_recording_resolved(
        self,
        generation: int,
        slot_idx: int,
        cam_id: int,
        target_unix: int,
        recording: Recording | None,
    ) -> None:
        """find_recording_at's result for one slot's seek request.

        Discarded outright if a newer seek has been issued for this
        slot since this lookup started (see _slot_seek_generation) --
        DSM's own per-camera lookup latency varies enough, especially
        across a whole grid, that a burst of clicks/ruler drags can
        otherwise have a stale lookup land *after* a newer one already
        applied, silently snapping a slot back to an earlier position
        and, worse, doing it repeatedly as more stale lookups keep
        trickling in.

        Still calls _finish_timeline_seek even when discarded this
        way: a stale lookup's role as *an* in-flight one for this slot
        is over regardless of whether its own result gets used.
        Skipping that release here stranded a superseded Back/Forward
        10s click until only _NUDGE_RESOLVE_TIMEOUT_SECONDS' safety
        net eventually cleared it, several seconds later than a click
        should ever take to register.
        """
        if generation != self._slot_seek_generation.get(slot_idx):
            self._finish_timeline_seek(slot_idx)
            return
        slot = self._slots[slot_idx]
        if not (slot.camera and slot.camera.id == cam_id):
            self._finish_timeline_seek(slot_idx)
            return
        if recording is None:
            when = time.strftime("%c", time.localtime(target_unix))
            log.info("No recording found near %s for %s", when, slot.camera.name)
            self._finish_timeline_seek(slot_idx)
        elif slot._ws_bridge is not None and slot._ws_bridge.is_history:
            # The recording exists, so this seek supersedes a delayed
            # return-to-Live for the same bridge. Keep the Live request
            # valid when no recording exists: it may be the only pending
            # stream for a camera that was still starting up.
            self._invalidate_live_start(slot_idx)
            self._leaving_history_slots.discard(slot_idx)
            # Already playing recorded video: let the bridge itself decide
            # whether this is a same-recording reseek (reuses the
            # connection) or a jump to a different one (reconnects) — see
            # WebSocketBridge.seek()'s own docstring.
            bridge = slot._ws_bridge
            run_async(
                bridge.seek(recording, target_unix),
                callback=lambda pos, s=slot, i=slot_idx, b=bridge: self._on_bridge_seek_done(
                    generation, s, i, b, pos
                ),
                error_callback=lambda exc, i=slot_idx: self._on_history_seek_failed(slot, i, exc),
            )
        else:
            position = self._enter_history_mode(slot, recording, target_unix)
            self._on_history_seek_applied(slot, slot_idx, position)

    def _on_bridge_seek_done(
        self,
        generation: int,
        slot: CameraSlot,
        slot_idx: int,
        bridge: WebSocketBridge,
        position: int,
    ) -> None:
        """A History bridge's seek() answer. Applied only while that seek
        is still current and the bridge is still the slot's: the Live
        button or a layout switch may have replaced it meanwhile, and its
        position would leave a live slot looking like History."""
        if generation != self._slot_seek_generation.get(slot_idx) or slot._ws_bridge is not bridge:
            self._finish_timeline_seek(slot_idx)
            return
        self._on_history_seek_applied(slot, slot_idx, position)

    def _on_history_seek_applied(self, slot: CameraSlot, slot_idx: int, position: int) -> None:
        """Common tail for _on_recording_resolved's two seek-performing
        branches. *position* may differ from what was requested (see
        WebSocketBridge.seek's/_enter_history_mode's own near-live
        clamp) -- reflecting it here, not the raw click/nudge target,
        is what keeps the on-screen marker and a follow-up Forward 10s
        (whose own reference point is this slot's _history_position)
        from drifting past wall clock click by click."""
        # Where the seek actually landed, which a clamp or the nearest
        # recording can move away from the target the jump asked for.
        if slot._ws_bridge is not None:
            slot._ws_bridge.expect_history_position(position)
        self._set_history_position(slot, position)
        self.timeline.set_history_active(True)
        self._finish_timeline_seek(slot_idx)

    def _on_history_seek_failed(self, slot: CameraSlot, slot_idx: int, exc: BaseException) -> None:
        log.error("History seek failed for %s: %s", slot.camera.name if slot.camera else "?", exc)
        self._finish_timeline_seek(slot_idx)

    def _finish_timeline_seek(self, slot_idx: int) -> None:
        """Whatever a seek's outcome, the focus slot's part in it is
        done -- let any Back/Forward 10s clicks that piled up meanwhile
        fire as one flush (see _flush_timeline_nudge), now that
        _set_history_position (if it ran) has already landed rather
        than still being about to."""
        if slot_idx == self._timeline_focus_slot:
            self._nudge_seek_in_flight = False
            self._flush_timeline_nudge()

    def _set_history_position(self, slot: CameraSlot, position: float | None) -> None:
        """Record *slot*'s own current History playback position (see
        CameraSlot._history_position) and, if *slot* is the timeline's
        current focus slot, push it to the canvas marker too — the two
        can disagree, e.g. a non-focus slot mid-seek, and only the
        focus slot's position is ever what the shared marker shows."""
        slot._history_position = position
        if slot.index == self._timeline_focus_slot:
            self.timeline.canvas.set_history_position(position)

    def _clear_slot(self, slot: CameraSlot) -> None:
        """Clear *slot*, and tell the timeline about it.

        CameraSlot.clear() drops the slot's own History position, but
        the shared canvas marker is LiveView's to update. Without this,
        clearing the slot the timeline happens to be tracking leaves
        its marker, date/time bubble and grey History ruler frozen at
        the last position that slot played, with nothing left running
        to ever move them again -- not even the Live button, which only
        resets slots that still have a History bridge to return.
        """
        self._invalidate_live_start(slot.index)
        slot.clear()
        self._set_history_position(slot, None)
        self._sync_history_active()

    def _sync_history_active(self) -> None:
        """Reflect whether any active slot is still playing recorded
        video.

        The toolbar's History-only controls are switched on by whatever
        seek entered History and off by the Live button. A slot that
        leaves History without going through either -- cleared, dropped
        to the offline card, or restarted live by resume_streams after
        a page switch -- left them on with nothing behind them. A slot
        _return_all_to_live has told to leave is skipped: its old bridge
        stays alive until the staggered replacement lands, and would
        otherwise count as still in History.
        """
        if not hasattr(self, "timeline"):
            return  # still constructing -- see _return_all_to_live
        bridges = (
            self._slots[i]._ws_bridge for i in self._active if i not in self._leaving_history_slots
        )
        self.timeline.set_history_active(any(b is not None and b.is_history for b in bridges))

    def _focus_reference_time(self) -> float:
        """The focus slot's current History position, or wall-clock
        "now" if it's on Live -- shared reference point for Back/Forward
        10s (_flush_timeline_nudge) and Previous/Next event
        (_seek_to_nearest_event)."""
        position = self._slots[self._timeline_focus_slot]._history_position
        return position if position is not None else time.time()

    def _on_timeline_live_clicked(self, _btn: Gtk.Button) -> None:
        """Timeline's Live button — return every slot currently playing
        recorded video back to its normal live stream."""
        self._return_all_to_live()

    def _on_timeline_back_10s(self, _btn: Gtk.Button) -> None:
        """Timeline's Back 10s button — see _nudge_timeline."""
        self._nudge_timeline(-_TIMELINE_NUDGE_SECONDS)

    def _on_timeline_forward_10s(self, _btn: Gtk.Button) -> None:
        """Timeline's Forward 10s button — see _nudge_timeline. Only
        reachable in History mode (see Timeline.set_history_active), so
        there's always a position on the timeline to jump forward from."""
        self._nudge_timeline(_TIMELINE_NUDGE_SECONDS)

    def _nudge_timeline(self, delta_seconds: float) -> None:
        """Accumulate a Back/Forward 10s click and flush it if nothing
        is already in flight. DSM's per-camera recording lookup
        (_seek_slot_to_time) takes long enough that a burst of taps
        would otherwise each fire their own already-stale lookup;
        instead they collapse into whatever the accumulated delta is
        once the previous one lands (_flush_timeline_nudge, triggered
        from _on_recording_resolved)."""
        self._pending_nudge_seconds += delta_seconds
        if not self._nudge_seek_in_flight:
            self._flush_timeline_nudge()

    def _flush_timeline_nudge(self) -> None:
        """Fire one seek for whatever Back/Forward 10s delta has
        accumulated since the last one landed. Marked in flight, via
        the same path _on_timeline_seek already uses (which is also
        what takes every slot into History mode, so clicking Back 10s
        while live drops straight into it), until the focus slot's own
        lookup resolves and calls back in here for anything that
        accumulated meanwhile.

        A target landing within WebSocketBridge's own near-live floor
        is left for it to clamp (see _set_history_delta there) rather
        than caught here and redirected to Live -- Forward 10s stays
        historical navigation like every other seek; the Live button
        right next to it is the deliberate way back to real time."""
        delta, self._pending_nudge_seconds = self._pending_nudge_seconds, 0.0
        if delta == 0 or not self._active:
            return
        target = self._focus_reference_time() + delta
        self._nudge_seek_in_flight = True
        GLib.timeout_add_seconds(_NUDGE_RESOLVE_TIMEOUT_SECONDS, self._on_nudge_resolve_timeout)
        self._on_timeline_seek(target)

    def _on_nudge_resolve_timeout(self) -> bool:
        """Safety net for _flush_timeline_nudge's in-flight tracking —
        see _NUDGE_RESOLVE_TIMEOUT_SECONDS."""
        if self._nudge_seek_in_flight:
            self._nudge_seek_in_flight = False
            self._flush_timeline_nudge()
        return False  # one-shot

    def _on_timeline_pause_play(self, _btn: Gtk.Button) -> None:
        """Timeline's Pause/Play button — a single shared toggle for
        every active slot, the same scope as Back/Forward 10s and
        Live."""
        if self._timeline_paused:
            self._resume_all_slots(apply_resumed_position=True)
        else:
            self._pause_all_slots()

    def _pause_all_slots(self) -> None:
        """Freeze every active slot in place, each per its own current
        mode rather than forcing a shared one -- see
        WebSocketBridge.pause's own docstring for what "freeze" means
        per mode. A Live slot never leaves Live mode just because it's
        paused (see timeline.py's transport-cluster comment for why
        that differs from Back 10s/Previous event)."""
        self._timeline_paused = True
        self.timeline.set_paused(True)
        for slot_idx in self._active:
            slot = self._slots[slot_idx]
            if slot.camera is None:
                continue
            # Bridge and monitor before mpv: see request_pause's own
            # docstring for the write-stall race this closes, and
            # RtspHealthMonitor.set_paused's for the monitor's own
            # version of it, where a frozen time_pos reads as the
            # stream having died.
            self._pause_bridge(slot)
            if slot._rtsp_monitor is not None:
                slot._rtsp_monitor.set_paused(True)
            # The local freeze applies regardless of protocol -- a
            # camera on RTSP/mjpeg/etc. has no _ws_bridge at all, but
            # mpv is still what's rendering it either way.
            slot.player.set_paused(True)

    def _pause_bridge(self, slot: CameraSlot) -> None:
        """Pause *slot*'s bridge: request_pause() synchronously first,
        the rest of pause() on the loop, and a History bridge's frozen
        position reflected on the timeline once it is known."""
        bridge = slot._ws_bridge
        if bridge is None or slot.camera is None:
            return
        bridge.request_pause()
        camera_name = slot.camera.name
        run_async(
            bridge.pause(),
            callback=lambda pos, s=slot: (
                self._set_history_position(s, pos) if pos is not None else None
            ),
            error_callback=lambda exc, name=camera_name: log.error(
                "Pause failed for %s: %s", name, exc
            ),
        )

    def _end_timeline_pause(self) -> None:
        """Drop a timeline Pause without resuming any bridge: the flag,
        the toolbar's icon, and the local mpv pause on every slot in
        the pool, hidden ones included, since mpv.play() never resets
        mpv.pause on its own. For the paths that replace every bridge
        anyway (leaving the page, a layout switch's hidden slots); the
        bridges that stay are _resume_all_slots' business."""
        if self._timeline_paused:
            self._timeline_paused = False
            self.timeline.set_paused(False)
        for slot in self._slots:
            slot.player.set_paused(False)
            if slot._rtsp_monitor is not None:
                slot._rtsp_monitor.set_paused(False)

    def _resume_all_slots(self, *, apply_resumed_position: bool = False) -> None:
        """Undo _pause_all_slots for every active slot. A no-op for the
        bridges when nothing was paused, so every path that must not
        leave a Pause behind can call it without checking first.

        *apply_resumed_position* puts where a History bridge actually
        resumed on the timeline, since that can land later than where
        the pause froze it (WebSocketBridge.resume's own wall-clock
        floor). Only the Play button wants it. The other callers -- the
        Live button, a seek, a layout switch -- settle the position
        themselves, and a resume answers a turn of the main loop later,
        so applying it there would overwrite what they had just decided
        with where playback stood before the resume.
        """
        was_paused = self._timeline_paused
        self._end_timeline_pause()
        if not was_paused:
            return
        for slot_idx in self._active:
            slot = self._slots[slot_idx]
            if slot.camera is None:
                continue
            if slot._ws_bridge is None:
                # Pause can win between stopping a delayed Live pipeline
                # and its staggered restart. Play should restore that tile
                # now, rather than leave it blank until the next NAS poll.
                # Seeks/layout switches settle their own streams instead.
                if (apply_resumed_position and slot._stream_lost
                        and slot._rtsp_monitor is None and not self._streams_paused
                        and self.app.api is not None and self._history_target(slot) is None):
                    self._start_stream(slot_idx, slot.camera)
                continue
            camera_name = slot.camera.name
            run_async(
                slot._ws_bridge.resume(),
                callback=partial(self._apply_resumed_position, slot)
                if apply_resumed_position
                else None,
                error_callback=lambda exc, name=camera_name: log.error(
                    "Resume failed for %s: %s", name, exc
                ),
            )

    def _apply_resumed_position(self, slot: CameraSlot, position: int | None) -> None:
        """Reflect where *slot*'s bridge resumed. None for a Live bridge,
        which has no position of its own."""
        if position is not None:
            self._set_history_position(slot, position)

    def _on_timeline_speed_selected(self, value: str) -> None:
        """Timeline's speed dropdown — applies to every active History
        slot at once, the same scope as Pause/Back/Forward 10s. A Live
        slot has no speed concept (WebSocketBridge.set_speed is a
        no-op for one), so this only actually does anything for slots
        already in History mode."""
        self._timeline_speed = value
        for slot_idx in self._active:
            slot = self._slots[slot_idx]
            if slot.camera is None or slot._ws_bridge is None:
                continue
            camera_name = slot.camera.name
            if slot._ws_bridge.is_history:
                slot.player.set_history_speed(float(value))
            run_async(
                slot._ws_bridge.set_speed(value),
                error_callback=lambda exc, name=camera_name: log.error(
                    "Speed change failed for %s: %s", name, exc
                ),
            )

    def _on_timeline_reverse_selected(self, reverse: bool) -> None:
        """Timeline's Fwd/Rev toggle — same scope/reasoning as
        _on_timeline_speed_selected."""
        self._timeline_reverse = reverse
        # Whatever the marker reached going one way says nothing about the
        # other: let the next tick take the slots' positions as they are,
        # as after a jump (see compute_focus_marker_update).
        self._history_gap_last_set_position = None
        for slot_idx in self._active:
            slot = self._slots[slot_idx]
            if slot.camera is None or slot._ws_bridge is None:
                continue
            camera_name = slot.camera.name
            run_async(
                slot._ws_bridge.set_reverse(reverse),
                error_callback=lambda exc, name=camera_name: log.error(
                    "Direction change failed for %s: %s", name, exc
                ),
            )

    def _return_all_to_live(self) -> None:
        """Return every active slot currently playing recorded video
        back to its normal live stream — shared by the Live button and
        _apply_layout, since History state is scoped to the current
        layout and doesn't carry across a switch to a different one.
        Restarted staggered (see _HISTORY_TRANSITION_STAGGER_MS), not
        all in the same instant, for the same reason _on_timeline_seek
        is.

        __init__ calls _apply_layout() once before self.timeline exists
        (self._active is still empty at that point too, so nothing
        below finds anything to act on either way) — guard rather than
        reorder __init__, since nothing else here depends on
        construction order.
        """
        # A Pause does not survive the return to Live. The History
        # bridges it froze are replaced below, but a Live slot keeps its
        # bridge, and one left paused behind the mpv this unpauses would
        # stay frozen; and mpv itself keeps its pause across play(), so
        # a restarted slot would feed a paused player, which the bridge
        # reads as a stalled pipe and gives up on.
        self._resume_all_slots()
        # A seek, event lookup or queued Back/Forward 10s still out would
        # land after this and put the slots straight back into History.
        self._forget_pending_lookups()
        starts: list[tuple[int, Camera]] = []
        for slot_idx in self._active:
            slot = self._slots[slot_idx]
            if slot.camera and slot._ws_bridge is not None and slot._ws_bridge.is_history:
                self._set_history_position(slot, None)
                self._leaving_history_slots.add(slot_idx)
                starts.append((slot_idx, slot.camera))
            elif self._history_target(slot) is not None:
                # Lost while in History: no bridge to replace, but the
                # position its retry would return to has to go, or the
                # next camera poll puts it straight back in History.
                self._set_history_position(slot, None)
        self._queue_live_starts(starts)
        if hasattr(self, "timeline"):
            self.timeline.set_history_active(False)
            self._reset_playback_speed()
            if starts:
                # Only when something actually left History -- a layout
                # switch while every slot was already Live shouldn't
                # clobber a view the user may have deliberately panned/
                # zoomed while still watching live.
                self.timeline.canvas.reset_view()

    def _forget_pending_lookups(self) -> None:
        """Make every seek and event lookup still out stale on arrival,
        and drop Back/Forward 10s clicks still queued behind them. Left,
        the queue was flushed by the next stale arrival or by
        _on_nudge_resolve_timeout and took every slot back into History."""
        self._slot_seek_generation.clear()
        self._event_nav_generation += 1
        self._set_event_search_busy(None)
        self._pending_nudge_seconds = 0.0

    def _reset_playback_speed(self) -> None:
        """Back to 1x forward, what every return to Live resets the
        History speed and direction to."""
        self._timeline_speed = "1"
        self.timeline.set_speed("1")
        self._timeline_reverse = False
        self.timeline.set_reverse(False)

    def _show_timeline_thumbnail(
        self, generation: int, overlay_x: float, overlay_y: float, timestamp: float, data: bytes
    ) -> None:
        # The cursor may have moved on (or left) while the fetch was in
        # flight — a stale image popping up over wherever it's pointing
        # now would be worse than just not showing one.
        if generation != self._timeline_thumbnail_generation:
            log.debug("Timeline thumbnail: dropped stale response")
            return
        if not data:
            log.debug("Timeline thumbnail: empty response")
            return
        try:
            loader = GdkPixbuf.PixbufLoader()
            loader.write(data)
            loader.close()
            pixbuf = loader.get_pixbuf()
        except Exception as exc:
            log.debug("Timeline thumbnail decode failed: %s", exc)
            return
        if pixbuf is None:
            log.debug("Timeline thumbnail: decoded to no pixbuf")
            return

        # Gtk.Picture's own natural size follows its paintable's native
        # pixel size, not set_size_request()'s minimum — DSM returns a
        # much bigger image (seen: 320x180) than the small preview this
        # is meant to be, and without capping it here the widget renders
        # at that full native size regardless of what's requested, and
        # the margin math below (which assumes the requested size) would
        # then be positioning a box far taller than it actually draws.
        scaled = pixbuf.scale_simple(
            _TIMELINE_THUMBNAIL_WIDTH, _TIMELINE_THUMBNAIL_HEIGHT, GdkPixbuf.InterpType.BILINEAR
        )
        if scaled is None:
            return
        self._thumbnail_picture.set_paintable(Gdk.Texture.new_for_pixbuf(scaled))
        self._thumbnail_time_label.set_label(
            datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d\n%H:%M:%S")
        )
        # Centered horizontally on the cursor, bottom edge resting on
        # the ruler's top edge, clamped to stay within the overlay.
        overlay_width = self._overlay.get_width()
        max_x = overlay_width - _TIMELINE_THUMBNAIL_WIDTH
        x = max(0.0, min(overlay_x - _TIMELINE_THUMBNAIL_WIDTH / 2, max_x))
        y = max(0.0, overlay_y - _TIMELINE_THUMBNAIL_HEIGHT)
        self._thumbnail_frame.set_margin_start(int(x))
        self._thumbnail_frame.set_margin_top(int(y))
        self._thumbnail_frame.set_visible(True)

    def set_layout(self, layout: str) -> None:
        """Switch to *layout*, keeping each layout's camera assignments."""
        if layout == self._current_layout or layout not in LAYOUT_VISIBLE:
            return
        # Save current layout's cameras before switching
        self._save_layout_cameras()
        # The slots streaming under the outgoing layout: a camera the
        # incoming one keeps in the same slot is left running there.
        streaming = frozenset(self._active)
        self._current_layout = layout
        self._server_layout = None
        self._apply_layout()
        # Restore the new layout's saved cameras
        self._restore_layout_cameras(streaming)
        self._save_session()

    def _save_layout_cameras(self) -> None:
        """Save camera assignments for the current layout to config."""
        if self._current_layout.startswith("nas:"):
            return
        cam_ids: list[int] = []
        for i in self._active:
            cam = self._slots[i].camera
            cam_ids.append(cam.id if cam else 0)
        log.debug("layout_cameras save: [%s] = %s", self._current_layout, cam_ids)
        self.app.config.layout_cameras[self._current_layout] = cam_ids

    def _restore_layout_cameras(self, streaming: frozenset[int] = frozenset()) -> None:
        """Restore saved camera assignments for the current layout.

        Layouts are independent: one with no saved assignment starts empty
        rather than inheriting whatever another layout had shown, since the
        16 physical slots are shared behind the scenes across layouts.

        *streaming* names the slots whose stream is current, active under
        the layout just left. One of those already showing the camera
        this layout puts in it is left alone: restarting it blanked the
        slot for a reconnect and spawned another ffmpeg, in the same
        main-loop pass as every other slot's start, which on a switch to
        4x4 is the burst described at _HISTORY_TRANSITION_STAGGER_MS. A
        hidden slot still holds its last camera in memory but no stream,
        so it is not in the set and starts afresh like any other.
        """
        server_layout = self._current_layout.startswith("nas:")
        cam_ids = (self._server_camera_ids if server_layout
                   else self.app.config.layout_cameras.get(self._current_layout, []))
        log.debug("layout_cameras restore: [%s] = %s", self._current_layout, cam_ids)
        # Prefer fresh camera list from sidebar; fall back to locally cached list.
        cameras = self.window.sidebar.cameras or self._cameras
        if not cameras:
            return

        cam_map = {c.id: c for c in cameras}
        seen: set[int] = set()
        starts: list[tuple[int, Camera]] = []
        for i, phys in enumerate(self._active):
            cam_id = cam_ids[i] if i < len(cam_ids) else 0
            if cam_id and cam_id in cam_map and (server_layout or cam_id not in seen):
                seen.add(cam_id)
                shown = self._slots[phys].camera
                if (phys in streaming and shown is not None and shown.id == cam_id
                        and phys in self._slot_stream_profiles
                        and self._slot_stream_profiles[phys] == self._live_profile(phys, shown)
                        and LiveView._ws_audio_policy_matches(self, self._slots[phys])):
                    continue
                cam = cam_map[cam_id]
                # A slot still on screen with another camera goes on playing
                # it under this one's name until the new URL arrives, and
                # for good if that fetch fails.
                self._invalidate_live_start(phys)
                self._slots[phys].stop_stream()
                self._slots[phys].assign(cam)
                self._restore_saved_audio_state(self._slots[phys], cam)
                self._update_slot_audio(self._slots[phys], cam)
                self._load_slot_ptz_extras(self._slots[phys], cam)
                # While another page is shown the streams are paused; keep
                # the assignment current but do not start playback behind
                # the user's back — resume_streams() starts it on return.
                if self._streams_paused:
                    continue
                starts.append((phys, cam))
            else:
                # Saved state says this slot is empty (or a stale duplicate),
                # so clear it explicitly: hidden slots from other layouts keep
                # their camera in memory rather than resetting it.
                self._clear_slot(self._slots[phys])
        self._queue_live_starts(starts)
        # The layout-accumulated row's own camera set just changed.
        self._request_presence_refresh()

    # ------------------------------------------------------------------
    # User interactions
    # ------------------------------------------------------------------

    def confirm_clear_layout(self) -> None:
        """Confirm, then clear all streams and camera assignments in this layout.

        Called from the header bar's grid-layout menu.
        """
        dialog = Gtk.AlertDialog()
        dialog.set_message("Clear all streams in this layout?")
        dialog.set_detail(
            "Every camera assignment in the current grid layout will be removed. "
            "This cannot be undone."
        )
        dialog.set_buttons(["Cancel", "Clear All"])
        dialog.set_cancel_button(0)
        dialog.set_default_button(0)

        def _on_response(d: Gtk.AlertDialog, result: object) -> None:
            try:
                idx = d.choose_finish(result)
            except Exception:
                return
            if idx == 1:
                self._do_clear_all()

        dialog.choose(self.window, None, _on_response)

    def _do_clear_all(self) -> None:
        """Actually clear all streams and camera assignments."""
        for slot in self._slots:
            self._clear_slot(slot)
        self._select_slot(None)
        self._save_session()

    def _on_slot_clicked(self, slot_idx: int) -> None:
        """Select a grid slot, or deselect it if already selected."""
        if slot_idx not in self._active:
            return
        self._set_timeline_focus_slot(slot_idx)
        if self._selected_slot == slot_idx:
            self._select_slot(None)
        else:
            self._select_slot(slot_idx)

    def _select_slot(self, slot_idx: int | None) -> None:
        """Update the selected slot and its visual indicator."""
        if self._selected_slot is not None and self._selected_slot < len(self._slots):
            self._slots[self._selected_slot].set_selected(False)
        self._selected_slot = slot_idx
        if slot_idx is not None and slot_idx < len(self._slots):
            self._slots[slot_idx].set_selected(True)

    def on_camera_selected(self, camera: Camera) -> None:
        """Handle camera selection.

        With a slot selected: assign the camera to that slot.
        Without a slot selected: switch to 1x1 and show only this camera.
        """
        if self._selected_slot is not None:
            self._assign_to_slot(self._selected_slot, camera)
            self._select_slot(None)
        else:
            # Save current layout before switching
            self._save_layout_cameras()
            # Clear visible slots and switch to 1x1
            for i in self._active:
                self._clear_slot(self._slots[i])
            self._current_layout = "1x1"
            self.window.sync_grid_layout("1x1")
            self._apply_layout()
            self._slots[0].assign(camera)
            self._restore_saved_audio_state(self._slots[0], camera)
            self._update_slot_audio(self._slots[0], camera)
            self._load_slot_ptz_extras(self._slots[0], camera)
            self._start_stream(0, camera)
        self._save_session()

    def clear_selected_slot(self) -> None:
        """Clear the camera assigned to the currently selected slot, if any."""
        if self._selected_slot is None:
            return
        self._clear_slot(self._slots[self._selected_slot])
        self._select_slot(None)
        self._save_session()

    def _on_slot_take_snapshot(self, slot_idx: int) -> None:
        """Right-click menu action: take a snapshot of this slot's camera.

        Matches DSM's own "Take Snapshot" behavior: the snapshot is saved
        to the server's snapshot database immediately (so it shows up on
        the Snapshots page) regardless of what happens next, and a Save
        dialog is then offered so the user can optionally also keep a
        local copy — cancelling that dialog does not undo the server-side
        save.
        """
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return

        run_async(
            take_and_save_snapshot(self.app.api, camera.id),
            callback=lambda snapshot_id: self._on_snapshot_taken(camera, snapshot_id),
            error_callback=lambda e: log.error("Snapshot failed: %s", e),
        )

    def _on_snapshot_taken(self, camera: Camera, snapshot_id: int) -> None:
        log.info("Snapshot saved to server (id=%d) for %s", snapshot_id, camera.name)
        if not self.app.api:
            return

        dialog = Gtk.FileDialog()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = re.sub(r'[/\\<>:"|?*]', "_", camera.name)
        dialog.set_initial_name(f"{safe_name}_{timestamp}.jpg")
        snapshot_dir = self.app.config.snapshot_dir
        if snapshot_dir:
            dialog.set_initial_folder(Gio.File.new_for_path(snapshot_dir))

        def _on_save(d: Gtk.FileDialog, result: object) -> None:
            try:
                gfile = d.save_finish(result)
            except Exception:
                return  # Cancelled — snapshot is already saved server-side
            if gfile is None:
                return
            path = gfile.get_path()
            if not path or self.app.api is None:
                return
            run_async(
                download_snapshot(self.app.api, snapshot_id, Path(path)),
                callback=lambda p: log.info("Snapshot also saved locally to %s", p),
                error_callback=lambda e: log.error("Local snapshot save failed: %s", e),
            )

        dialog.save(self.window, None, _on_save)

    def _restore_saved_audio_state(self, slot: CameraSlot, camera: Camera) -> None:
        """Restore *camera*'s persisted volume and mute state into *slot*.

        Mute still auto-mutes whenever a camera loses visibility (see
        clear(), _apply_layout(), pause_streams()) — this is the other
        half: called wherever a camera *gains* visibility, restoring
        whatever it was set to rather than a fixed default.
        """
        volume = self.app.config.camera_volume.get(camera.id, 50)
        slot.set_saved_volume(volume)
        muted = self.app.config.camera_muted.get(camera.id, True)
        slot.set_saved_mute(muted)

    def _update_slot_audio(self, slot: CameraSlot, camera: Camera) -> None:
        """Tell *slot* whether audio can reach the player for *camera*
        right now.

        Having an audio track is not enough: it also has to arrive over a
        protocol that carries one. The RTSP-family protocols (see
        AUDIO_PROTOCOLS) settle this immediately. The WebSocket-family
        protocols ("auto", "websocket") get an optimistic has_audio-based
        guess instead: real audio muxing (see ws_bridge.py) only kicks in
        once DSM's codec-info frame confirms a codec we can actually mux
        (PCMU or AAC), so _start_ws_bridge's _on_ready corrects this down
        for a camera whose audio codec turns out not to be one of those,
        once that's actually known. mjpeg never carries audio.
        """
        protocol = self.app.config.camera_protocols.get(camera.id, "auto")
        playable = camera.has_audio and (
            protocol in AUDIO_PROTOCOLS or protocol in ("auto", "websocket")
        )
        slot.set_audio_playable(playable)

    def _load_slot_ptz_extras(self, slot: CameraSlot, camera: Camera) -> None:
        """Populate *slot*'s Preset/Patrol dropdowns for *camera* — only
        PTZ cameras have either.

        Both lists are dropped if the slot has moved on to another camera
        by the time they arrive: picking an entry acts on whichever camera
        the slot holds now, so a stale list would aim one camera's presets
        at another. Same check as _on_stream_url().
        """
        if not camera.is_ptz or not self.app.api:
            return
        cam_id = camera.id

        def _still_current() -> bool:
            return bool(slot.camera and slot.camera.id == cam_id)

        def _apply_presets(presets: list[PtzPreset]) -> None:
            if _still_current():
                slot.set_presets(presets)

        def _apply_patrols(patrols: list[PtzPatrol]) -> None:
            if _still_current():
                slot.set_patrols(patrols)

        run_async(
            ptz.list_presets(self.app.api, camera.id),
            callback=_apply_presets,
            error_callback=lambda e: log.error("PTZ list_presets failed: %s", e),
        )
        run_async(
            ptz.list_patrols(self.app.api, camera.id),
            callback=_apply_patrols,
            error_callback=lambda e: log.error("PTZ list_patrols failed: %s", e),
        )

    def _on_slot_mute_changed(self, slot_idx: int, muted: bool) -> None:
        slot = self._slots[slot_idx]
        camera = slot.camera
        if not camera:
            return
        self.app.config.camera_muted[camera.id] = muted
        save_config(self.app.config)
        # A muted Live grid tile bypasses audio demux/resample/remux. When
        # sound is requested again, only this camera obtains a fresh
        # audio-capable pipeline; never deselect a running muxer's track.
        if (self.app.api is not None and not self._streams_paused
                and slot_idx in self._active and slot._ws_bridge is not None
                and not slot._ws_bridge.is_history
                and not LiveView._ws_audio_policy_matches(self, slot)):
            self._on_slot_reload(slot_idx)

    def _on_slot_volume_changed(self, slot_idx: int, volume: int) -> None:
        camera = self._slots[slot_idx].camera
        if not camera:
            return
        self.app.config.camera_volume[camera.id] = volume
        save_config(self.app.config)

    def _on_slot_mic_toggle(self, slot_idx: int, active: bool) -> None:
        slot = self._slots[slot_idx]
        if not active:
            if slot._ptt_session is not None:
                slot._ptt_session.stop()
                slot._ptt_session = None
            return

        camera = slot.camera
        if not camera or not self.app.api:
            slot.set_mic_active(False)
            return

        session = PttSession(camera.id)
        slot._ptt_session = session
        run_async(
            session.run(self.app.api),
            error_callback=lambda e, s=slot, sess=session: self._on_ptt_ended(s, sess, e),
        )

    def _on_ptt_ended(self, slot: CameraSlot, session: PttSession, exc: BaseException) -> None:
        """A push-to-talk session ended on its own (occupied camera, dropped
        connection, ...) rather than the user tapping to stop.

        stop() only sets an event the send loop polls, so a session still in
        the handshake keeps running and can raise long after the user tapped
        off: check_occupied() reports an occupied camera without rechecking
        the flag, and connect() has its own timeout. By then the slot may
        already own a newer session, so the failure has to be matched against
        the session that produced it before anything is cleared.
        """
        if slot._ptt_session is not session:
            return  # a newer session owns the mic now
        if isinstance(exc, PttOccupiedError):
            log.info("Push-to-talk: %s", exc)
        else:
            log.error("Push-to-talk session ended: %s", exc)
        slot._ptt_session = None
        slot.set_mic_active(False)

    async def _ptz_in_order(self, camera_id: int, command: Coroutine[Any, Any, Any]) -> Any:
        """Run one PTZ *command* for *camera_id* after the ones sent
        before it. Each used to be its own task, so a Start and its Stop
        raced: after an expired session each logs in again on its own,
        and the Stop could reach the NAS first and leave the motor
        running. asyncio.Lock wakes its waiters in the order they came."""
        lock = self._ptz_locks.setdefault(camera_id, asyncio.Lock())
        async with lock:
            return await command

    def _on_slot_ptz_move(self, slot_idx: int, direction: str, move_type: str) -> None:
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return
        run_async(
            self._ptz_in_order(
                camera.id, ptz.move(self.app.api, camera.id, f"{direction}{move_type}")
            ),
            error_callback=lambda e: log.error("PTZ move failed: %s", e),
        )

    def _on_slot_zoom(self, slot_idx: int, direction: str, move_type: str) -> None:
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return
        run_async(
            self._ptz_in_order(
                camera.id, ptz.zoom(self.app.api, camera.id, f"{direction}{move_type}")
            ),
            error_callback=lambda e: log.error("PTZ zoom failed: %s", e),
        )

    def _on_slot_focus(self, slot_idx: int, control: str, move_type: str) -> None:
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return
        run_async(
            self._ptz_in_order(camera.id, ptz.focus(self.app.api, camera.id, control, move_type)),
            error_callback=lambda e: log.error("PTZ focus failed: %s", e),
        )

    def _on_slot_preset(self, slot_idx: int, preset_id: int) -> None:
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return
        run_async(
            self._ptz_in_order(camera.id, ptz.go_preset(self.app.api, camera.id, preset_id)),
            error_callback=lambda e: log.error("PTZ go_preset failed: %s", e),
        )

    def _on_slot_patrol(self, slot_idx: int, patrol_id: int) -> None:
        camera = self._slots[slot_idx].camera
        if not camera or not self.app.api:
            return
        run_async(
            self._ptz_in_order(camera.id, ptz.run_patrol(self.app.api, camera.id, patrol_id)),
            error_callback=lambda e: log.error("PTZ run_patrol failed: %s", e),
        )

    def _on_slot_open_1x1(self, slot_idx: int) -> None:
        """Right-click menu action: switch to 1x1 layout showing just this
        slot's camera."""
        camera = self._slots[slot_idx].camera
        if not camera:
            return
        # Ensure on_camera_selected takes its "switch to 1x1" branch rather
        # than "assign to the selected slot".
        self._select_slot(None)
        self.on_camera_selected(camera)

    def _on_slot_clear(self, slot_idx: int) -> None:
        """Right-click menu action: clear this specific slot's camera
        assignment, regardless of which slot (if any) is currently
        selected."""
        self._clear_slot(self._slots[slot_idx])
        if self._selected_slot == slot_idx:
            self._select_slot(None)
        self._save_session()

    def _on_slot_reload(self, slot_idx: int) -> None:
        """Right-click menu action: restart this slot's stream, leaving
        the rest of the layout alone.

        A slot that keeps its camera across a layout switch keeps its
        stream too (see _restore_layout_cameras), so switching layout is
        no longer a way to reset one camera that has drifted behind or
        stopped moving. This is, and it costs a single reconnect instead
        of a whole layout's worth.
        """
        slot = self._slots[slot_idx]
        camera = slot.camera
        if camera is None:
            return
        log.info("Reloading slot %d: %s", slot_idx, camera.name)
        history_target = self._history_target(slot)
        # Drop the bridge first. A History seek that still finds one on
        # the slot reuses that connection rather than building a fresh
        # one (see _on_recording_resolved), which would leave whatever
        # went wrong with it exactly where it was.
        slot.stop_stream()
        self._restart_slot_stream(slot_idx, camera, history_target)

    def reload_all_streams(self) -> None:
        """Restart every visible slot's stream, one slot at a time.

        The header bar's Reload button, for a whole layout gone bad
        rather than the single camera _on_slot_reload covers. Staggered
        rather than fired in one main-loop pass: a full 4x4 restarted at
        once is exactly the burst _HISTORY_TRANSITION_STAGGER_MS exists
        to spread out, and reloading is not worth reintroducing it.
        """
        self._run_staggered(
            [
                partial(self._on_slot_reload, slot_idx)
                for slot_idx in self._active
                if self._slots[slot_idx].camera is not None
            ]
        )

    def _assign_to_slot(self, slot_idx: int, camera: Camera) -> None:
        """Assign a camera to a specific slot, moving it if already displayed."""
        # Remove camera from its current slot if displayed elsewhere
        for slot in self._slots:
            if slot.camera and slot.camera.id == camera.id and slot.index != slot_idx:
                self._clear_slot(slot)
                break

        target = self._slots[slot_idx]
        # A slot playing recorded video keeps doing so for the newly
        # picked camera too, at the same point in time it was already
        # showing -- picking a camera isn't implicitly "return to live"
        # the way the Live button explicitly is (see _return_all_to_live).
        # Read before clear() below, which drops it.
        history_target = self._history_target(target)

        # Clear the target slot and assign
        self._clear_slot(target)
        target.assign(camera)
        self._restore_saved_audio_state(target, camera)
        self._update_slot_audio(target, camera)
        self._load_slot_ptz_extras(target, camera)
        self._restart_slot_stream(slot_idx, camera, history_target)

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------

    def _wants_ws_audio(self, slot: CameraSlot) -> bool:
        """Keep the normal single-camera path; skip inaudible grid work.

        History never calls this policy. Muted grid cameras retain their
        audio controls, and unmuting restarts that tile with sound.
        """
        return (slot.camera is None or len(self._active) <= 1
                or self.fullscreen_focus == slot.index
                or not self.app.config.camera_muted.get(slot.camera.id, True))

    def _ws_audio_policy_matches(self, slot: CameraSlot) -> bool:
        bridge = slot._ws_bridge
        return (bridge is None or bridge.is_history
                or bridge.audio_suppressed == (not LiveView._wants_ws_audio(self, slot)))

    def _live_profile(self, slot_idx: int, camera: Camera) -> StreamProfile | None:
        """Requested live quality; non-WebSocket transports keep their URL."""
        protocol = self.app.config.camera_protocols.get(camera.id, "auto")
        if protocol not in WEBSOCKET_PROTOCOLS:
            return None
        choice = self.app.config.camera_live_view_stream_profiles.get(
            camera.id, StreamProfile.CAMERA
        )
        return effective_layout_profile(
            choice, len(self._active), focused=self.fullscreen_focus == slot_idx
        )

    def _invalidate_live_start(self, slot_idx: int) -> None:
        """Discard a queued start/URL reply when this slot moves on."""
        self._slot_stream_requests.pop(slot_idx, None)
        self._slot_stream_profiles.pop(slot_idx, None)

    def _queue_live_starts(self, starts: list[tuple[int, Camera]]) -> None:
        """Space connection/decoder startup and cancel obsolete work.

        Layouts can contain dozens of tiles. Starting all bridges and
        audio muxers in one GTK iteration creates a large CPU/memory
        burst. Tickets also prevent an old delayed action from reopening
        a camera that the user cleared, replaced or already reloaded.
        """
        if self._streams_paused:
            return
        generation = self._layout_stream_generation
        for position, (index, camera) in enumerate(starts):
            ticket = object()
            self._slot_stream_requests[index] = ticket

            def start_one(index=index, camera_id=camera.id, ticket=ticket) -> bool:
                slot = self._slots[index]
                if (generation == self._layout_stream_generation
                        and self._slot_stream_requests.get(index) is ticket
                        and not self._streams_paused and index in self._active
                        and slot.camera is not None and slot.camera.id == camera_id):
                    self._start_stream(index, slot.camera)
                return False

            if position == 0:
                start_one()
            else:
                GLib.timeout_add(position * _HISTORY_TRANSITION_STAGGER_MS, start_one)

    @staticmethod
    def _history_target(slot: CameraSlot) -> float | None:
        """Where *slot* is in recorded video, None if it is playing live.

        Read before whatever tears the slot's stream down: clear() drops
        the position outright, and a fresh bridge starts reporting its
        own. A slot whose stream gave up has no bridge left, but is still
        in History until something returns it to live, the same as the
        camera poll's retry treats it.
        """
        if slot._ws_bridge is None:
            return slot._history_position if slot._stream_lost else None
        if not slot._ws_bridge.is_history:
            return None
        return slot._history_position

    def _restart_slot_stream(
        self, slot_idx: int, camera: Camera, history_target: float | None
    ) -> None:
        """Start *camera* in *slot_idx* afresh, back at *history_target*
        if that is where the slot was.

        Only the Live button ends History (see _return_all_to_live), so
        a slot showing recorded video comes back on the same moment
        rather than at the live edge. The seek gets a generation of its
        own, a batch of one, so it cannot supersede a timeline click's
        whole batch (see _slot_seek_generation).
        """
        if history_target is None:
            self._start_stream(slot_idx, camera)
            return
        self._invalidate_live_start(slot_idx)
        self._seek_generation += 1
        self._slot_seek_generation[slot_idx] = self._seek_generation
        self._seek_slot_to_time(self._slots[slot_idx], int(history_target), self._seek_generation)

    def _start_stream(self, slot_idx: int, camera: Camera) -> None:
        """Start streaming a camera in a slot.

        A camera the server reports as not ENABLED (disabled, or
        disconnected/offline) never gets a real RTSP/WebSocket URL handed
        to mpv — playing a placeholder instead avoids ever calling play()
        on a stream that may never resolve, which is what wedges a slot's
        render context with no way back (see git history for the
        investigation). sync_camera_statuses() swaps back to the real
        stream automatically once the camera is ENABLED again.
        """
        slot = self._slots[slot_idx]
        if (self._streams_paused or slot_idx not in self._active
                or slot.camera is None or slot.camera.id != camera.id):
            return
        # A fresh request replaces the ticket from any delayed start and
        # any earlier URL fetch, even if both address the same camera.
        request = object()
        self._slot_stream_requests[slot_idx] = request
        profile = self._live_profile(slot_idx, camera)
        self._slot_stream_profiles[slot_idx] = profile
        was_lost = slot._stream_lost
        if camera.status != CameraStatus.ENABLED:
            slot._stream_lost = False  # showing "offline", not a lost stream
            slot.stop_stream()
            slot.stop_ptt()  # the camera is not reachable to talk to either
            # A History session playing here went with the stream, so
            # its position goes too, or the timeline keeps drawing the
            # grey History ruler and bubble for it, and Back 10s, the
            # calendar and Download keep starting from where it was.
            slot.set_history_mode(False)
            self._set_history_position(slot, None)
            self._sync_history_active()
            # The placeholder card is never zoomed or dewarped.
            slot.player.set_dewarp("")
            slot.player.reset_zoom()
            slot.set_status("offline")
            slot.player.play(OFFLINE_PLACEHOLDER_URL)
            return

        if was_lost:
            # Retrying after a previous give-up, not a fresh selection —
            # show that something is happening rather than a silent black
            # screen while it reconnects (cleared once actually confirmed:
            # _on_ready for WebSocket, _on_stream_recovered for RTSP).
            slot.set_status("attempting reconnect")

        if not self.app.api:
            return

        # A stream starting while the layout is paused (a camera picked
        # into a slot, a status flip, a protocol change, a retry) joins
        # the Pause: this slot's own player may never have been paused,
        # and mpv keeps its pause across play() either way, so the
        # bridge or monitor started below has to know too, or it reads
        # the paused player as a dead stream (see _pause_all_slots).
        slot.player.set_paused(self._timeline_paused)

        api = self.app.api
        protocol = self.app.config.camera_protocols.get(camera.id, "auto")
        override = self.app.config.camera_overrides.get(camera.id, "")
        camera_stream_profile = self.app.config.camera_live_view_stream_profiles.get(
            camera.id, StreamProfile.CAMERA
        )

        cam_id = camera.id

        async def _get_url() -> tuple[int, int, str]:
            url = await get_live_view_path(
                api,
                camera.id,
                protocol=protocol,
                override_url=override,
                camera_stream_profile=camera_stream_profile,
                layout_stream_profile=profile,
            )
            return slot_idx, cam_id, url

        def accept_url(result: tuple[int, int, str]) -> None:
            current = self._slots[slot_idx].camera
            if (self._slot_stream_requests.get(slot_idx) is request
                    and self.app.api is api and current is not None
                    and current.id == cam_id and self._live_profile(slot_idx, current) == profile):
                self._on_stream_url(result)

        run_async(
            _get_url(),
            callback=accept_url,
            error_callback=lambda e: log.error(
                "Failed to get stream URL for %s: %s", camera.name, e
            ),
        )

    def _on_stream_url(self, result: tuple[int, int, str]) -> None:
        slot_idx, cam_id, url = result
        slot = self._slots[slot_idx]
        if self._streams_paused:
            # The user left the Live View page while this URL was being
            # fetched. A slot keeps its own visible flag when the page is
            # unmapped, so that alone would not stop us starting a stream
            # nobody is watching and pause_streams() has already been past.
            # resume_streams() starts it again on return.
            return
        if slot_idx in self._active and slot.camera and slot.camera.id == cam_id:
            log.info("Starting stream in slot %d: %s", slot_idx, url)
            slot.stop_stream()
            # Not before the URL fetch: a retried slot still shows the
            # offline or stream lost card until here, and keeps it if the
            # fetch fails.
            self._apply_dewarp(slot, slot.camera)
            # Only now is a stream really starting. Holding the flag until
            # here keeps the retry armed when the URL fetch itself fails,
            # which is the likeliest outcome when the NAS being unreachable
            # is what killed the stream in the first place.
            slot._stream_lost = False
            if url.startswith(("ws://", "wss://")):
                self._start_ws_bridge(slot, url)
            else:
                self._start_rtsp_monitor(slot, url)

    def _start_ws_bridge(self, slot: CameraSlot, url: str) -> None:
        """Start a Live WebSocket bridge and play the resulting pipe in
        mpv (see _enter_history_mode for the History equivalent —
        _start_bridge is the plumbing they share)."""
        slot.stop_stream()
        verify_ssl = self.app.api.profile.verify_ssl if self.app.api else True
        sid = self.app.api.sid if self.app.api else ""
        label = slot.camera.name if slot.camera else ""
        bridge = WebSocketBridge(
            url, verify_ssl, sid, label=label,
            include_audio=LiveView._wants_ws_audio(self, slot),
        )
        self._start_bridge(slot, bridge)

    def _apply_dewarp(self, slot: CameraSlot, camera: Camera) -> None:
        """Set *slot*'s fisheye dewarp from *camera*'s settings, before the
        first frame of a stream starting there, live or History."""
        slot.player.set_dewarp(*camera_dewarp(self.app.config, camera.id))

    def _enter_history_mode(self, slot: CameraSlot, recording: Recording, target_unix: int) -> int:
        """Switch *slot* into History mode, playing *recording* from
        *target_unix* (see ws_bridge.py's module docstring for the wire
        protocol). Only for a fresh seek -- a slot already in History
        mode reuses its existing bridge's seek() instead, which reuses
        the connection when it can rather than tearing down and
        rebuilding a whole pipeline for every click (see
        _on_recording_resolved).

        Returns the actual (possibly clamped, see
        WebSocketBridge._set_history_delta) position now playing --
        available synchronously right off the freshly constructed
        bridge, no await needed, since the clamp runs in its own
        __init__ -- for the caller to reflect on its own UI rather than
        assuming target_unix was used as-is. Falls back to target_unix
        itself if there's no API to build a bridge at all."""
        if not self.app.api:
            return target_unix
        self._invalidate_live_start(slot.index)
        slot.stop_stream()
        # Picked into a History slot, back from the stream lost card or
        # restarted by Camera Settings, the camera starts here, not in
        # _start_stream.
        if slot.camera:
            self._apply_dewarp(slot, slot.camera)
        # A stream really starts here, as in _on_stream_url, so a slot
        # retried after a give-up stops being one. Left set, every camera
        # poll retried it again, re-seeking a healthy bridge.
        slot._stream_lost = False
        verify_ssl = self.app.api.profile.verify_ssl
        sid = self.app.api.sid
        label = slot.camera.name if slot.camera else ""
        url = get_history_view_path(self.app.api)
        camera_id = recording.camera_id

        async def resolve(target: int) -> Recording | None:
            """Bound to camera_id, not to slot.camera -- this outlives
            whatever the slot is showing by the time a stale reconnect
            calls it (see WebSocketBridge's own history_resolver).

            find_covering_recording_at, not find_recording_at: a stale
            reconnect asking "does anything cover the target now" needs
            None for a genuine gap (e.g. the camera was down for a
            while), not the nearest recording on either side of it --
            see find_covering_recording_at's own docstring for what
            goes wrong otherwise."""
            api = self.app.api
            return await find_covering_recording_at(api, camera_id, target) if api else None

        bridge = WebSocketBridge(
            url,
            verify_ssl,
            sid,
            label=label,
            history_recording=recording,
            history_target=target_unix,
            history_resolver=resolve,
            history_speed=self._timeline_speed,
            history_reverse=self._timeline_reverse,
        )
        self._start_bridge(slot, bridge)
        position = bridge.current_history_position
        return position if position is not None else target_unix

    def _start_bridge(self, slot: CameraSlot, bridge: WebSocketBridge) -> None:
        """Plumbing shared by Live and History bridges alike: assign
        *bridge* to *slot*, play the pipe once ready, and report a
        permanent give-up the same way regardless of which mode started
        it (see _start_ws_bridge / _enter_history_mode)."""
        slot._ws_bridge = bridge
        # *bridge* is now the authoritative one for this slot either way
        # -- clears the stale-tick guard _return_all_to_live armed, if
        # any (see _leaving_history_slots's own comment).
        self._leaving_history_slots.discard(slot.index)
        # Ghosts/restores the camera-motor controls immediately, before
        # the pipe is even ready -- a slot mid-History-connect has no
        # live camera under it any more than one already playing does.
        slot.set_history_mode(bridge.is_history)
        if self._timeline_paused:
            self._pause_bridge(slot)
        if not bridge.is_history:
            # Defensive: covers every path back to Live, not just the
            # Live button (already clears this itself) -- e.g. a slot
            # hidden by a layout switch while in History, then reshown
            # later on its normal live stream, would otherwise keep a
            # stale position that resurfaces if it becomes the timeline
            # focus slot again.
            self._set_history_position(slot, None)
        cam_id = slot.camera.id if slot.camera else -1
        slot_idx = slot.index

        def _on_ready(pipe_url: str) -> None:
            s = self._slots[slot_idx]
            if s._ws_bridge is not bridge:
                # The slot tore this bridge down (or replaced it) while
                # start() was still resolving. Its read fd is closed by now
                # and the next bridge's os.pipe() hands the same numbers
                # back, so playing this pipe_url would point mpv at another
                # camera's stream.
                return
            if slot_idx in self._active and s.camera and s.camera.id == cam_id:
                log.info(
                    "WebSocket bridge ready, playing pipe: %s (audio_active=%s, history=%s)",
                    pipe_url,
                    bridge.audio_active,
                    bridge.is_history,
                )
                s.set_status("")
                s.player.play(
                    pipe_url,
                    live=not bridge.is_history,
                    low_latency=not bridge.audio_active,
                    muxed_audio=bridge.audio_active,
                    history_speed=float(self._timeline_speed) if bridge.is_history else 1.0,
                    video_format=bridge.video_format,
                )
                # Corrects the optimistic has_audio-based guess from
                # _update_slot_audio() now that whether DSM's audio codec
                # was actually mixable (PCMU or AAC) is known for certain.
                s.set_audio_playable(
                    bridge.audio_active or (bridge.audio_suppressed and s.camera.has_audio)
                )
                if bridge.audio_active:
                    # Only now, not back in _start_bridge: wait_audio_ended
                    # needs the pump task start() creates, and a stream
                    # with no audio to begin with has none to lose.
                    def _on_audio_ended(ended: bool) -> None:
                        if ended:
                            self._on_slot_audio_ended(slot_idx, bridge)

                    run_async(bridge.wait_audio_ended(), callback=_on_audio_ended)

        def _on_start_failed(exc: Exception) -> None:
            if self._slots[slot_idx]._ws_bridge is not bridge:
                # Same case _on_ready guards, arriving down the other
                # branch: a bridge stopped while start() was still pending
                # ends its pump without ever becoming ready, so start()
                # raises. Switching camera or leaving the page during the
                # second or two a stream takes to come up is ordinary, and
                # was being reported as a failure to start it.
                log.debug("WebSocket bridge stopped before it was ready: %s", exc)
                return
            log.error("WebSocket bridge failed: %s", exc)

        run_async(
            bridge.start(),
            callback=_on_ready,
            error_callback=_on_start_failed,
        )
        # WebSocketBridge reconnects on the same pipe internally and never
        # surfaces a routine drop as a "closed" event, so mpv never sees a
        # real EOF from one. This only fires once the bridge has genuinely
        # given up (a run of attempts that never even connect) or on a
        # deliberate stop (empty reason, ignored below).
        run_async(
            bridge.wait_closed(),
            callback=lambda reason: self._on_stream_gave_up(slot_idx, cam_id, bridge, reason),
        )
        if not bridge.is_history:
            # This notification intentionally leaves the pipe OPEN.
            # Recovery must stop mpv before closing any old writer.
            run_async(
                bridge.wait_live_resync(),
                callback=lambda reason: self._recover_live_slot(slot_idx, cam_id, bridge, reason),
            )

    def _on_slot_audio_ended(self, slot_idx: int, bridge: WebSocketBridge) -> None:
        """The gap watchdog ended this slot's audio for the session.

        Greys the volume control at once, which the camera poll would
        otherwise take up to its own interval to get to.

        **Do not deselect the audio track here.** It looks like the tidy
        thing to do, since the track can never deliver another packet and
        mpv goes on holding a decoder for it. Measured against real
        libmpv, deselecting is what wedges the whole stream: while the
        track is still selected mpv keeps reading the pipe hoping for
        audio, and dropping it leaves mpv needing only video, satisfied
        by demuxer-readahead-secs, which at any ordinary camera bitrate
        is far less than the 1 MiB already sitting in ffmpeg's output
        pipe. mpv stops reading with the pipe full, ffmpeg blocks writing
        to it, stops reading our video input, and the bridge gives the
        stream up. Reproduced 3 of 3 with the deselection and 0 of 3
        without, with everything else held constant, and it matched the
        give-up seen live every 24-88s after this fires.
        """
        slot = self._slots[slot_idx]
        if slot._ws_bridge is not bridge:
            return  # the slot moved on to another stream meanwhile
        log.info(
            "Audio ended for slot %d (%s)",
            slot_idx,
            slot.camera.name if slot.camera else "no camera",
        )
        slot.set_audio_playable(False)

    def _start_rtsp_monitor(self, slot: CameraSlot, url: str) -> None:
        """Play a plain RTSP URL and watch it with an RtspHealthMonitor.

        Unlike WebSocket streams (bridged through WebSocketBridge, which
        already detects and recovers from a dead connection), mpv talks to
        an RTSP camera directly with nothing watching for the demuxer
        dying silently mid-stream — this is what fills that gap.
        """
        slot.set_status("")  # clear any leftover "offline"/"reconnect" label
        # RTSP has no History mode at all (see ws_bridge.py's module
        # docstring) -- a defensive reset for a slot that switches
        # protocol away from a History WS session straight to RTSP,
        # which would otherwise leave its camera-motor controls ghosted
        # with nothing to ever un-ghost them.
        slot.set_history_mode(False)
        self._set_history_position(slot, None)
        slot.player.play(url, live=True)
        cam_id = slot.camera.id if slot.camera else -1
        slot_idx = slot.index
        label = slot.camera.name if slot.camera else ""

        monitor = RtspHealthMonitor(
            slot.player,
            url,
            label,
            on_gave_up=lambda reason: self._on_stream_gave_up(slot_idx, cam_id, monitor, reason),
            on_recovered=lambda: self._on_stream_recovered(slot_idx, cam_id, monitor),
        )
        if self._timeline_paused:
            monitor.set_paused(True)
        slot._rtsp_monitor = monitor

    def _on_stream_recovered(self, slot_idx: int, cam_id: int, monitor: RtspHealthMonitor) -> None:
        """Clear the "attempting reconnect" status once a retried RTSP
        stream is confirmed advancing again."""
        slot = self._slots[slot_idx]
        if slot._rtsp_monitor is not monitor:
            return  # slot moved on to something else
        if slot_idx not in self._active or not slot.camera or slot.camera.id != cam_id:
            return
        slot.set_status("")

    def _on_stream_gave_up(
        self, slot_idx: int, cam_id: int, source: WebSocketBridge | RtspHealthMonitor, reason: str
    ) -> None:
        """Show a slot whose stream gave up after repeated failures.

        *source* is whichever object reported the failure — compared
        against the slot's current bridge/monitor so a stale notification
        from one the slot has since moved on from is ignored.
        """
        slot = self._slots[slot_idx]
        if not reason or (slot._ws_bridge is not source and slot._rtsp_monitor is not source):
            return  # we stopped it ourselves, or the slot moved on
        if slot_idx not in self._active or not slot.camera or slot.camera.id != cam_id:
            return
        log.error("Stream for %s gave up (%s)", slot.camera.name, reason)
        # The camera may still be reported ENABLED (this is a transport-
        # level failure, not necessarily a status change) — mark it so
        # sync_camera_statuses() keeps retrying on the next poll even
        # without seeing a status transition to react to.
        slot._stream_lost = True
        # Swap to the placeholder rather than leaving the wedged mpv state
        # on screen: this is a normal stop()/play() cycle (same as any
        # camera-to-camera switch), just targeting a local synthetic
        # stream instead of the dead network one, so it can't wedge.
        slot.stop_stream()
        # The placeholder card is never zoomed or dewarped.
        slot.player.set_dewarp("")
        slot.player.reset_zoom()
        slot.set_status("stream lost")
        slot.player.play(OFFLINE_PLACEHOLDER_URL)

    # ------------------------------------------------------------------
    # Session persistence
    # ------------------------------------------------------------------

    def _save_session(self) -> None:
        """Persist grid layout and per-layout camera assignments to config."""
        cam_ids: list[int] = []
        for i in self._active:
            cam = self._slots[i].camera
            cam_ids.append(cam.id if cam else 0)
        if not self._current_layout.startswith("nas:"):
            self.app.config.grid_layout = self._current_layout
            self.app.config.layout_cameras[self._current_layout] = cam_ids
        log.debug("layout_cameras session save: [%s] = %s", self._current_layout, cam_ids)
        save_config_now(self.app.config)
        # Session changes (assign/clear a slot's camera) can change the
        # layout-accumulated row's own camera set.
        self._request_presence_refresh()

    def restore_session(self, cameras: list[Camera]) -> None:
        """Restore camera assignments from config."""
        self._cameras = cameras
        self._restore_layout_cameras()

    def _shown_slots(self) -> list[CameraSlot]:
        """Slots on screen with a camera: none while another page is
        shown, and never a hidden one, which keeps its camera across
        layout switches."""
        if self._streams_paused:
            return []
        return [self._slots[i] for i in self._active if self._slots[i].camera is not None]

    def displayed_camera_ids(self) -> set[int]:
        """Cameras currently on screen."""
        return {slot.camera.id for slot in self._shown_slots() if slot.camera is not None}

    def show_transaction(self, camera_id: int, text: str) -> None:
        """Show a POS receipt over every slot on screen showing *camera_id*."""
        for slot in self._shown_slots():
            if slot.camera is not None and slot.camera.id == camera_id:
                slot.show_receipt(text)

    def sync_camera_statuses(self, cameras: list[Camera]) -> None:
        """Swap a visible slot between its real stream and the offline
        placeholder as its camera's reported status changes.

        Called after every sidebar camera-list refresh (including the
        periodic poll), so a camera that comes back online has its real
        feed restored automatically, without the user re-selecting it.

        Also retries any slot whose stream gave up (slot._stream_lost) while
        its camera is still ENABLED, even without a status transition — a
        transport-level RTSP failure has no status change to react to
        otherwise, so it would be stuck on the placeholder forever.
        """
        self._cameras = cameras
        cam_map = {c.id: c for c in cameras}
        for i in self._active:
            slot = self._slots[i]
            if not slot.camera:
                continue
            fresh = cam_map.get(slot.camera.id)
            if fresh is None:
                continue
            # A bridge that was muxing audio can stop mid-session, when
            # the camera goes quiet and the gap watchdog ends the stream
            # to keep the video moving. Nothing else revisits the audio
            # control after the stream started, so it would go on
            # offering a volume slider that reaches nothing.
            if (slot._ws_bridge is not None and not slot._ws_bridge.audio_active
                    and not slot._ws_bridge.audio_suppressed):
                slot.set_audio_playable(False)
            status_changed = fresh.status != slot.camera.status
            retry_lost_stream = slot._stream_lost and fresh.status == CameraStatus.ENABLED
            if not status_changed and not retry_lost_stream:
                continue
            slot.update_camera(fresh)
            # While another page is shown the streams are paused; keep the
            # camera status current but do not start a stream behind the
            # user's back — resume_streams restores them on return.
            if self._streams_paused:
                continue
            # A slot that gave up while playing recorded video comes back
            # to the same moment, the way Reload already does. _start_stream
            # is the live starter and has no History awareness at all, so it
            # resolved the camera's protocol and began a plain live stream,
            # dropping the slot out of History with no way back.
            #
            # slot._history_position, not _history_target(slot): the bridge
            # is already gone by now (_on_stream_gave_up tears the stream
            # down), while the position outlives it. It is None for a slot
            # that was playing live, since every path back to live clears
            # it, and _start_stream clears it for a camera that is no longer
            # ENABLED, which is the branch that shows the offline card.
            target = slot._history_position if fresh.status == CameraStatus.ENABLED else None
            self._restart_slot_stream(i, fresh, target)

    def restart_camera(self, camera_id: int) -> None:
        """Restart the stream for a camera if it is currently displayed.

        Called after a protocol override change, among other things — the
        mute button's playability needs re-resolving too, since that's
        exactly the kind of change that flips it (WebSocket <-> RTSP).
        """
        for slot in self._slots:
            if slot.index in self._active and slot.camera and slot.camera.id == camera_id:
                # Only the Live button ends History, so a slot showing
                # recorded video comes back on the same moment.
                history_target = self._history_target(slot)
                slot.stop_stream()
                self._update_slot_audio(slot, slot.camera)
                # While another page is shown the streams are paused, and
                # resume_streams restarts them on return.
                if not self._streams_paused:
                    self._restart_slot_stream(slot.index, slot.camera, history_target)

    def pause_streams(self) -> None:
        """Stop all mpv playback but keep camera assignments.

        Also resets zoom and auto-mutes — leaving the Live View page loses
        visibility for every slot, same as any other slot that stops being
        shown (see _apply_layout()). resume_streams() restores each
        camera's actual mute/volume choice, not just leaving it muted.
        """
        self._streams_paused = True
        self._layout_stream_generation += 1
        self._slot_stream_requests.clear()
        self._slot_stream_profiles.clear()
        # A seek, event lookup or queued Back/Forward 10s still out would
        # otherwise open History streams in slots nobody can see, muted
        # until the page comes back and replaces them.
        self._forget_pending_lookups()
        # Leaving the page ends a Pause, like a layout switch does:
        # resume_streams starts every stream afresh, and mpv keeps its
        # pause across play(), so the new stream would otherwise feed a
        # paused player that its bridge or monitor then gives up on.
        self._end_timeline_pause()
        for slot in self._slots:
            slot.player.reset_zoom()
            slot.player.set_mute(True)
            slot._update_mute_icon()
            if slot.camera:
                slot.stop_stream()
                slot.stop_ptt()

    def resume_streams(self) -> None:
        """Restart streams for all visible slots that have a camera
        assigned.

        Always on the live stream, History or not -- pause_streams tore
        every bridge down on the way out -- so the timeline's
        History-only controls have to come back off with them.
        """
        self._streams_paused = False
        starts: list[tuple[int, Camera]] = []
        for i in self._active:
            slot = self._slots[i]
            if slot.camera:
                self._restore_saved_audio_state(slot, slot.camera)
                self._set_history_position(slot, None)
                starts.append((i, slot.camera))
        self._queue_live_starts(starts)
        self._sync_history_active()
        # Kept, the next History entry ran at whatever speed was in use
        # before leaving, and a lowered Settings budget then changed it
        # the moment the speed dropdown opened.
        self._reset_playback_speed()

    def stop_all(self) -> None:
        """Stop all streams."""
        self._streams_paused = True
        self._layout_stream_generation += 1
        self._slot_stream_requests.clear()
        self._slot_stream_profiles.clear()
        for slot in self._slots:
            slot.clear()
