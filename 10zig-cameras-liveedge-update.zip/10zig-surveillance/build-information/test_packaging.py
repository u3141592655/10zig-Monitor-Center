"""Execute the real installer/rollback with isolated PeakOS paths and freeze.

The application's runtime bytes are reduced to a test fixture, with the matching
expected digest substituted in the temporary copy. No real /boot or /tmp/config
path is touched.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


PACKAGE = Path(__file__).parent / "package" / "10zig-surveillance"
if not (PACKAGE / "install.sh").is_file():
    # This test is also shipped in the extracted ZIP's build-information.
    PACKAGE = Path(__file__).resolve().parent.parent
RUNTIME = b"fixture for the existing read-only native runtime\n"
SHA = hashlib.sha256(RUNTIME).hexdigest()
OLD_SHA = "91dc667cc2f2c1b49af9ec06a6ba5a7df1253ee36dcc9394a5eb6113a45973c4"


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="cameras-install-test-")
        self.base = Path(self.tmp.name)
        self.usb = self.base / "usb" / "10zig-surveillance"
        self.root = self.base / "boot" / "custom-apps" / "10zig-surveillance"
        self.config = self.base / "tmp" / "config"
        self.local = self.config / "files" / "surveillance-client"
        self.conn = self.config / "xmlconfig" / "user" / "software" / "shellscript" / "connections" / "Q2FtZXJhcw==.xml"
        self.bin = self.base / "bin"
        self.bin.mkdir()
        self.usb.mkdir(parents=True)
        self.local.mkdir(parents=True)
        self.conn.parent.mkdir(parents=True)
        (self.base / "boot").mkdir(exist_ok=True)
        (self.usb / "app" / "surveillance").mkdir(parents=True)
        (self.usb / "app" / "surveillance" / "__main__.py").write_text("# new application\n")
        for name in ("install.sh", "start-surveillance.sh", "rollback.sh"):
            text = (PACKAGE / name).read_text()
            text = text.replace("/boot/", str(self.base / "boot") + "/")
            text = text.replace("/tmp/config", str(self.config))
            text = text.replace('"/tmp/$SURV_REL"', '"' + str(self.base / "tmp") + '/$SURV_REL"')
            text = text.replace("/tmp/10zig-", str(self.base / "tmp") + "/10zig-")
            text = text.replace(OLD_SHA, SHA)
            (self.usb / name).write_text(text)
        freeze = self.bin / "freeze"
        freeze.write_text("#!/bin/sh\nset -e\n[ \"${FAIL_FREEZE:-0}\" = 0 ] || exit 8\ntar -czf " + str(self.base / "boot" / "config.tar.gz") + " -C " + str(self.base / "tmp") + " config\n")
        freeze.chmod(0o755)
        identity = self.bin / "id"
        identity.write_text("#!/bin/sh\nprintf '0\\n'\n")
        identity.chmod(0o755)
        self.env = dict(os.environ, PATH=str(self.bin) + ":" + os.environ["PATH"])

    def tearDown(self):
        self.tmp.cleanup()

    def manifest(self):
        rows = []
        for path in sorted(self.usb.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                rows.append(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(self.usb)))
        (self.usb / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n")

    def existing(self):
        self.root.mkdir(parents=True)
        (self.root / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        (self.root / "profile" / "config").mkdir(parents=True)
        (self.root / "profile" / "config" / "keep.toml").write_text("valuable = 'existing profile'\n")
        (self.local / "start-surveillance.sh").write_text("# original launcher\n")
        (self.local / "image-path.txt").write_text(str(self.root / "surveillance-runtime.squashfs") + "\n")
        (self.config / "files" / "Cameras.sh").write_text("# original connection script\n")
        self.conn.write_text('<key><_string value="connStartArgs">CONN_PNAME_SUBST</_string><untouched>yes</untouched></key>\n')

    def run_script(self, script, **extra_env):
        return subprocess.run(["sh", str(script)], env=dict(self.env, **extra_env), capture_output=True, text=True)

    def test_update_and_rollback_preserve_profile_and_runtime(self):
        self.existing()
        old_app = self.root / "app" / "surveillance" / "__main__.py"
        old_app.parent.mkdir(parents=True)
        old_app.write_text("# previous layouts3 application\n")
        (self.root / "release.txt").write_text("0.15.0+peakos.layouts3\n")
        credentials = self.root / "profile" / "data" / "surveillance" / "credentials"
        credentials.mkdir(parents=True)
        (credentials / "account.fernet").write_bytes(b"encrypted credential test fixture")
        layouts = self.root / "profile" / "config" / "local-layouts.json"
        layouts.write_text('{"name":"My layout","cameras":[1,2,3,4]}\n')
        profile_before = {p.relative_to(self.root / "profile"): p.read_bytes() for p in (self.root / "profile").rglob("*") if p.is_file()}
        self.manifest()
        original_config = (self.root / "profile" / "config" / "keep.toml").read_bytes()
        original_script = (self.config / "files" / "Cameras.sh").read_bytes()
        original_xml = self.conn.read_bytes()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.root / "surveillance-runtime.squashfs").read_bytes(), RUNTIME)
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_bytes(), original_config)
        self.assertIn('>Cameras<', self.conn.read_text())
        self.assertIn('<untouched>yes</untouched>', self.conn.read_text())
        self.assertTrue((self.root / "app" / "surveillance" / "__main__.py").exists())
        self.assertEqual((self.root / "release.txt").read_text(), "0.15.0+peakos.layouts4\n")
        for relative, contents in profile_before.items():
            self.assertEqual((self.root / "profile" / relative).read_bytes(), contents)
        self.assertIn('SURVEILLANCE_CREDENTIAL_STORE=file', (self.local / "start-surveillance.sh").read_text())
        result = self.run_script(self.root / "rollback.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertEqual((self.config / "files" / "Cameras.sh").read_bytes(), original_script)
        self.assertEqual(self.conn.read_bytes(), original_xml)
        self.assertEqual(old_app.read_text(), "# previous layouts3 application\n")
        self.assertEqual((self.root / "release.txt").read_text(), "0.15.0+peakos.layouts3\n")
        for relative, contents in profile_before.items():
            self.assertEqual((self.root / "profile" / relative).read_bytes(), contents)
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_bytes(), original_config)

    def test_update_rejects_missing_runtime_before_installing(self):
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("small update requires", result.stderr)
        self.assertFalse(self.root.exists())

    def test_damaged_source_rejected_before_touching_existing_install(self):
        self.existing()
        self.manifest()
        (self.usb / "app" / "surveillance" / "__main__.py").write_text("corrupted\n")
        result = self.run_script(self.usb / "install.sh")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertFalse((self.root / "last-backup.txt").exists())

    def test_full_package_installs_runtime(self):
        (self.usb / "surveillance-runtime.squashfs").write_bytes(RUNTIME)
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.root / "surveillance-runtime.squashfs").read_bytes(), RUNTIME)
        self.assertTrue((self.root / "profile").exists())

    def test_failed_freeze_reports_rollback_and_previous_install_is_restorable(self):
        self.existing()
        self.manifest()
        result = self.run_script(self.usb / "install.sh", FAIL_FREEZE="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("rollback.sh", result.stderr)
        result = self.run_script(self.root / "rollback.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.local / "start-surveillance.sh").read_text(), "# original launcher\n")
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_text(), "valuable = 'existing profile'\n")

    def test_launcher_uses_internal_profile_overlay_and_software_decoding(self):
        self.existing()
        self.manifest()
        result = self.run_script(self.usb / "install.sh")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        prefix = self.base / "tmp" / "10zig-surveillance-runtime"
        (prefix / "bin").mkdir(parents=True)
        (prefix / "10zig-build-id.txt").write_text("surveillance-0.15.0-peakos16.5-x86_64-20261030\n")
        for name in ("mountpoint", "umount"):
            command = self.bin / name
            command.write_text("#!/bin/sh\nexit 0\n")
            command.chmod(0o755)
        capture = self.base / "captured-environment.txt"
        python = prefix / "bin" / "python"
        python.write_text('#!/bin/sh\nprintf "%s\\n" "$XDG_CONFIG_HOME" "$XDG_DATA_HOME" "$PYTHONPATH" "$SURVEILLANCE_CREDENTIAL_STORE" "$SURVEILLANCE_MPV_OPTS" > "$SURV_TEST_CAPTURE"\n')
        python.chmod(0o755)
        result = self.run_script(self.local / "start-surveillance.sh", SURV_TEST_CAPTURE=str(capture), SURVEILLANCE_MPV_OPTS="")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(capture.read_text().splitlines(), [
            str(self.root / "profile" / "config"),
            str(self.root / "profile" / "data"),
            str(self.root / "app"),
            "file",
            "hwdec=no",
        ])
        self.assertEqual((self.root / "profile" / "config" / "keep.toml").read_text(), "valuable = 'existing profile'\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
