"""Bounded native transport + LiveView recovery reproduction.

No NAS, GTK display, camera credentials, or external service is involved.
Two local WebSocket cameras carry real H.264 with per-picture source IDs in
valid user_data_unregistered SEI. One reader continuously consumes at 15fps
while the source runs at 25fps; the peer drains as frames become available.

The application WebSocketBridge, LiveView._start_stream/_on_stream_url/
_start_ws_bridge/_start_bridge/_recover_live_slot, and CameraSlot.stop_stream
are used unchanged. Only the UI/decoder is replaced by a controlled reader,
the URL provider by this local source, and async/UI delivery by the current
event loop. Every complete captured session is decoded by bundled FFmpeg.
Thus these are source-to-pipe-consumer ages, NOT physical screen latency or
measurements of the user's NAS/PeakOS device.

Run with the app runtime and PYTHONPATH pointing at the current source/src:
  python validation/probe_live_recovery.py --baseline ../cameras-realtime-edition/source
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import fcntl
import importlib.util
import json
import math
import os
import re
import struct
import subprocess
import sys
import time
from pathlib import Path
from types import MethodType, SimpleNamespace
from typing import Any

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

from surveillance.api.models import CameraStatus
from surveillance.services.ws_bridge import WebSocketBridge
from surveillance.ui import liveview

FPS = 25
SLOW_FPS = 15
UUID = bytes.fromhex("1031a35e64fa4b20a41a497e302dade7")
START = b"\x00\x00\x00\x01"
AUD = START + b"\x09"


def escape_rbsp(data: bytes) -> bytes:
    result = bytearray()
    zeros = 0
    for value in data:
        if zeros >= 2 and value <= 3:
            result.append(3)
            zeros = 0
        result.append(value)
        zeros = zeros + 1 if value == 0 else 0
    return bytes(result)


def unescape_rbsp(data: bytes) -> bytes:
    return data.replace(b"\x00\x00\x03", b"\x00\x00")


def source_sei(seq: int) -> bytes:
    payload = UUID + struct.pack(">Q", seq)
    return b"\x06" + escape_rbsp(bytes((5, len(payload))) + payload + b"\x80")


def read_source_seq(frame: bytes) -> int:
    for nal in frame.split(START):
        if nal and nal[0] & 31 == 6:
            rbsp = unescape_rbsp(nal[1:])
            marker = rbsp.find(UUID)
            if marker >= 0:
                return struct.unpack(">Q", rbsp[marker + 16:marker + 24])[0]
    raise AssertionError("source SEI missing from complete AU")


def wire(header: bytes, payload: bytes = b"") -> bytes:
    return len(header).to_bytes(4, "big") + header + payload


def encoded_frames(folder: Path) -> list[list[bytes]]:
    path = folder / "generated-source.h264"
    subprocess.run([
        "ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i",
        "testsrc2=s=960x540:r=25", "-t", "3", "-c:v", "libx264",
        "-threads", "1", "-preset", "ultrafast", "-tune", "zerolatency",
        "-crf", "18", "-x264-params", "aud=1:keyint=25:scenecut=0:repeat-headers=1",
        "-f", "h264", str(path),
    ], check=True)
    frames: list[list[bytes]] = []
    for nal in re.split(rb"\x00\x00\x00?\x01", path.read_bytes()):
        if not nal:
            continue
        if nal[0] & 31 == 9:
            frames.append([])
        frames[-1].append(nal)
    assert len(frames) == 75
    assert all(any(n[0] & 31 == 5 for n in frames[i]) for i in (0, 25, 50))
    return frames


def summarize(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(values),
        "first_s": round(values[0], 4),
        "last_s": round(values[-1], 4),
        "median_s": round(ordered[len(ordered) // 2], 4),
        "p95_s": round(ordered[int((len(ordered) - 1) * 0.95)], 4),
        "maximum_s": round(max(values), 4),
    }


async def trial(
    name: str, bridge_type: type, frames: list[list[bytes]], folder: Path,
    duration: float, recovery_enabled: bool,
) -> dict[str, Any]:
    started = time.monotonic()
    events: list[dict[str, Any]] = []
    tasks: set[asyncio.Task] = set()
    errors: list[str] = []
    bridges: list[Any] = []
    sessions: list[dict[str, Any]] = []
    url_calls = [0, 0]
    websocket_connections = [0, 0]
    active_sockets: set[int] = set()
    closing = False

    def event(kind: str, **details: Any) -> None:
        events.append({"at_s": round(time.monotonic() - started, 4), "kind": kind, **details})

    def dispatch(coroutine: Any, callback: Any = None, error_callback: Any = None) -> asyncio.Task:
        task = asyncio.create_task(coroutine)
        tasks.add(task)

        def complete(future: asyncio.Task) -> None:
            tasks.discard(future)
            if future.cancelled():
                return
            try:
                result = future.result()
                if callback is not None:
                    callback(result)
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
                if error_callback is not None:
                    error_callback(exc)

        task.add_done_callback(complete)
        return task

    class ObservedBridge(bridge_type):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            if not recovery_enabled:
                # The previous release has no optional-audio policy.
                # This source has no audio, so preserve its old behavior.
                kwargs.pop("include_audio", None)
            super().__init__(*args, **kwargs)
            self.probe_id = len(bridges)
            self.probe_pipe_inode: int | None = None
            self.probe_stop_complete = False
            self.probe_close_after_consumer = True
            bridges.append(self)

        @property
        def audio_suppressed(self) -> bool:
            return getattr(super(), "audio_suppressed", False)

        async def start(self) -> str:
            url = await super().start()
            self.probe_pipe_inode = os.fstat(self._read_fd).st_ino
            event("bridge_ready", bridge=self.probe_id, label=self._label,
                  pipe_inode=self.probe_pipe_inode,
                  pipe_capacity=fcntl.fcntl(self._read_fd, fcntl.F_GETPIPE_SZ))
            return url

        def close_write_end(self) -> None:
            active_readers = [s for s in sessions if s["bridge"] == self.probe_id and s["reader_open"]]
            if active_readers:
                self.probe_close_after_consumer = False
            event("bridge_close_write", bridge=self.probe_id,
                  active_consumer_readers=len(active_readers))
            super().close_write_end()

        async def stop(self) -> None:
            await super().stop()
            self.probe_stop_complete = True
            event("bridge_stopped", bridge=self.probe_id,
                  read_fd=self._read_fd, video_write_fd=self._video_write_fd)

        async def wait_live_resync(self) -> str:
            if recovery_enabled:
                return await super().wait_live_resync()
            await self.wait_closed()
            return ""

    async def sender(websocket: Any) -> None:
        path = websocket.request.path
        camera = int(path.split("?")[0].rsplit("/", 1)[-1])
        websocket_connections[camera] += 1
        connection_id = sum(websocket_connections)
        active_sockets.add(connection_id)
        # A new live connection starts at the next source keyframe, not
        # where its old connection stopped consuming.
        seq = math.ceil(max(0, time.monotonic() - started) / 1.0) * FPS
        event("source_connected", camera=camera, connection=connection_id, first_seq=seq)
        try:
            await websocket.send(wire(b"vdoCodec=H264"))
            while not closing:
                await asyncio.sleep(max(0.0, started + seq / FPS - time.monotonic()))
                frame = frames[seq % len(frames)]
                sent_sei = False
                for nal in frame:
                    if not sent_sei and nal[0] & 31 in (1, 5):
                        await websocket.send(wire(
                            f"mediaType=1&msec={seq * 40}".encode(), source_sei(seq)
                        ))
                        sent_sei = True
                    await websocket.send(wire(f"mediaType=1&msec={seq * 40}".encode(), nal))
                seq += 1
        except ConnectionClosed:
            pass
        finally:
            active_sockets.discard(connection_id)
            event("source_closed", camera=camera, connection=connection_id)

    class ControlledPlayer:
        def __init__(self, camera: int) -> None:
            self.camera = camera
            self.task: asyncio.Task | None = None
            self.fd = -1
            self.session: dict[str, Any] | None = None

        def play(self, pipe_url: str, **_kwargs: Any) -> None:
            self.stop()
            original = int(pipe_url.removeprefix("fd://"))
            self.fd = os.dup(original)
            os.set_blocking(self.fd, False)
            bridge = view._slots[self.camera]._ws_bridge
            session = {
                "camera": self.camera, "bridge": bridge.probe_id,
                "reader_open": True, "reader_fd": self.fd,
                "pipe_inode": os.fstat(self.fd).st_ino, "ages": [], "seqs": [],
                "bytes": bytearray(), "created_s": time.monotonic() - started,
            }
            sessions.append(session)
            self.session = session
            event("player_started", camera=self.camera, bridge=bridge.probe_id)
            self.task = dispatch(self.consume(self.fd, session))

        async def consume(self, fd: int, session: dict[str, Any]) -> None:
            buffer = bytearray()
            interval = 1.0 / SLOW_FPS if self.camera == 0 else 0.0
            next_at = time.monotonic()
            while True:
                boundary = buffer.find(AUD, len(AUD))
                if boundary > 0:
                    await asyncio.sleep(max(0, next_at - time.monotonic()))
                    frame = bytes(buffer[:boundary])
                    del buffer[:boundary]
                    seq = read_source_seq(frame)
                    age = time.monotonic() - (started + seq / FPS)
                    session["ages"].append(age)
                    session["seqs"].append(seq)
                    session["bytes"].extend(frame)
                    if len(session["seqs"]) == 1:
                        assert any(n and n[0] & 31 == 5 for n in frame.split(START)), "fresh reader must begin at IDR"
                        event("first_frame", camera=self.camera, bridge=session["bridge"],
                              seq=seq, source_age_s=round(age, 4))
                    next_at = time.monotonic() + interval
                    continue
                try:
                    chunk = os.read(fd, 1024)
                except BlockingIOError:
                    await asyncio.sleep(0.001)
                    continue
                if not chunk:
                    return
                buffer.extend(chunk)

        def stop(self) -> None:
            if self.task is not None:
                self.task.cancel()
                self.task = None
            if self.fd >= 0:
                os.close(self.fd)
                self.fd = -1
                assert self.session is not None
                self.session["reader_open"] = False
                event("player_stopped", camera=self.camera, bridge=self.session["bridge"])
            self.session = None

        def set_paused(self, _value: bool) -> None:
            pass

        def live_backlog_reason(self) -> None:
            return None

    slots = []
    for index in range(2):
        slot = SimpleNamespace(
            index=index, camera=SimpleNamespace(id=index, name=("slow" if index == 0 else "healthy"),
                                               status=CameraStatus.ENABLED, has_audio=False),
            player=ControlledPlayer(index), _rtsp_monitor=None, _ws_bridge=None,
            _stream_lost=False, _history_position=None,
            set_status=lambda _status: None, set_history_mode=lambda _value: None,
            set_audio_playable=lambda _value: None,
        )
        slot.stop_stream = MethodType(liveview.CameraSlot.stop_stream, slot)
        slots.append(slot)

    view = SimpleNamespace(
        app=SimpleNamespace(api=SimpleNamespace(profile=SimpleNamespace(verify_ssl=False), sid="local"),
                            config=SimpleNamespace(camera_protocols={}, camera_overrides={},
                                                   camera_live_view_stream_profiles={}, camera_muted={})),
        _streams_paused=False, _timeline_paused=False, _active={0, 1}, _slots=slots,
        fullscreen_focus=None,
        _live_resync_pending={}, _layout_stream_generation=1,
        _slot_seek_generation={}, _slot_stream_requests={}, _slot_stream_profiles={},
        _live_resync_next_at=0.0, _leaving_history_slots=set(), _timeline_speed=1,
        _timeline_reverse=False, _live_profile=lambda _index, _cam: None,
        _apply_dewarp=lambda _slot, _cam: None,
        _set_history_position=lambda slot, value: setattr(slot, "_history_position", value),
        _on_stream_gave_up=lambda _index, _cam, _bridge, reason: errors.append(reason) if reason else None,
        _on_slot_audio_ended=lambda *_args: None,
    )
    for method in ("_start_stream", "_on_stream_url", "_start_ws_bridge", "_start_bridge",
                   "_invalidate_live_start", "_recover_live_slot"):
        setattr(view, method, MethodType(getattr(liveview.LiveView, method), view))
    view._history_target = liveview.LiveView._history_target

    previous = (liveview.run_async, liveview.WebSocketBridge, liveview.get_live_view_path)
    liveview.run_async = dispatch
    liveview.WebSocketBridge = ObservedBridge
    try:
        async with serve(sender, "127.0.0.1", 0, compression=None, close_timeout=0.2) as server:
            port = server.sockets[0].getsockname()[1]

            async def fresh_url(_api: Any, camera: int, **_kwargs: Any) -> str:
                url_calls[camera] += 1
                event("fresh_url", camera=camera, request=url_calls[camera])
                return f"ws://127.0.0.1:{port}/{camera}?request={url_calls[camera]}"

            liveview.get_live_view_path = fresh_url
            for slot in slots:
                view._start_stream(slot.index, slot.camera)
            deadline = started + duration
            while time.monotonic() < deadline:
                await asyncio.sleep(0.1)
            closing = True
            view._streams_paused = True
            for slot in slots:
                slot.stop_stream()
            await asyncio.sleep(0.5)
            for bridge in bridges:
                await bridge.stop()
            for task in list(tasks):
                task.cancel()
            await asyncio.gather(*list(tasks), return_exceptions=True)
    finally:
        liveview.run_async, liveview.WebSocketBridge, liveview.get_live_view_path = previous
        for slot in slots:
            slot.player.stop()

    assert not errors, errors
    assert not active_sockets, active_sockets
    decoded_sessions = []
    for index, session in enumerate(sessions):
        if not session["seqs"]:
            raise AssertionError("empty media session")
        output = folder / f"{name}-camera{session['camera']}-session{index}.h264"
        output.write_bytes(session.pop("bytes"))
        result = subprocess.run([
            "ffmpeg", "-v", "error", "-xerror", "-i", str(output), "-f", "null", "-"
        ], capture_output=True, text=True)
        assert result.returncode == 0, f"{output}: {result.stderr}"
        decoded_sessions.append({
            "camera": session["camera"], "bridge": session["bridge"],
            "pipe_inode": session["pipe_inode"], "frames": len(session["seqs"]),
            "first_source_seq": session["seqs"][0], "last_source_seq": session["seqs"][-1],
            "consumer_age": summarize(session["ages"]),
            "ffmpeg_decode_without_errors": True,
        })
    slow = [session for session in sessions if session["camera"] == 0]
    healthy = [session for session in sessions if session["camera"] == 1]
    assert len(healthy) == 1, "healthy camera restarted"
    assert websocket_connections[1] == 1 and url_calls[1] == 1
    assert all(bridge.probe_stop_complete and bridge._read_fd < 0 and bridge._video_write_fd < 0
               for bridge in bridges)
    assert all(bridge.probe_close_after_consumer for bridge in bridges), "writer closed before consumer stopped"
    assert len({session["pipe_inode"] for session in sessions}) == len(sessions), "old pipe reused"
    if recovery_enabled:
        assert len(slow) >= 2, "slow live stream never recovered"
        assert all(session["ages"][0] < 0.25 for session in slow[1:]), "fresh session still read stale video"
        assert all(slow[i]["seqs"][0] > slow[i - 1]["seqs"][-1] + FPS
                   for i in range(1, len(slow))), "recovery did not jump forward"
    else:
        assert len(slow) == 1
        assert slow[0]["ages"][-1] > 6, "baseline did not reproduce growing live age"
    return {
        "implementation": name, "duration_s": duration,
        "source_fps": FPS, "slow_consumer_fps": SLOW_FPS,
        "source_geometry": "960x540", "pipe_capacity_override": False,
        "url_requests": url_calls, "websocket_connections": websocket_connections,
        "full_pipeline_restarts": len(slow) - 1,
        "old_consumers_stopped_before_old_bridge_closed": True,
        "all_old_bridge_read_and_write_descriptors_closed": True,
        "fresh_pipe_inodes_per_session": True, "all_socket_sessions_closed": True,
        "healthy_peer_restarts": 0,
        "healthy_peer_consumer_age": summarize(healthy[0]["ages"]),
        "sessions": decoded_sessions, "events": events,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("validation/live-recovery-results.json"))
    parser.add_argument("--duration", type=float, default=24)
    parser.add_argument("--current-only", action="store_true", help="Rerun only the changed implementation")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    folder = args.output.parent / "live-recovery-media"
    folder.mkdir(exist_ok=True)
    spec = importlib.util.spec_from_file_location(
        "baseline_bridge_live_probe", args.baseline / "src/surveillance/services/ws_bridge.py"
    )
    assert spec and spec.loader
    baseline = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = baseline
    spec.loader.exec_module(baseline)
    frames = encoded_frames(folder)
    results = []
    for name, bridge_type, recover in (("layouts3-baseline", baseline.WebSocketBridge, False),
                                       ("liveedge-current", WebSocketBridge, True)):
        if args.current_only and not recover:
            continue
        print(f"Starting {name} for {args.duration:g} seconds", flush=True)
        result = asyncio.run(trial(name, bridge_type, frames, folder, args.duration, recover))
        results.append(result)
        args.output.write_text(json.dumps({
            "scope": "Native transport and actual LiveView lifecycle with controlled reader; not GUI or NAS performance",
            "frame_age_measurement": "Per-picture source sequence in valid H.264 SEI; monotonic source-generation clock",
            "results": results,
        }, indent=2) + "\n")
        print(json.dumps({"implementation": name, "restarts": result["full_pipeline_restarts"],
                          "sessions": result["sessions"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
