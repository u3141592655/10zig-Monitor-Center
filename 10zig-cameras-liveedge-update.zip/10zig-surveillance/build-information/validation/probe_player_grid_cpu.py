#!/usr/bin/env python3
"""A controlled local grid throughput probe, not a 10ZiG benchmark."""
import argparse
import contextlib
import faulthandler
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("--players", type=int, default=1)
parser.add_argument("--cpus", type=int, default=1)
parser.add_argument("--seconds", type=int, default=10)
parser.add_argument("--mode", choices=("timed", "raw"), default="timed")
parser.add_argument("--threads", type=int, default=0)
parser.add_argument("--fast-scaling", action="store_true")
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
os.sched_setaffinity(0, set(sorted(os.sched_getaffinity(0))[:args.cpus]))
os.environ["SURVEILLANCE_MPV_OPTS"] = f"hwdec=no vd-lavc-threads={args.threads}"

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib
from surveillance.ui.mpv_widget import MpvGLArea

class Probe(MpvGLArea):
    def __init__(self):
        self.frames = 0
        self.last_pts = None
        self.renders = []
        super().__init__()
    def _on_render(self, area, context):
        begin = time.monotonic()
        result = super()._on_render(area, context)
        if self._url:
            self.frames += 1
            self.renders.append(time.monotonic()-begin)
        return result

Gtk.init()
window = Gtk.Window(title="Controlled grid CPU comparison")
window.set_default_size(1120, 720)
grid = Gtk.Grid()
grid.set_column_homogeneous(True)
grid.set_row_homogeneous(True)
window.set_child(grid)
players = [Probe() for _ in range(args.players)]
side = math.ceil(math.sqrt(args.players))
for index, player in enumerate(players):
    player.set_grid_mode(args.fast_scaling)
    grid.attach(player, index % side, index // side, 1, 1)
processes = []
samples = [[] for _ in players]
loop = GLib.MainLoop()
start = None
deadline = time.monotonic()+10

def finish():
    loop.quit()
    return False

def sample():
    wall = time.monotonic()-start
    for index, player in enumerate(players):
        samples[index].append({"wall": wall, "pts": player.last_pts,
                               "renders": player.frames})
    return True

def begin():
    global start
    if not all(player._initialized for player in players):
        if time.monotonic() >= deadline:
            raise RuntimeError("Player initialization timed out")
        return True
    start = time.monotonic()
    for player in players:
        def position(name, value, player=player):
            if value is not None:
                player.last_pts = float(value)
        player._mpv.observe_property("time-pos", position)
        command = ["/tmp/10zig-surveillance-runtime/bin/ffmpeg", "-hide_banner",
                   "-loglevel", "error", "-re", "-i", "/tmp/mpv-paced-research/fixture1080.mkv",
                   "-map", "0:v:0", "-an", "-c:v", "copy"]
        command += (["-f", "h264", "pipe:1"] if args.mode == "raw" else
                    ["-f", "matroska", "-cluster_time_limit", "100", "-flush_packets", "1", "pipe:1"])
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        processes.append(process)
        player.set_mute(True)
        player.play(f"fd://{process.stdout.fileno()}", live=True,
                    low_latency=args.mode == "raw", muxed_audio=args.mode == "timed",
                    video_format="h264" if args.mode == "raw" else "")
        player._stop_cache_control()
    GLib.timeout_add(250, sample)
    GLib.timeout_add(args.seconds*1000, finish)
    return False

faulthandler.dump_traceback_later(45)
window.present()
GLib.timeout_add(100, begin)
GLib.timeout_add((args.seconds+12)*1000, finish)
loop.run()
summary = []
for index, player in enumerate(players):
    valid = [r for r in samples[index] if r["wall"]>=3 and r["pts"] is not None]
    if len(valid)<2:
        summary.append({"tile": index+1, "error": "insufficient video progress"})
        continue
    first, last = valid[0], valid[-1]
    duration = last["wall"]-first["wall"]
    ordered = sorted(player.renders)
    summary.append({"tile": index+1, "clock_rate": (last["pts"]-first["pts"])/duration,
                    "render_callback_rate": (last["renders"]-first["renders"])/duration,
                    "last_pts": last["pts"], "elapsed": last["wall"],
                    "render_ms_median": statistics.median(ordered)*1000,
                    "render_ms_p95": ordered[int(len(ordered)*.95)]*1000,
                    "render_ms_max": max(ordered)*1000})
result = {"players": args.players, "mode": args.mode, "cpu_affinity_count": args.cpus,
          "decode_threads_option": args.threads, "seconds": args.seconds,
          "fast_scaling": args.fast_scaling,
          "physical_10zig": False, "software_GL_virtual_display": True,
          "source": "1920x1080 30fps H264 testsrc2, encoded, ffmpeg -re paced, muted",
          "clock_note": "Raw time-pos is synthetic with 25fps override; rate1.2 corresponds to 30fps actual. Timed clock is true encoded media time.",
          "scaling_options": {name: players[0]._mpv[name] for name in (
              "scale", "dscale", "cscale", "correct-downscaling", "linear-downscaling", "sigmoid-upscaling")},
          "summary": summary, "samples": samples}
args.output.write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="samples"}), flush=True)
faulthandler.cancel_dump_traceback_later()
for player in players:
    player.stop()
for process in processes:
    process.terminate()
for process in processes:
    with contextlib.suppress(Exception):
        process.wait(timeout=.5)
    if process.poll() is None:
        process.kill()
    process.stdout.close()
window.destroy()
