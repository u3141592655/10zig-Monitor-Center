#!/usr/bin/env python3
"""Exercise the actual GTK/libmpv detector with encoded paced video.

This deliberately slows a continuously advancing timed consumer to 0.5x.
It is a backlog-recovery regression, not a 10ZiG hardware benchmark or a
claim about NAS-to-screen latency. A separate raw phase verifies the
stop-player-before-closing-producer lifecycle on fresh pipe playback.
"""
import argparse
import contextlib
import faulthandler
import json
import os
from pathlib import Path
import subprocess
import time

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk
from surveillance.ui.mpv_widget import MpvGLArea

parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--mode", choices=("timed", "raw"), default="timed")
args = parser.parse_args()

class Probe(MpvGLArea):
    def __init__(self):
        self.frames = 0
        super().__init__()

    def _on_render(self, area, context):
        result = super()._on_render(area, context)
        if self._url:
            self.frames += 1
        return result

Gtk.init()
window = Gtk.Window(title="Live backlog encoded-video regression")
window.set_default_size(640, 400)
player = Probe()
window.set_child(player)
loop = GLib.MainLoop()
samples = []
events = []
producers = []
current = None
phase = 0
start = time.monotonic()
phase_start = start
detected = None
finished = False

def launch(slow):
    global current, phase_start
    command = ["/tmp/10zig-surveillance-runtime/bin/ffmpeg", "-hide_banner",
               "-loglevel", "error", "-re", "-i", "/tmp/mpv-paced-research/fixture.mkv"]
    if args.mode == "timed":
        command += ["-c", "copy", "-f", "matroska", "-cluster_time_limit", "100",
                    "-flush_packets", "1", "pipe:1"]
    else:
        command += ["-map", "0:v:0", "-an", "-c:v", "copy", "-f", "h264", "pipe:1"]
    current = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    producers.append(current)
    phase_start = time.monotonic()
    player.set_mute(True)
    player.play(f"fd://{current.stdout.fileno()}", live=True,
                low_latency=args.mode == "raw", muxed_audio=args.mode == "timed",
                video_format="h264" if args.mode == "raw" else "")
    player._stop_cache_control()
    if slow:
        player._mpv.speed = 0.5

def stop_producer_after_player():
    player.stop()
    if current and current.poll() is None:
        current.terminate()
        with contextlib.suppress(subprocess.TimeoutExpired):
            current.wait(timeout=2)
        if current.poll() is None:
            current.kill()
    if current and current.stdout:
        current.stdout.close()

def finish():
    global finished
    finished = True
    loop.quit()
    return False

def sample():
    global phase, detected
    now = time.monotonic()
    # The production watchdog itself only reads asynchronous cached values.
    reason = player.live_backlog_reason(now)
    observations = dict(player._live_observations)
    if args.mode == "raw":
        # This synthetic clock is recorded ONLY as a progress probe. It is
        # not fed to the live-age detector or interpreted as real time.
        with contextlib.suppress(Exception):
            observations["time-pos"] = player._mpv.time_pos
    record = {"wall": round(now-start, 4), "phase_wall": round(now-phase_start, 4),
              "phase": phase, "pts": observations.get("time-pos"),
              "cache": observations.get("demuxer-cache-duration"),
              "render_callbacks": player.frames, "reason": reason}
    samples.append(record)
    switch = (reason is not None) if args.mode == "timed" else now-phase_start >= 4
    if phase == 0 and switch:
        detected = record
        events.append({"event": "stop_before_writer_close", "wall": round(now-start, 4)})
        stop_producer_after_player()
        phase = 1
        launch(False)
        events.append({"event": "fresh_pipe_play", "wall": round(time.monotonic()-start, 4)})
    elif phase == 1 and now-phase_start >= 7:
        return finish()
    return not finished

def begin():
    if not player._initialized:
        if time.monotonic()-start > 7:
            raise RuntimeError("GTK/libmpv initialization timed out")
        return True
    launch(args.mode == "timed")
    GLib.timeout_add(250, sample)
    return False

faulthandler.dump_traceback_later(40)
window.present()
GLib.timeout_add(100, begin)
GLib.timeout_add(30000, finish)
loop.run()

def metrics(which):
    valid = [r for r in samples if r["phase"] == which and r["pts"] is not None
             and r["phase_wall"] >= 2]
    if len(valid) < 2:
        return {"samples": len(valid), "progressed": False}
    first, last = valid[0], valid[-1]
    return {"samples": len(valid), "progressed": last["pts"] > first["pts"],
            "pts_advance": round(last["pts"]-first["pts"], 3),
            "wall_advance": round(last["wall"]-first["wall"], 3),
            "media_seconds_per_wall_second": (last["pts"]-first["pts"])/(last["wall"]-first["wall"]),
            "render_callbacks": last["render_callbacks"]-first["render_callbacks"],
            "recovery_reason_count": sum(r["reason"] is not None for r in valid)}

result = {"mode": args.mode, "physical_10zig": False, "virtual_display": True,
          "source": "Encoded 640x360 15fps H264+PCMU, ffmpeg -re paced pipe",
          "simulation": "0.5x timed consumer" if args.mode == "timed" else "normal untimed raw NAL",
          "detected": detected, "before": metrics(0), "after_fresh_pipe": metrics(1),
          "events": events, "samples": samples}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({key: value for key, value in result.items() if key != "samples"}), flush=True)
faulthandler.cancel_dump_traceback_later()
stop_producer_after_player()
window.destroy()
if not result["before"]["progressed"] or not result["after_fresh_pipe"]["progressed"]:
    raise SystemExit("Video did not advance in both phases")
if args.mode == "timed" and (not detected or not detected["reason"]):
    raise SystemExit("Slow progressing timed player was not detected")
