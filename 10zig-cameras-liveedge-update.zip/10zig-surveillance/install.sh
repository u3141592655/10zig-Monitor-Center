#!/bin/sh
# Cameras: PeakOS grid playback and live recovery edition. Install from USB.
# Existing camera profiles and recording settings are never replaced.
set -eu

SURV_RELEASE='0.15.0+peakos.layouts4'
SURV_ROOT='/boot/custom-apps/10zig-surveillance'
SURV_LOCAL='/tmp/config/files/surveillance-client'
SURV_CAMERAS='/tmp/config/files/Cameras.sh'
SURV_CONN='/tmp/config/xmlconfig/user/software/shellscript/connections/Q2FtZXJhcw==.xml'
SURV_ARCHIVE='/boot/config.tar.gz'
SURV_SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
SURV_EXPECTED='91dc667cc2f2c1b49af9ec06a6ba5a7df1253ee36dcc9394a5eb6113a45973c4'
SURV_LOG='/tmp/10zig-surveillance-install.log'
SURV_STAGE=''
SURV_COMMITTED=no

surv_fail() {
    printf '\n%s\n' "$1" >&2
    exit 1
}
surv_cleanup() {
    SURV_RESULT=$?
    if [ -n "$SURV_STAGE" ] && [ -d "$SURV_STAGE" ]; then
        rm -rf -- "$SURV_STAGE"
    fi
    if [ "$SURV_RESULT" -ne 0 ] && [ "$SURV_COMMITTED" = yes ]; then
        printf '%s\n' 'The update did not finish. Your previous files are backed up.' >&2
        printf '%s\n' 'To restore them, run: sh /boot/custom-apps/10zig-surveillance/rollback.sh' >&2
    fi
}
trap surv_cleanup EXIT
trap 'exit 1' HUP INT TERM

[ "$(id -u)" = 0 ] || surv_fail 'Run this from the PeakOS administrative console (Ctrl+Alt+Shift+0).'
[ "$(uname -m)" = x86_64 ] || surv_fail 'This package is for x86_64 PeakOS only.'
[ -d /tmp/config ] && command -v freeze >/dev/null 2>&1 || \
    surv_fail 'PeakOS configuration storage and the freeze utility are required.'
command -v flock >/dev/null 2>&1 || surv_fail 'The PeakOS flock utility was not found.'
exec 9>/tmp/10zig-surveillance.lock
flock -n 9 || surv_fail 'Close Cameras and wait for it to exit before updating.'

for SURV_REQUIRED in app/surveillance/__main__.py start-surveillance.sh rollback.sh SHA256SUMS.txt; do
    [ -f "$SURV_SOURCE/$SURV_REQUIRED" ] || surv_fail "The ZIP was not fully extracted: missing $SURV_REQUIRED."
done
printf '%s\n' 'Checking package files...'
if ! (cd "$SURV_SOURCE" && sha256sum -c SHA256SUMS.txt) > "$SURV_LOG" 2>&1; then
    tail -n 15 "$SURV_LOG" >&2
    surv_fail 'A package file is missing or damaged. Extract a fresh copy of the ZIP.'
fi

SURV_IMAGE="$SURV_ROOT/surveillance-runtime.squashfs"
SURV_COPY_RUNTIME=no
if [ -f "$SURV_IMAGE" ]; then
    printf '%s\n' 'Verifying the existing native runtime...'
    SURV_SUM=$(sha256sum "$SURV_IMAGE")
    [ "${SURV_SUM%% *}" = "$SURV_EXPECTED" ] || \
        surv_fail 'The existing runtime is a different build. Nothing was replaced. Keep the working installation and use its matching update package.'
elif [ -f "$SURV_SOURCE/surveillance-runtime.squashfs" ]; then
    SURV_SUM=$(sha256sum "$SURV_SOURCE/surveillance-runtime.squashfs")
    [ "${SURV_SUM%% *}" = "$SURV_EXPECTED" ] || surv_fail 'The supplied runtime does not match this release.'
    SURV_COPY_RUNTIME=yes
else
    surv_fail 'The small update requires the previously installed native runtime at /boot/custom-apps/10zig-surveillance. Use the full ZIP for a fresh installation.'
fi

# Stage every new executable before touching the existing installed app.
mkdir -p "$SURV_ROOT"
SURV_STAGE=$(mktemp -d "$SURV_ROOT/.update.XXXXXX")
cp -R "$SURV_SOURCE/app" "$SURV_STAGE/app"
cp "$SURV_SOURCE/start-surveillance.sh" "$SURV_STAGE/start-surveillance.sh"
cp "$SURV_SOURCE/rollback.sh" "$SURV_STAGE/rollback.sh"
# The /boot filesystem may not support chmod. These files are run via sh;
# executable permissions are applied only to the saved /tmp/config launchers.
if [ "$SURV_COPY_RUNTIME" = yes ]; then
    printf '%s\n' 'Copying the native runtime to internal storage...'
    cp "$SURV_SOURCE/surveillance-runtime.squashfs" "$SURV_STAGE/surveillance-runtime.squashfs"
    SURV_SUM=$(sha256sum "$SURV_STAGE/surveillance-runtime.squashfs")
    [ "${SURV_SUM%% *}" = "$SURV_EXPECTED" ] || surv_fail 'The internal runtime copy could not be verified.'
fi

SURV_BACKUP=$(mktemp -d "$SURV_ROOT/backup-before-layouts.XXXXXX")
if [ -d "$SURV_LOCAL" ]; then cp -R "$SURV_LOCAL" "$SURV_BACKUP/local"; fi
if [ -f "$SURV_CAMERAS" ]; then cp "$SURV_CAMERAS" "$SURV_BACKUP/Cameras.sh"; fi
if [ -f "$SURV_CONN" ]; then cp "$SURV_CONN" "$SURV_BACKUP/Cameras.xml"; fi
if [ -f "$SURV_ROOT/start-surveillance.sh" ]; then
    cp "$SURV_ROOT/start-surveillance.sh" "$SURV_BACKUP/root-launcher.sh"
fi
if [ -f "$SURV_ROOT/release.txt" ]; then cp "$SURV_ROOT/release.txt" "$SURV_BACKUP/release.txt"; fi
printf '%s\n' "$SURV_BACKUP" > "$SURV_ROOT/last-backup.txt"
printf '%s\n' 'The existing profile is preserved in place, not copied into this backup.' > "$SURV_BACKUP/PROFILE-NOTE.txt"

mv "$SURV_STAGE/rollback.sh" "$SURV_ROOT/rollback.sh"
SURV_COMMITTED=yes
if [ -d "$SURV_ROOT/app" ]; then mv "$SURV_ROOT/app" "$SURV_BACKUP/app"; fi
mv "$SURV_STAGE/app" "$SURV_ROOT/app"
if [ "$SURV_COPY_RUNTIME" = yes ]; then
    mv "$SURV_STAGE/surveillance-runtime.squashfs" "$SURV_IMAGE"
fi
mv "$SURV_STAGE/start-surveillance.sh" "$SURV_ROOT/start-surveillance.sh"

# Keep the existing persistent profile and saved NAS settings untouched.
mkdir -p "$SURV_ROOT/profile" "$SURV_LOCAL"
cp "$SURV_ROOT/start-surveillance.sh" "$SURV_LOCAL/start-surveillance.sh.new"
chmod 700 "$SURV_LOCAL/start-surveillance.sh.new"
mv "$SURV_LOCAL/start-surveillance.sh.new" "$SURV_LOCAL/start-surveillance.sh"
printf '%s\n' "$SURV_IMAGE" > "$SURV_LOCAL/image-path.txt"
cat > "$SURV_CAMERAS.new" <<'CAMERAS'
#!/bin/sh
exec /bin/sh /tmp/config/files/surveillance-client/start-surveillance.sh
CAMERAS
chmod 700 "$SURV_CAMERAS.new"
mv "$SURV_CAMERAS.new" "$SURV_CAMERAS"

# PeakOS 16.5.40 quotes the CONN_PNAME_SUBST argument incorrectly.
# Correct only the already-existing Cameras connection; never edit others.
if [ -f "$SURV_CONN" ]; then
    sed 's/CONN_PNAME_SUBST/Cameras/g' "$SURV_CONN" > "$SURV_CONN.new"
    mv "$SURV_CONN.new" "$SURV_CONN"
fi

printf '%s\n' 'Saving the Cameras launcher in PeakOS configuration...'
freeze
SURV_VERIFY=$(mktemp -d /tmp/10zig-surveillance-save.XXXXXX)
SURV_SAVED=yes
SURV_VERIFY_FILES='config/files/surveillance-client/start-surveillance.sh config/files/surveillance-client/image-path.txt config/files/Cameras.sh'
if [ -f "$SURV_CONN" ]; then
    SURV_VERIFY_FILES="$SURV_VERIFY_FILES config/xmlconfig/user/software/shellscript/connections/Q2FtZXJhcw==.xml"
fi
for SURV_REL in $SURV_VERIFY_FILES; do
    if ! tar -xOzf "$SURV_ARCHIVE" "$SURV_REL" > "$SURV_VERIFY/saved" || \
       ! cmp -s "$SURV_VERIFY/saved" "/tmp/$SURV_REL"; then
        SURV_SAVED=no
        break
    fi
done
rm -f "$SURV_VERIFY/saved"
rmdir "$SURV_VERIFY"
if [ "$SURV_SAVED" != yes ]; then
    printf '%s\n' "Backup: $SURV_BACKUP" >&2
    surv_fail 'The files were installed, but PeakOS did not save the launcher successfully. Do not reboot yet. Run: sh /boot/custom-apps/10zig-surveillance/rollback.sh'
fi

printf '%s\n' "$SURV_RELEASE" > "$SURV_ROOT/release.txt"
for SURV_DOC in START-HERE.txt ROLLBACK.txt CHANGELOG.txt RESEARCH.txt; do
    if [ -f "$SURV_SOURCE/$SURV_DOC" ] && [ "$SURV_SOURCE" != "$SURV_ROOT" ]; then
        cp "$SURV_SOURCE/$SURV_DOC" "$SURV_ROOT/$SURV_DOC"
    fi
done
sync
printf '\n%s\n' "Cameras $SURV_RELEASE installed. Your existing profile has been preserved."
printf '%s\n' "Rollback backup: $SURV_BACKUP"
printf '\n%s\n' 'Restart the 10ZiG normally, remove the USB, and launch Cameras.'
printf '%s\n' 'If no Cameras connection exists, follow the short Connection Manager instructions in START-HERE.txt.'
