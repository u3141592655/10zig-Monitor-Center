#!/bin/sh
# Community native Surveillance Station client for PeakOS 16.5 x86_64.
# Performance edition 0.15.0+peakos.layouts2: unchanged runtime, updated app overlay.
# Mounts this package's application runtime read-only. Does not modify system libraries.
set -u

SURV_BUILD_ID='surveillance-0.15.0-peakos16.5-x86_64-20261030'
SURV_EXPECTED_SHA256='91dc667cc2f2c1b49af9ec06a6ba5a7df1253ee36dcc9394a5eb6113a45973c4'
SURV_RUNTIME_NAME='surveillance-runtime.squashfs'
SURV_PREFIX='/tmp/10zig-surveillance-runtime'
SURV_LOCAL='/tmp/config/files/surveillance-client'
SURV_LOG='/tmp/10zig-surveillance.log'
SURV_ERROR='/tmp/10zig-surveillance-error.txt'
SURV_SELF="$SURV_LOCAL/start-surveillance.sh"

if [ "${1:-}" = '--show-error' ]; then
    cat "${2:-$SURV_ERROR}"
    printf '\nPress Enter to close this window. '
    IFS= read -r SURV_REPLY || :
    exit 0
fi

surv_error() {
    printf '%s\n' "$1" >&2
    {
        printf '%s\n\n' "$1"
        if [ -s "$SURV_LOG" ]; then
            printf 'Last application messages:\n'
            tail -n 45 "$SURV_LOG"
        fi
    } > "$SURV_ERROR"
    if [ -n "${DISPLAY:-}" ] && command -v rxvt-unicode >/dev/null 2>&1; then
        rxvt-unicode -title 'Surveillance Station - message' -geometry 100x25 \
            -e /bin/sh "$SURV_SELF" --show-error "$SURV_ERROR" >/dev/null 2>&1 &
    fi
    exit 1
}

[ "$(id -u)" = 0 ] || surv_error 'This launcher needs the normal PeakOS root desktop session to mount its read-only application runtime.'
[ "$(uname -m)" = x86_64 ] || surv_error 'This package requires an x86_64 10ZiG. It does not support ARM or a 32-bit operating system.'

# One instance owns the mount and log. flock releases automatically on exit.
exec 9>/tmp/10zig-surveillance.lock
flock -n 9 || surv_error 'Surveillance Station is already running. Return to its existing window.'
: > "$SURV_LOG"

# This edition always uses internal storage. Falling back to an attached USB
# would create a different profile and make saved credentials appear to vanish.
SURV_IMAGE='/boot/custom-apps/10zig-surveillance/surveillance-runtime.squashfs'
[ -f "$SURV_IMAGE" ] || surv_error 'The internally installed runtime was not found. Run install.sh from the extracted full performance-edition ZIP.'

SURV_APP_DIR=${SURV_IMAGE%/*}
SURV_APP="$SURV_APP_DIR/app"
[ -f "$SURV_APP/surveillance/__main__.py" ] || surv_error 'The updated Cameras application files are missing. Run install.sh from the extracted performance-edition ZIP again.'
SURV_PROFILE="$SURV_APP_DIR/profile"
mkdir -p "$SURV_PROFILE/config" "$SURV_PROFILE/data" "$SURV_PROFILE/state" \
    /tmp/10zig-surveillance-cache || surv_error 'The application folder must be writable so the app can save its NAS profile and preferences.'
[ -w "$SURV_PROFILE/config" ] || surv_error 'The profile folder is not writable. Restore write access to the application storage and try again.'

if mountpoint -q "$SURV_PREFIX"; then
    [ -r "$SURV_PREFIX/10zig-build-id.txt" ] || surv_error 'The runtime mount location is already used by something else. Restart the 10ZiG and try again.'
    [ "$(cat "$SURV_PREFIX/10zig-build-id.txt")" = "$SURV_BUILD_ID" ] || \
        surv_error 'A different version of this runtime is mounted. Restart the 10ZiG before using this package.'
else
    [ ! -L "$SURV_PREFIX" ] || surv_error 'The runtime path is a symbolic link. Installation has stopped.'
    mkdir -p "$SURV_PREFIX" || surv_error 'Cannot create the temporary runtime mount directory.'
    if [ -n "$(ls -A "$SURV_PREFIX")" ]; then
        surv_error 'The temporary runtime directory is not empty. Restart the 10ZiG and try again.'
    fi
    SURV_ACTUAL_SHA256=$(sha256sum "$SURV_IMAGE") || surv_error 'Cannot read the application runtime from storage.'
    SURV_ACTUAL_SHA256=${SURV_ACTUAL_SHA256%% *}
    [ "$SURV_ACTUAL_SHA256" = "$SURV_EXPECTED_SHA256" ] || \
        surv_error 'The runtime is incomplete or does not match this launcher. Replace the application folder with a fresh copy of the package.'
    mount -t squashfs -o loop,ro,nodev,nosuid "$SURV_IMAGE" "$SURV_PREFIX" >> "$SURV_LOG" 2>&1 || \
        surv_error 'PeakOS could not mount the read-only application runtime. The mount error is shown below.'
fi

# Keep app preferences beside the runtime and cache in RAM, outside the PeakOS config archive.
# Run a child environment; the PeakOS desktop keeps its own libraries and HOME.
env \
    PATH="$SURV_PREFIX/bin:${PATH:-/usr/bin:/bin}" \
    LD_LIBRARY_PATH="$SURV_PREFIX/lib" \
    PYTHONPATH="$SURV_APP" \
    PYTHONNOUSERSITE=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    GI_TYPELIB_PATH="$SURV_PREFIX/lib/girepository-1.0" \
    GSETTINGS_SCHEMA_DIR="$SURV_PREFIX/share/glib-2.0/schemas" \
    XDG_DATA_DIRS="$SURV_PREFIX/share:/usr/local/share:/usr/share" \
    XDG_CONFIG_HOME="$SURV_PROFILE/config" \
    XDG_DATA_HOME="$SURV_PROFILE/data" \
    XDG_STATE_HOME="$SURV_PROFILE/state" \
    XDG_CACHE_HOME=/tmp/10zig-surveillance-cache \
    SURVEILLANCE_CREDENTIAL_STORE=file \
    SURVEILLANCE_MPV_OPTS="${SURVEILLANCE_MPV_OPTS:-hwdec=no}" \
    GDK_BACKEND=x11 \
    GSK_RENDERER=gl \
    GDK_DEBUG=gl-prefer-gl \
    "$SURV_PREFIX/bin/python" -m surveillance "$@" >> "$SURV_LOG" 2>&1
SURV_STATUS=$?
sync
if ! umount "$SURV_PREFIX" >> "$SURV_LOG" 2>&1; then
    surv_error 'The application closed, but its runtime is still in use. Shut down the 10ZiG normally before moving or deleting the application files.'
fi
if [ "$SURV_STATUS" -ne 0 ]; then
    surv_error "Surveillance Station stopped with exit code $SURV_STATUS. Its recent messages are shown below."
fi
exit 0
