# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Data models for Synology Surveillance Station API responses."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class CameraStatus(IntEnum):
    """Camera.List v9 status; the others (deleted, unavailable,
    unauthorized...) land in _missing_ and count as not streaming."""

    ENABLED = 1
    DISCONNECTED = 3
    DISABLED = 7

    @classmethod
    def _missing_(cls, value: object) -> CameraStatus:
        """Handle unknown status values from the API."""
        val: int = int(value)  # type: ignore[call-overload]
        obj = int.__new__(cls, val)
        obj._name_ = f"UNKNOWN_{val}"
        obj._value_ = val
        result: CameraStatus = obj
        return result


@dataclass
class Camera:
    """Surveillance camera."""

    id: int
    name: str
    model: str
    vendor: str
    status: CameraStatus
    is_ptz: bool = False
    has_audio: bool = False
    has_speaker: bool = False

    @classmethod
    def from_api(cls, data: dict) -> Camera:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            name=data.get("newName", data.get("name", "")),
            model=data.get("model", ""),
            vendor=data.get("vendor", ""),
            status=CameraStatus(data.get("status", 0)),
            is_ptz=bool(data.get("ptzDirection", 0)),
            # audioCodec is 0 when the camera has no audio track, a
            # nonzero codec id when it does -- confirmed live as a
            # genuine top-level Camera List field on this DSM/API
            # version (audioType, claimed as the only top-level audio
            # field upstream, was absent entirely from the same live
            # response). Checking both covers whichever field a given
            # DSM version actually populates.
            has_audio=bool(data.get("audioCodec", 0) or data.get("audioType", 0)),
            # audioOut is the camera's own speaker capability (two-way
            # audio) — separate from audioType, which is about the
            # camera's mic recording into the stream, not its speaker.
            has_speaker=bool(data.get("audioOut", False)),
        )


DETECTION_LABELS: dict[int, str] = {
    1: "Person",
    2: "Vehicle",
    3: "Animal",
    4: "Tampering",
    6: "Crowd",
    7: "License Plate",
    8: "Over-occupancy",
}


def decode_detection_labels(bitmask: int) -> list[str]:
    """Decode a defaultLabel bitmask into human-readable detection tags."""
    labels = []
    for bit, name in DETECTION_LABELS.items():
        if bitmask & (1 << bit):
            labels.append(name)
    return labels


@dataclass
class Recording:
    """A camera recording."""

    id: int
    camera_id: int
    camera_name: str
    start_time: int  # unix timestamp
    stop_time: int
    file_size: int = 0
    # Recording.List's "type" field. Presumed to be the same enum as
    # Event.event_type just below (mode: 1=motion, 2=alarm, 3=manual,
    # etc.) since both come from a "why was this recorded" concept and
    # get_stream_url/ws_bridge.py's History play command both send it
    # on as recEvtType -- not independently confirmed, since nothing
    # has decoded the value against a recording of a known trigger type.
    event_type: int = 0
    # Which storage mount (of possibly several -- external USB, a
    # second volume, ...) and which archive within it this recording's
    # file lives on. Opaque beyond that: DSM's own clients pass them
    # straight through to eventId/mountId/archId (see get_stream_url)
    # or mountId/archId (the WS History play command, ws_bridge.py)
    # without this app ever needing to interpret them itself.
    mount_id: int = 0
    arch_id: int = 0
    detection_label: int = 0

    @classmethod
    def from_api(cls, data: dict) -> Recording:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            camera_id=data.get("cameraId", 0),
            camera_name=data.get("camera_name", data.get("cameraName", "")),
            start_time=data.get("startTime", 0),
            stop_time=data.get("stopTime", 0),
            file_size=data.get("fileSize", 0),
            event_type=data.get("type", 0),
            mount_id=data.get("mountId", 0),
            arch_id=data.get("archId", 0),
            detection_label=data.get("defaultLabel", 0),
        )


@dataclass
class Snapshot:
    """A camera snapshot."""

    id: int
    camera_name: str
    create_time: int
    # SnapShot::List identifies the camera by name only, so camera_id is
    # not in the response; the snapshots page fills it in from the camera
    # list to drive per-camera filtering.
    camera_id: int = 0
    # Base64-encoded JPEG, already sized for a list thumbnail, included
    # inline in SnapShot::List's response, so browsing the list doesn't
    # need a separate per-row download the way Recording thumbnails do.
    image_data: str = ""

    @classmethod
    def from_api(cls, data: dict) -> Snapshot:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            camera_name=data.get("camName", ""),
            create_time=data.get("createdTm", data.get("displayTm", 0)),
            image_data=data.get("imageData", ""),
        )


@dataclass
class Event:
    """A surveillance event (recording triggered by motion, alarm, etc.)."""

    id: int
    camera_id: int
    camera_name: str
    event_type: int  # mode: 1=motion, 2=alarm, 3=manual, etc.
    start_time: int
    stop_time: int = 0
    mount_id: int = 0
    arch_id: int = 0
    detection_label: int = 0
    # Seconds into the parent recording file where this event actually starts.
    # Set by the event backends (see services.event_backend) rather than by
    # Event::List, since id/mount_id/arch_id there refer to the whole
    # (much longer) recording file, not this specific moment within it.
    seek_offset: int = 0
    # Raw event_map [value, flag, reserved] flag and reserved fields, set
    # only by LegacyEventBackend (see services.legacy_event) and 0 for any
    # other event. Classify an event through its EventBackend rather than
    # reading these directly. See LEGACY_EVENT_BITMASK.md for what they carry.
    legacy_flag: int = 0
    legacy_reserved: int = 0
    # EventCenter.Event::List's event_type and object_type, set only by
    # EventCenterBackend (see services.event_center) and 0 for any other
    # event. Not event_type above, which is Event::List's own "mode".
    event_center_type: int = 0
    object_type: int = 0

    @classmethod
    def from_api(cls, data: dict) -> Event:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            camera_id=data.get("cameraId", 0),
            camera_name=data.get("camera_name", data.get("cameraName", "")),
            event_type=data.get("mode", data.get("type", data.get("eventType", 0))),
            start_time=data.get("startTime", 0),
            stop_time=data.get("stopTime", 0),
            mount_id=data.get("mountId", 0),
            arch_id=data.get("archId", 0),
            detection_label=data.get("defaultLabel", 0),
        )


@dataclass
class Alert:
    """A surveillance alert."""

    id: int
    camera_id: int
    camera_name: str
    alert_type: int
    timestamp: int
    is_read: bool = False

    @classmethod
    def from_api(cls, data: dict) -> Alert:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            camera_id=data.get("cameraId", 0),
            camera_name=data.get("cameraName", ""),
            alert_type=data.get("alertType", 0),
            timestamp=data.get("timestamp", 0),
            is_read=data.get("isRead", False),
        )


@dataclass
class HomeModeInfo:
    """Home mode status."""

    on: bool = False

    @classmethod
    def from_api(cls, data: dict) -> HomeModeInfo:  # type: ignore[type-arg]
        return cls(on=data.get("on", False))


@dataclass
class PtzPreset:
    """PTZ preset position."""

    id: int
    name: str
    position: int = 0

    @classmethod
    def from_api(cls, data: dict) -> PtzPreset:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            name=data.get("name", ""),
            position=data.get("position", 0),
        )


@dataclass
class PtzPatrol:
    """PTZ patrol route. Run it with ptz.run_patrol(); the route itself
    lives on the NAS."""

    id: int
    name: str

    @classmethod
    def from_api(cls, data: dict) -> PtzPatrol:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            name=data.get("name", ""),
        )


@dataclass
class ApiInfo:
    """API endpoint information from SYNO.API.Info."""

    path: str
    max_version: int

    @classmethod
    def from_api(cls, data: dict) -> ApiInfo:  # type: ignore[type-arg]
        return cls(
            path=data.get("path", ""),
            max_version=data.get("maxVersion", 1),
        )


@dataclass
class License:
    """A Surveillance Station camera license."""

    id: int
    key: str
    quota: int
    expired_date: int  # unix timestamp, 0 = never expires
    is_expired: bool = False
    is_migrated: bool = False

    @classmethod
    def from_api(cls, data: dict) -> License:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            key=data.get("key", ""),
            quota=data.get("quota", 0),
            expired_date=data.get("expired_date", 0),
            is_expired=data.get("isExpired", False),
            is_migrated=data.get("isMigrated", False),
        )


@dataclass
class LicenseInfo:
    """License summary with list of individual licenses."""

    key_max: int
    key_total: int
    key_used: int
    licenses: list[License]

    @classmethod
    def from_api(cls, data: dict) -> LicenseInfo:  # type: ignore[type-arg]
        raw = data.get("license", [])
        return cls(
            key_max=data.get("key_max", 0),
            key_total=data.get("key_total", 0),
            key_used=data.get("key_used", 0),
            licenses=[License.from_api(lic) for lic in raw],
        )


@dataclass
class TimeLapseTask:
    """A time lapse task configuration."""

    id: int
    name: str
    camera_id: int
    camera_name: str

    @classmethod
    def from_api(cls, data: dict) -> TimeLapseTask:  # type: ignore[type-arg]
        return cls(
            id=data.get("id", 0),
            name=data.get("name", ""),
            camera_id=data.get("cameraId", 0),
            camera_name=data.get("cameraName", ""),
        )


@dataclass
class TimeLapseRecording:
    """A time lapse recording segment."""

    id: int
    camera_id: int
    camera_name: str
    start_time: int
    stop_time: int
    file_size: int = 0
    mount_id: int = 0
    arch_id: int = 0
    is_locked: bool = False
    recording: bool = False
    path: str = ""

    @classmethod
    def from_api(cls, data: dict) -> TimeLapseRecording:  # type: ignore[type-arg]
        # status_flags bit 2 = locked (from APK RecModel.isLocked)
        status_flags = data.get("status_flags", 0)
        return cls(
            id=data.get("id", 0),
            camera_id=data.get("cameraId", 0),
            camera_name=data.get("camera_name", data.get("cameraName", "")),
            start_time=data.get("startTime", 0),
            stop_time=data.get("stopTime", 0),
            file_size=data.get("event_size_bytes", 0),
            mount_id=data.get("mountId", 0),
            arch_id=data.get("archId", 0),
            is_locked=bool(status_flags & 4),
            recording=data.get("recording", False),
            path=data.get("path", ""),
        )
