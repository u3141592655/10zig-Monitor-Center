# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Credential storage for normal Linux desktops and persistent PeakOS profiles.

The standard backend remains the desktop keyring.  The PeakOS launcher selects
``SURVEILLANCE_CREDENTIAL_STORE=file`` because it has no desktop Secret Service.
That backend encrypts the credentials with Fernet in XDG_DATA_HOME.  Its local
key is stored beside the ciphertext: this prevents readable passwords in the
profile, but does not protect against someone who can read both files (including
an administrator).  Unix file modes are tightened wherever the filesystem
supports them; FAT storage cannot enforce those modes.
"""

from __future__ import annotations

import asyncio
import contextlib
import errno
import hashlib
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Iterator

if TYPE_CHECKING:
    from cryptography.fernet import Fernet

SERVICE_NAME = "surveillance-station"

log = logging.getLogger(__name__)


class CredentialStoreError(RuntimeError):
    """A persistent credential store could not be accessed safely."""


def _use_file_store() -> bool:
    return os.environ.get("SURVEILLANCE_CREDENTIAL_STORE", "").lower() == "file"


def _store_directory() -> Path:
    data_home = os.environ.get("XDG_DATA_HOME")
    base = Path(data_home) if data_home else Path.home() / ".local" / "share"
    return base / "surveillance" / "credentials"


def _profile_file(directory: Path, profile_name: str) -> Path:
    # Profile names are user input, not paths.  Hashing also avoids exposing
    # NAS/profile names in the directory listing.
    name = hashlib.sha256(profile_name.encode("utf-8")).hexdigest()
    return directory / (name + ".fernet")


def _restrict_mode(path: Path, mode: int) -> None:
    try:
        path.chmod(mode)
    except OSError as exc:
        if exc.errno not in {errno.EPERM, errno.EOPNOTSUPP, errno.ENOSYS}:
            raise
        # PeakOS persistent /boot storage may be FAT.  The encrypted store
        # must remain usable there, although FAT has no Unix access modes.
        log.debug("The credential storage filesystem does not support Unix permissions")


@contextlib.contextmanager
def _file_lock(directory: Path) -> Iterator[None]:
    import fcntl

    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    _restrict_mode(directory, 0o700)
    flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(directory / ".lock", flags, 0o600)
    try:
        _restrict_mode(directory / ".lock", 0o600)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        os.close(descriptor)


def _sync_directory(directory: Path) -> None:
    descriptor = os.open(directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        try:
            os.fsync(descriptor)
        except OSError as exc:
            if exc.errno not in {errno.EINVAL, errno.EOPNOTSUPP}:
                raise
    finally:
        os.close(descriptor)


def _atomic_write(path: Path, data: bytes) -> None:
    descriptor, temporary_name = tempfile.mkstemp(prefix=".credential-", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        _restrict_mode(temporary, 0o600)
        os.replace(temporary, path)
        _sync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def _read_file(path: Path) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, "rb") as source:
        value = source.read(65537)
    if len(value) > 65536:
        raise ValueError("Credential data is too large")
    return value


def _fernet(directory: Path, *, create: bool = False) -> Fernet:
    from cryptography.fernet import Fernet

    key_file = directory / "key"
    if not key_file.exists():
        if not create or any(directory.glob("*.fernet")):
            # Never silently replace a missing key while old passwords
            # exist; doing that would make all remaining profiles unreadable.
            raise CredentialStoreError("The saved credential key is missing")
        _atomic_write(key_file, Fernet.generate_key())
    _restrict_mode(key_file, 0o600)
    return Fernet(_read_file(key_file))


def store_credentials(profile_name: str, username: str, password: str) -> bool:
    """Persist credentials, returning False on a storage failure.

    Saving is a convenience: a storage failure must not invalidate an
    already-successful NAS login.  The login dialog reports False visibly.
    """
    if _use_file_store():
        try:
            directory = _store_directory()
            with _file_lock(directory):
                cipher = _fernet(directory, create=True)
                payload = json.dumps({
                    "version": 1,
                    "username": username,
                    "password": password,
                }, ensure_ascii=False).encode("utf-8")
                _atomic_write(_profile_file(directory, profile_name), cipher.encrypt(payload))
        except Exception as exc:
            # Exception text can contain sensitive backend values.  Log
            # only the exception type, never credential contents or paths.
            log.warning("Could not save local credentials (%s)", type(exc).__name__)
            return False
        return True

    try:
        import keyring

        keyring.set_password(SERVICE_NAME, f"{profile_name}:username", username)
        keyring.set_password(SERVICE_NAME, f"{profile_name}:password", password)
    except Exception as exc:
        log.warning("Could not save credentials to the keyring (%s)", type(exc).__name__)
        return False
    return True


def get_credentials(profile_name: str) -> tuple[str, str] | None:
    """Retrieve (username, password), or None if nothing has been saved.

    File corruption/access errors raise CredentialStoreError so the login
    dialog can tell the user that saving did not silently disappear.
    """
    if _use_file_store():
        directory = _store_directory()
        path = _profile_file(directory, profile_name)
        if not path.exists():
            return None
        try:
            with _file_lock(directory):
                # Another login may have cleared the entry while waiting.
                if not path.exists():
                    return None
                payload = json.loads(_fernet(directory).decrypt(_read_file(path)))
            if not isinstance(payload, dict) or payload.get("version") != 1:
                raise ValueError("Unsupported credential format")
            username, password = payload.get("username"), payload.get("password")
            if not isinstance(username, str) or not isinstance(password, str):
                raise ValueError("Invalid credential format")
            return username, password
        except Exception as exc:
            log.warning("Could not read local credentials (%s)", type(exc).__name__)
            raise CredentialStoreError("Saved credentials could not be read") from None

    try:
        import keyring

        username = keyring.get_password(SERVICE_NAME, f"{profile_name}:username")
        password = keyring.get_password(SERVICE_NAME, f"{profile_name}:password")
    except Exception as exc:
        log.warning("Could not read credentials from the keyring (%s)", type(exc).__name__)
        return None
    if username is None or password is None:
        return None
    return username, password


def delete_credentials(profile_name: str) -> None:
    """Forget a profile's credentials, including an unreadable local entry."""
    if _use_file_store():
        directory = _store_directory()
        path = _profile_file(directory, profile_name)
        if not path.exists():
            return
        try:
            with _file_lock(directory):
                path.unlink(missing_ok=True)
                _sync_directory(directory)
        except Exception as exc:
            log.warning("Could not remove local credentials (%s)", type(exc).__name__)
            raise CredentialStoreError("Saved credentials could not be removed") from None
        return

    try:
        import keyring
    except ImportError:
        return
    with contextlib.suppress(keyring.errors.KeyringError):
        keyring.delete_password(SERVICE_NAME, f"{profile_name}:username")
    with contextlib.suppress(keyring.errors.KeyringError):
        keyring.delete_password(SERVICE_NAME, f"{profile_name}:password")


# Both backends run away from the GTK thread.  In particular, a locked
# desktop keyring can wait for an interactive unlock prompt.

async def get_credentials_async(profile_name: str) -> tuple[str, str] | None:
    return await asyncio.to_thread(get_credentials, profile_name)


async def store_credentials_async(profile_name: str, username: str, password: str) -> bool:
    return await asyncio.to_thread(store_credentials, profile_name, username, password)


async def delete_credentials_async(profile_name: str) -> None:
    await asyncio.to_thread(delete_credentials, profile_name)
