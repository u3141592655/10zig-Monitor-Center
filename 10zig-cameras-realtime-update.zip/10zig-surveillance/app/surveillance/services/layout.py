"""Read Monitor Center layouts and explicitly create new camera-grid layouts.

The wire format follows Surveillance Station 9's own web client:
``SYNO.SurveillanceStation.Layout/List`` v2, ``appType=0``.  A current layout
uses ``range="columns_rows"`` and ``customPosList`` contains merged rectangles
as ``[x, y, width, height]``.  Channel ``location`` is a row-major cell index.
Older layouts instead index an ordered template in ``customPosList``.

Modern camera channels identify the *host* camera with ``itemId``.  Their
``id`` can be a recording-server-local id in CMS, so it must not take priority.
The conversion below preserves empty/non-camera tiles rather than shifting
the remaining cameras into the wrong places.

Reading never changes the NAS. ``create_layout`` is a separate, explicit
operation: it only creates (id=-1), never overwrites, deletes or changes the
default layout, and its save request is never automatically retried.
"""

from __future__ import annotations

import json
import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from surveillance.api.client import SurveillanceAPI

MAX_LAYOUT_CELLS = 100
MAX_LAYOUT_SIDE = 100
_CAMERA = 0
_SEQUENCE = 0
_ALERT = -3
_GROUP = -2


class LayoutFormatError(ValueError):
    """A NAS layout response cannot be interpreted safely."""


class LayoutCreateUncertainError(RuntimeError):
    """A save was sent but its outcome is unknown; refresh before retrying."""


@dataclass(frozen=True, slots=True)
class LayoutTile:
    location: int
    camera_id: int | None
    row: int
    column: int
    row_span: int = 1
    column_span: int = 1
    item_type: int = _CAMERA
    camera_ids: tuple[int, ...] = ()
    label: str = ""
    owner_ds_id: int = 0
    interval: int = 10


@dataclass(frozen=True, slots=True)
class ServerLayout:
    id: int
    name: str
    columns: int
    rows: int
    tiles: tuple[LayoutTile, ...]
    is_default: bool = False
    kind: str = "general"
    warnings: tuple[str, ...] = ()
    child_layout_ids: tuple[int, ...] = ()
    interval: int = 10

    @property
    def camera_count(self) -> int:
        return sum(tile.camera_id is not None for tile in self.tiles)


def _integer(value: Any, default: int | None = None) -> int | None:
    if isinstance(value, bool):
        return default
    if isinstance(value, float) and not value.is_integer():
        return default
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _positive_id(value: Any) -> int | None:
    number = _integer(value)
    return number if number is not None and number > 0 else None


def _boolean(value: Any) -> bool:
    return value is True or value == 1 or str(value).lower() in {"true", "1"}


def _json_list(value: Any, field: str) -> list:
    if value is None or value == "":
        return []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (ValueError, TypeError) as exc:
            raise LayoutFormatError(f"Invalid {field} data") from exc
    if not isinstance(value, (list, tuple)):
        raise LayoutFormatError(f"Invalid {field} data")
    return list(value)


# Ordered geometry, matching the old official web client's GetCustomPosList.
# These are factual grid coordinates, not copied implementation code.
_LEGACY_CUSTOM: dict[int, tuple[tuple[int, int, int, int], ...]] = {
    6: ((0, 0, 2, 2), (2, 0, 1, 1), (2, 1, 1, 1),
        (0, 2, 1, 1), (1, 2, 1, 1), (2, 2, 1, 1)),
    10: ((0, 0, 2, 2), (2, 0, 2, 2), (0, 2, 1, 1), (1, 2, 1, 1),
         (2, 2, 1, 1), (3, 2, 1, 1), (0, 3, 1, 1), (1, 3, 1, 1),
         (2, 3, 1, 1), (3, 3, 1, 1)),
    13: ((0, 0, 1, 1), (1, 0, 1, 1), (2, 0, 1, 1), (3, 0, 1, 1),
         (0, 1, 1, 1), (0, 2, 1, 1), (1, 1, 2, 2), (3, 1, 1, 1),
         (3, 2, 1, 1), (0, 3, 1, 1), (1, 3, 1, 1), (2, 3, 1, 1),
         (3, 3, 1, 1)),
    14: ((0, 0, 2, 2), (2, 0, 1, 1), (3, 0, 1, 1), (2, 1, 1, 1),
         (3, 1, 1, 1), (0, 2, 1, 1), (1, 2, 1, 1), (2, 2, 1, 1),
         (3, 2, 1, 1), (0, 3, 1, 1), (1, 3, 1, 1), (2, 3, 1, 1),
         (3, 3, 1, 1)),
}
_ITEM_NAMES = {
    1: "Map", 2: "Door", 3: "Camera group", 4: "I/O widget", 5: "Transaction",
    6: "Layout", 7: "Analytics", 8: "Speaker", 9: "Speaker group",
    10: "Face recognition", 11: "Web map", 12: "Layout folder",
}


def _size(columns: int, rows: int) -> tuple[int, int]:
    if (columns < 1 or rows < 1 or columns > MAX_LAYOUT_SIDE or rows > MAX_LAYOUT_SIDE
            or columns * rows > MAX_LAYOUT_CELLS):
        raise LayoutFormatError("Layout exceeds the supported 100-cell grid")
    return columns, rows


def _rectangle(raw: Any, columns: int, rows: int) -> tuple[int, int, int, int] | None:
    if not isinstance(raw, (list, tuple)) or len(raw) != 4:
        raise LayoutFormatError("Invalid merged-tile coordinates")
    values = [_integer(v) for v in raw]
    if any(v is None for v in values):
        raise LayoutFormatError("Invalid merged-tile coordinates")
    x, y, width, height = values
    # Legacy tables have zero-sized entries for cells hidden by a merge.
    if width == 0 or height == 0:
        return None
    if x < 0 or y < 0 or width < 1 or height < 1 or x + width > columns or y + height > rows:
        raise LayoutFormatError("A merged tile extends outside the layout")
    return x, y, width, height


def _geometry(record: dict, channels: list[dict]) -> tuple[int, int, dict, dict]:
    """Return dimensions, anchor rectangles and legacy-index -> anchor mapping."""
    range_value = str(record.get("range") or "")
    group_id = _integer(record.get("camGrpId"), -1)
    is_group = group_id is not None and group_id >= 0
    if is_group or _integer(record.get("type")) == _GROUP:
        side = max(1, math.ceil(math.sqrt(len(channels))))
        columns, rows = _size(side, side)
        return columns, rows, {i: (i % columns, i // columns, 1, 1)
                              for i in range(columns * rows)}, {i: i for i in range(len(channels))}

    custom = _json_list(record.get("customPosList"), "custom layout")
    legacy_map: dict[int, int] = {}
    if range_value:
        parts = range_value.split("_")
        if len(parts) != 2 or any(_integer(p) is None for p in parts):
            raise LayoutFormatError("Invalid layout grid dimensions")
        columns, rows = _size(int(parts[0]), int(parts[1]))
        rectangles = custom
    else:
        layout_type = _integer(record.get("type"), 1)
        if layout_type in _LEGACY_CUSTOM:
            side = 3 if layout_type == 6 else 4
        elif layout_type in {1, 4, 9, 16, 25, 36, 49, 64, 81, 100}:
            side = math.isqrt(layout_type)
        elif layout_type == 2:
            # SS9's rectangular templates normally include range. Preserve
            # their documented orientation if a server omits it.
            columns, rows = 1, 2
            side = 0
        elif layout_type == 7:
            columns, rows = 3, 2
            side = 0
        elif layout_type == 3:
            side = 2
            if not custom:
                # SS9's three-camera template merges the bottom row.
                custom = [[0, 0, 1, 1], [1, 0, 1, 1], [0, 1, 2, 1]]
        else:
            raise LayoutFormatError(f"Unsupported legacy layout type {layout_type}")
        if side:
            columns, rows = side, side
        columns, rows = _size(columns, rows)
        rectangles = custom or list(_LEGACY_CUSTOM.get(layout_type, ()))
        for index, raw in enumerate(rectangles):
            rect = _rectangle(raw, columns, rows)
            # Explicit -1 means the old slot was hidden by a merged tile.
            legacy_map[index] = rect[1] * columns + rect[0] if rect else -1

    anchors: dict[int, tuple[int, int, int, int]] = {}
    occupied: set[int] = set()
    for raw in rectangles:
        rect = _rectangle(raw, columns, rows)
        if rect is None:
            continue
        x, y, width, height = rect
        covered = {row * columns + col for row in range(y, y + height)
                   for col in range(x, x + width)}
        if occupied.intersection(covered):
            raise LayoutFormatError("Overlapping merged tiles in server layout")
        occupied.update(covered)
        anchors[y * columns + x] = rect
    for location in range(columns * rows):
        if location not in occupied:
            anchors[location] = (location % columns, location // columns, 1, 1)
    return columns, rows, anchors, legacy_map


def _camera_id(channel: dict, warnings: list[str]) -> int | None:
    if any((_integer(channel.get(key), 0) or 0) > 0 for key in ("mountId", "archId", "lapseId")):
        warnings.append("Archived and time-lapse channels are not live camera feeds.")
        return None
    # itemId is the key used by Monitor Center's dsCamera.getById().
    for key in ("itemId", "idOnHost", "camIdOnHost"):
        camera_id = _positive_id(channel.get(key))
        if camera_id is not None:
            return camera_id
    owner = _integer(channel.get("dsId"), 0)
    if owner is not None and owner > 0:
        warnings.append("A CMS channel has no host camera ID and cannot be matched safely.")
        return None
    for key in ("id", "camId", "cameraId"):
        camera_id = _positive_id(channel.get(key))
        if camera_id is not None:
            return camera_id
    return None


def parse_layout(record: dict) -> ServerLayout:
    """Convert one layout, raising a concise error for unsafe geometry."""
    layout_id = _integer(record.get("id"))
    if layout_id is None:
        raise LayoutFormatError("A layout has no numeric ID")
    name = str(record.get("name") or f"Layout {layout_id}")
    interval = max(1, min(3600, _integer(record.get("interval"), 10) or 10))
    warnings: list[str] = []
    raw_channels = _json_list(record.get("Channels", record.get("channels", [])), "channels")
    channels = [channel for channel in raw_channels if isinstance(channel, dict)]
    if len(channels) != len(raw_channels):
        warnings.append("Some malformed channel entries were ignored.")
    layout_type = _integer(record.get("type"), 1)
    if layout_type in {_SEQUENCE, _ALERT}:
        ordered = sorted(enumerate(channels), key=lambda pair:
                         _integer(pair[1].get("location"), pair[0]) or 0)
        children = tuple(child for _, channel in ordered
                         if (child := _positive_id(channel.get("id", channel.get("itemId"))))
                         is not None and child != layout_id)
        if layout_type == _ALERT:
            warnings.append("Alert-triggered layout switching is not available in this client.")
        return ServerLayout(layout_id, name, 1, 1, (), _boolean(record.get("isDefault")),
                            "sequence" if layout_type == _SEQUENCE else "alert",
                            tuple(warnings), children, interval)

    columns, rows, anchors, legacy_map = _geometry(record, channels)
    group_id = _integer(record.get("camGrpId"), -1)
    is_group = (group_id is not None and group_id >= 0) or layout_type == _GROUP
    by_location: dict[int, dict] = {}
    for index, channel in enumerate(channels):
        location = index if is_group else _integer(channel.get("location"), index)
        location = legacy_map.get(location, location)
        if location == -1:
            continue
        if location not in anchors:
            warnings.append("A channel outside the visible layout was ignored.")
            continue
        if location in by_location:
            warnings.append("A duplicate tile assignment was ignored.")
            continue
        by_location[location] = channel

    tiles: list[LayoutTile] = []
    for location, (x, y, width, height) in sorted(anchors.items()):
        channel = by_location.get(location, {})
        item_type = _integer(channel.get("itemType"), _CAMERA)
        camera_id = None
        label = str(channel.get("customName") or channel.get("name") or "")
        if channel and item_type == _CAMERA:
            camera_id = _camera_id(channel, warnings)
            if (_integer(channel.get("regionId"), 0) or 0) > 0:
                warnings.append("Fisheye-region channels show the complete camera feed.")
        elif channel:
            item_name = _ITEM_NAMES.get(item_type, "Unsupported item")
            label = f"{item_name}: {label}" if label else item_name
            warnings.append(f"{item_name} tiles are shown as placeholders.")
        tiles.append(LayoutTile(location, camera_id, y, x, height, width,
                                item_type if item_type is not None else -1,
                                (camera_id,) if camera_id is not None else (), label,
                                _integer(channel.get("dsId"), 0) or 0, interval))

    return ServerLayout(layout_id, name, columns, rows, tuple(tiles),
                        _boolean(record.get("isDefault")), "group" if is_group else "general",
                        tuple(dict.fromkeys(warnings)), (), interval)


def parse_layouts(data: dict) -> list[ServerLayout]:
    """Parse the data object returned by Layout.List.

    One malformed record with a valid ID becomes an unsupported named layout so
    the UI can explain it, rather than silently lose every other layout.
    """
    if not isinstance(data, dict):
        raise LayoutFormatError("The server returned invalid layout data")
    if "layout" not in data and isinstance(data.get("data"), dict):
        data = data["data"]
    if "layout" not in data:
        raise LayoutFormatError("The server did not return a Monitor Center layout list")
    records = _json_list(data["layout"], "layout list")
    result: list[ServerLayout] = []
    seen: set[int] = set()
    for record in records:
        if not isinstance(record, dict):
            raise LayoutFormatError("The server returned an invalid layout record")
        layout_id = _integer(record.get("id"))
        if layout_id is None:
            raise LayoutFormatError("A server layout is missing its ID")
        if layout_id in seen:
            continue
        seen.add(layout_id)
        try:
            result.append(parse_layout(record))
        except LayoutFormatError as exc:
            result.append(ServerLayout(layout_id, str(record.get("name") or f"Layout {layout_id}"),
                                       1, 1, (), _boolean(record.get("isDefault")),
                                       "unsupported", (str(exc),)))
    return result


async def list_layouts(api: SurveillanceAPI) -> list[ServerLayout]:
    """Read layouts visible to the current NAS account; never write them."""
    data = await api.request(
        api="SYNO.SurveillanceStation.Layout",
        method="List",
        version=2,
        extra_params={"appType": 0, "blIncludePlaybackPriv": "true"},
    )
    return parse_layouts(data)


async def create_layout(
    api: SurveillanceAPI,
    name: str,
    columns: int,
    rows: int,
    camera_ids: Sequence[int | None],
) -> int:
    """Create a new NAS camera layout and return its assigned ID.

    Supports the 1x1, 2x2, 3x3 and 4x4 templates. IDs are in display order;
    None/0 leaves that position empty. Duplicate IDs are permitted. The
    caller must invoke this only after the user chooses to save to Synology.

    The payload follows the official SS9 ``getDefaultSaveParams``,
    ``getLayoutSaveParams`` and ``getItemParams`` methods. API.Info verifies
    the advertised JSON wire format before any save. Camera.List supplies
    host/recording-server ownership rather than guessing CMS camera IDs.
    """
    import httpx

    from surveillance.api.client import ApiError, HttpStatusError, _json_or_raise, _raise_for_status
    from surveillance.api.models import ApiInfo

    if not isinstance(name, str) or not name.strip():
        raise ValueError("Enter a name for the new layout.")
    name = name.strip()
    if any(ord(char) < 32 for char in name):
        raise ValueError("The layout name cannot contain control characters.")
    columns, rows = _integer(columns), _integer(rows)
    if columns != rows or columns not in {1, 2, 3, 4}:
        raise ValueError("Choose a 1x1, 2x2, 3x3 or 4x4 layout.")
    if not isinstance(camera_ids, (list, tuple)) or len(camera_ids) > columns * rows:
        raise ValueError("The camera list does not fit the selected grid.")
    cameras: list[int | None] = []
    for value in camera_ids:
        camera_id = 0 if value is None else _integer(value)
        if camera_id is None or camera_id < 0:
            raise ValueError("Camera IDs must be positive integers or empty slots.")
        cameras.append(camera_id or None)

    api_name = "SYNO.SurveillanceStation.Layout"
    response = await api.client.get(
        "/webapi/query.cgi",
        params={"api": "SYNO.API.Info", "method": "Query", "version": 1, "query": api_name},
    )
    _raise_for_status(response)
    info_result = _json_or_raise(response)
    if not isinstance(info_result, dict) or not info_result.get("success"):
        error = info_result.get("error", {}) if isinstance(info_result, dict) else {}
        raise ApiError(error.get("code", 100), "Unable to verify the layout creation API.")
    info = info_result.get("data", {}).get(api_name)
    if (not isinstance(info, dict) or (_integer(info.get("maxVersion"), 0) or 0) < 2
            or str(info.get("requestFormat", "")).upper() != "JSON"):
        raise LayoutFormatError(
            "This NAS does not advertise the supported JSON layout creation API. "
            "Create the layout in Synology Monitor Center, then refresh it here."
        )
    # Keep the server-advertised CGI path/version in sync with normal discovery.
    api._api_info[api_name] = ApiInfo.from_api(info)

    owners: dict[int, int] = {}
    requested = {camera_id for camera_id in cameras if camera_id is not None}
    if requested:
        data = await api.request(
            api="SYNO.SurveillanceStation.Camera", method="List", version=9,
            extra_params={"basic": "true"},
        )
        if not isinstance(data, dict) or not isinstance(data.get("cameras"), list):
            raise LayoutFormatError("The server did not return a valid camera list.")
        for camera in data["cameras"]:
            if not isinstance(camera, dict):
                continue
            camera_id = _positive_id(camera.get("id"))
            owner_id = _integer(camera.get("ownerDsId", 0))
            if camera_id is not None and owner_id is not None and owner_id >= 0:
                owners[camera_id] = owner_id
        if not requested.issubset(owners):
            raise ValueError(
                "Some selected cameras are no longer available. Refresh the camera list "
                "before saving the layout."
            )

    # Modern Monitor Center stores host itemId; camId is its legacy fallback.
    # Its parseItem removes id, so getItemParams sends camId=0 for these items.
    channels = [
        {"camId": 0, "regionType": 0, "regionId": 0, "mountId": 0, "archId": 0,
         "itemType": 0, "itemId": camera_id, "dsId": owners[camera_id], "location": index}
        for index, camera_id in enumerate(cameras) if camera_id is not None
    ]
    params = {
        "id": -1, "name": name, "interval": 10, "camList": channels,
        "type": columns * rows, "customPosList": "[]", "range": f"{columns}_{rows}",
        "camGrpId": -1, "isDefault": 0, "isFixAspectRatio": 0,
        "appType": 0, "layoutGroupId": 0, "archId": 0,
    }
    # Synology's SDK JSON-encodes every extra parameter, including strings.
    # In particular customPosList is a JSON *string* containing a JSON array.
    encoded = {key: json.dumps(value, ensure_ascii=False, separators=(",", ":"))
               for key, value in params.items()}
    uncertain = (
        "The NAS may have created the layout, but the result could not be confirmed. "
        "Refresh Synology layouts before trying Save again to avoid a duplicate."
    )
    try:
        # raw_request deliberately bypasses request()'s session re-login/retry.
        # One explicit save must result in at most one LayoutSave request.
        saved = await api.raw_request(
            api=api_name, method="LayoutSave", version=2, extra_params=encoded, post=True,
        )
    except httpx.TransportError as exc:
        raise LayoutCreateUncertainError(uncertain) from exc
    except HttpStatusError as exc:
        if exc.status_code >= 500:
            raise LayoutCreateUncertainError(uncertain) from exc
        raise
    except ApiError as exc:
        if isinstance(exc.__cause__, ValueError):  # Successful HTTP response, invalid JSON.
            raise LayoutCreateUncertainError(uncertain) from exc
        raise
    except (ValueError, TypeError, AttributeError) as exc:
        raise LayoutCreateUncertainError(uncertain) from exc
    layout_id = _positive_id(saved.get("id")) if isinstance(saved, dict) else None
    if layout_id is None:
        raise LayoutCreateUncertainError(uncertain)
    return layout_id


class LayoutService:
    """Small object facade for callers that keep per-session services."""

    def __init__(self, api: SurveillanceAPI) -> None:
        self.api = api

    async def list_layouts(self) -> list[ServerLayout]:
        return await list_layouts(self.api)
