# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Live view stream URL management."""

from __future__ import annotations

import logging
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from surveillance.api.client import SurveillanceAPI

log = logging.getLogger(__name__)


PROTOCOL_LABELS: dict[str, str] = {
    "auto": "Auto (WebSocket)",
    "websocket": "WebSocket",
    "mjpeg": "MJPEG",
    "rtsp_over_http": "RTSP over HTTP",
    "rtsp": "RTSP",
    "multicast": "Multicast",
    "direct": "Direct RTSP URL",
}

# Protocols that stream over DSM's WebSocket, the only transport that can
# ask for a stream profile: an RTSP path from GetLiveViewPath always
# carries the camera's own Live View setting.
WEBSOCKET_PROTOCOLS = frozenset({"auto", "websocket"})


class StreamProfile(StrEnum):
    """Which of a camera's Surveillance Station stream profiles Live View
    asks for. CAMERA follows the camera's own Live View setting there."""

    CAMERA = "camera"
    HIGH = "high"
    BALANCED = "balanced"
    LOW = "low"


STREAM_PROFILE_LABELS: dict[StreamProfile, str] = {
    StreamProfile.CAMERA: "Use camera settings",
    StreamProfile.HIGH: "High quality",
    StreamProfile.BALANCED: "Balanced",
    StreamProfile.LOW: "Low bandwidth",
}

# Surveillance Station's own number for each profile, as GetInfo's
# defLiveProfile reports it. The WebSocket URL's profile parameter takes
# the same number, and DSM resolves it through each camera's own
# profile-to-stream mapping.
_STREAM_PROFILE_NUMBER: dict[StreamProfile, int] = {
    StreamProfile.HIGH: 0,
    StreamProfile.BALANCED: 1,
    StreamProfile.LOW: 2,
}

# Used when DSM does not say which profile a camera's Live View setting
# picks. Balanced is Surveillance Station's own default.
_FALLBACK_STREAM_PROFILE_NUMBER = 1

# App-wide stream profile from the Settings page (see set_app_stream_profile).
# Anything but CAMERA overrides every camera's own choice.
_APP_STREAM_PROFILE = StreamProfile.CAMERA

# By default a grid requests exactly the same stream profile as a single
# camera. Lower grid quality remains an explicit option, not a substitute
# for fixing the transport/scheduling path.
LAYOUT_STREAM_PROFILE_LABELS: dict[str, str] = {
    "configured": "Use configured quality",
    "low": "Low bandwidth",
    "balanced": "Balanced",
}
_LAYOUT_STREAM_PROFILE = "configured"


def app_stream_profile() -> StreamProfile:
    """The app-wide stream profile from the Settings page."""
    return _APP_STREAM_PROFILE


def set_app_stream_profile(value: str) -> None:
    """Set the app-wide stream profile; an unknown value (a hand-edited
    config) means CAMERA."""
    global _APP_STREAM_PROFILE
    try:
        _APP_STREAM_PROFILE = StreamProfile(value)
    except ValueError:
        _APP_STREAM_PROFILE = StreamProfile.CAMERA


def get_layout_stream_profile() -> str:
    """Quality policy for multi-camera layouts; independent of single view."""
    return _LAYOUT_STREAM_PROFILE


def set_layout_stream_profile(value: str) -> None:
    """Set grid policy; malformed settings follow ordinary camera quality."""
    global _LAYOUT_STREAM_PROFILE
    _LAYOUT_STREAM_PROFILE = value if value in LAYOUT_STREAM_PROFILE_LABELS else "configured"


def effective_stream_profile(camera_choice: str) -> StreamProfile:
    """The profile a camera's Live View stream uses: the app-wide setting
    when it forces one, otherwise *camera_choice* (the camera's own
    override, "camera" when it has none). CAMERA in the result means the
    camera's Live View setting in Surveillance Station."""
    if _APP_STREAM_PROFILE is not StreamProfile.CAMERA:
        return _APP_STREAM_PROFILE
    try:
        return StreamProfile(camera_choice)
    except ValueError:
        return StreamProfile.CAMERA


def effective_layout_profile(
    camera_choice: str, tile_count: int, focused: bool = False
) -> StreamProfile:
    """Choose quality for the visible layout, without changing NAS settings.

    A single or enlarged camera uses the ordinary app/per-camera priority.
    Multi-camera Low/Balanced explicitly overrides that priority; Configured
    restores it. A profile is a NAS mapping, so Low helps only when it maps
    to a genuinely lighter camera stream.
    """
    if focused or tile_count <= 1 or _LAYOUT_STREAM_PROFILE == "configured":
        return effective_stream_profile(camera_choice)
    return StreamProfile(_LAYOUT_STREAM_PROFILE)


# Protocols whose stream URL is an RTSP one, so audio reaches mpv as soon
# as the camera has a track. "auto" and "websocket" are not here because
# they only carry audio when ws_bridge can mux it (see its module
# docstring), which is not known until DSM reports the codec --
# liveview's _update_slot_audio handles that case separately. "mjpeg" is
# a still-image stream and never has audio.
AUDIO_PROTOCOLS = frozenset({"rtsp", "rtsp_over_http", "multicast", "direct"})

# Map protocol name -> API response field
_PROTO_FIELD: dict[str, str] = {
    "rtsp": "rtspPath",
    "rtsp_over_http": "rtspOverHttpPath",
    "mjpeg": "mjpegHttpPath",
    "multicast": "multicstPath",
}


# A locally-generated mpv URL showing a "camera offline" card. Uses
# libavdevice's lavfi input to synthesize a black frame with a static
# message, entirely without network I/O — unlike a real RTSP/WebSocket URL
# for an unreachable camera, this can never block mpv's demuxer on a dead
# connection, so it's always safe to play. The camera's own name is already
# shown in the slot header, so it isn't repeated here.
OFFLINE_PLACEHOLDER_URL = (
    "av://lavfi:color=c=black:s=1280x720:r=5,"
    "drawtext=text='Camera offline':fontcolor=white:fontsize=36:"
    "x=(w-text_w)/2:y=(h-text_h)/2"
)


def _build_ws_live_url(api: SurveillanceAPI, camera_id: int, profile: int) -> str:
    """Build a WebSocket live stream URL for stream profile *profile*
    (0 high, 1 balanced, 2 low)."""
    scheme = "wss" if api.base_url.startswith("https") else "ws"
    host_port = api.base_url.split("://", 1)[1]
    return (
        f"{scheme}://{host_port}/ss_webstream_task/"
        f"?method=MixStream&stmSrc=0&blAudio=true"
        f"&dsId=0&id={camera_id}&devType=1&profile={profile}"
    )


async def _stream_profile_number(
    api: SurveillanceAPI, camera_id: int, profile: StreamProfile
) -> int:
    """Surveillance Station's profile number for *profile*, asking DSM
    for the camera's Live View setting when *profile* is CAMERA.

    Only Camera.GetInfo with streamInfo reports that setting
    (defLiveProfile); Camera.List does not.
    """
    if profile is not StreamProfile.CAMERA:
        return _STREAM_PROFILE_NUMBER[profile]
    try:
        data = await api.request(
            api="SYNO.SurveillanceStation.Camera",
            method="GetInfo",
            version=8,
            extra_params={"cameraIds": str(camera_id), "streamInfo": "true"},
        )
        value = data["cameras"][0]["defLiveProfile"]
    except Exception as e:
        log.warning(
            "DSM did not report camera %d's Live View setting, using Balanced: %s",
            camera_id,
            e,
        )
        return _FALLBACK_STREAM_PROFILE_NUMBER
    if value not in _STREAM_PROFILE_NUMBER.values():
        return _FALLBACK_STREAM_PROFILE_NUMBER
    return int(value)


def get_history_view_path(api: SurveillanceAPI) -> str:
    """Build a WebSocket URL for History (recorded) playback.

    Unlike get_live_view_path/_build_ws_live_url, no camera or protocol
    choice applies here -- History is WS-only (see ws_bridge.py's
    module docstring: RTSP has no historical/timestamp param at all)
    and nothing here identifies a camera or recording, which is instead
    selected by an in-band message WebSocketBridge sends once connected
    (WebSocketBridge(history_recording=..., history_target=...)).

    Deliberately *not* carrying over blMux/browser/relay_rec_auth from
    DSM's own web client's connect URL, despite those being genuinely
    present there: blMux=true at the connect-URL level (unlike the
    same field already sent in-band in the action=play message, which
    has no such effect) switches DSM into sending an already-muxed
    MP4/MOV container from the start of the connection -- a
    fundamentally different wire format from the raw frames this
    bridge's reconstruction/AAC-detection pipeline parses.
    """
    scheme = "wss" if api.base_url.startswith("https") else "ws"
    host_port = api.base_url.split("://", 1)[1]
    return f"{scheme}://{host_port}/ss_webstream_task/?method=MixStream&stmSrc=2&dsId=0&id=0"


async def get_live_view_path(
    api: SurveillanceAPI,
    camera_id: int,
    protocol: str = "auto",
    override_url: str = "",
    camera_stream_profile: str = StreamProfile.CAMERA,
    layout_stream_profile: str | None = None,
) -> str:
    """Get the live view URL for a camera.

    *protocol* selects which stream path to use:
      auto, rtsp, rtsp_over_http, mjpeg, multicast, websocket, direct.
    When *protocol* is ``"direct"``, *override_url* is returned as-is.
    *camera_stream_profile* is the camera's own stream profile override,
    which only a WebSocket stream can honour (see
    effective_stream_profile for how it combines with the app-wide one).
    A valid explicit *layout_stream_profile* (high/balanced/low) takes
    priority over those settings for WebSocket. None or an unrecognised
    value preserves ordinary selection. Other protocols are unchanged.
    """
    if protocol == "direct" and override_url:
        return override_url

    # "auto" is WebSocket: it is what DSM's own web client uses and the
    # only transport that carries audio for the common camera. There is no
    # fallback to the API-based protocols -- picking one of those is a
    # per-camera override, made by right-clicking the camera in the sidebar.
    if protocol in WEBSOCKET_PROTOCOLS:
        profile = effective_stream_profile(camera_stream_profile)
        if layout_stream_profile in _STREAM_PROFILE_NUMBER:
            profile = StreamProfile(layout_stream_profile)
        number = await _stream_profile_number(api, camera_id, profile)
        return _build_ws_live_url(api, camera_id, number)

    data = await api.request(
        api="SYNO.SurveillanceStation.Camera",
        method="GetLiveViewPath",
        version=9,
        extra_params={"idList": str(camera_id)},
    )

    # Response 'data' can be a list directly or a dict with pathInfos
    paths: list[dict[str, str]] = []
    if isinstance(data, list):
        paths = data
    elif isinstance(data, dict):
        paths = data.get("pathInfos", data.get("cameras", [])) or []

    if not paths:
        raise ValueError(f"No live view path for camera {camera_id}")

    info = paths[0]

    # Specific protocol requested
    if protocol in _PROTO_FIELD:
        field_name = _PROTO_FIELD[protocol]
        value: str = info.get(field_name, "")
        if not value:
            raise ValueError(f"Protocol {protocol!r} not available for camera {camera_id}")
        if field_name == "mjpegHttpPath" and not value.startswith(("http://", "https://")):
            return f"{api.base_url}{value}"
        return value

    raise ValueError(f"Unknown protocol {protocol!r}")
