"""Named camera layouts stored in a connection profile on this endpoint."""

from __future__ import annotations

from typing import Any

from surveillance.services.layout import LayoutTile, ServerLayout


def make_local_layout_record(
    existing: list[dict[str, Any]], name: str, columns: int, rows: int,
    camera_ids: list[int | None],
) -> dict[str, Any]:
    name = name.strip()
    if not name or len(name) > 100:
        raise ValueError("Enter a layout name of 1–100 characters.")
    if any(ord(char) < 32 for char in name):
        raise ValueError("The layout name cannot contain control characters.")
    if columns not in (1, 2, 3, 4) or rows != columns:
        raise ValueError("Choose a 1×1, 2×2, 3×3, or 4×4 grid.")
    if len(camera_ids) != columns * rows:
        raise ValueError("Choose a camera or Empty for every tile.")
    if any(c is not None and (type(c) is not int or c <= 0) for c in camera_ids):
        raise ValueError("The camera list contains an invalid camera.")
    if any(str(item.get("name", "")).casefold() == name.casefold()
           for item in existing if isinstance(item, dict)):
        raise ValueError("A layout with this name already exists on this 10ZiG.")
    used = [int(item["id"]) for item in existing
            if isinstance(item, dict) and type(item.get("id")) is int and item["id"] < 0]
    return {"id": min(used + [0]) - 1, "name": name,
            "columns": columns, "rows": rows,
            "camera_ids": [c or 0 for c in camera_ids]}


def load_local_layouts(records: list[dict[str, Any]]) -> list[ServerLayout]:
    result = []
    seen = set()
    for record in records:
        try:
            identifier = record["id"]
            if type(identifier) is not int or identifier >= 0 or identifier in seen:
                continue
            columns, rows = record["columns"], record["rows"]
            if type(columns) is not int or type(rows) is not int:
                continue
            ids = [None if c == 0 else c for c in record["camera_ids"]]
            valid = make_local_layout_record([], record["name"], columns, rows, ids)
            tiles = tuple(LayoutTile(i, camera, i // columns, i % columns)
                          for i, camera in enumerate(ids))
            result.append(ServerLayout(identifier, valid["name"], columns, rows,
                                       tiles, kind="local"))
            seen.add(identifier)
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
    return result
