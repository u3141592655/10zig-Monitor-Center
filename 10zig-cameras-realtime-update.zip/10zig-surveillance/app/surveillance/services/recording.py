# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Recording management service."""

from __future__ import annotations

import asyncio
import base64
import collections
import json
import logging
import threading
import time
from collections.abc import Coroutine
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any

from surveillance.api.models import Recording
from surveillance.services.download import stream_to_file

if TYPE_CHECKING:
    from surveillance.api.client import SurveillanceAPI

log = logging.getLogger(__name__)

_thumbnail_semaphore = asyncio.Semaphore(8)

PRESET_TODAY = "today"
PRESET_YESTERDAY = "yesterday"
PRESET_LAST24H = "last24h"
PRESET_LAST7D = "last7d"
PRESET_LAST30D = "last30d"

# The user-facing name for each preset. One mapping rather than a copy
# per page: the three pages each kept their own identical dict until
# Events was found short an entry, printing a raw "last30d" instead of a
# label. Which presets a page actually offers still belongs to that page
# (the quick-filter bars deliberately carry different subsets); only the
# text is shared.
PRESET_LABELS: dict[str, str] = {
    PRESET_TODAY: "Today",
    PRESET_YESTERDAY: "Yesterday",
    PRESET_LAST24H: "Last 24 hrs",
    PRESET_LAST7D: "Last 7 days",
    PRESET_LAST30D: "Last 30 days",
}

# Recording.Download by recording id needs version 6 or later. Version 5
# returns a 400 "Execution failed" with no file. The official web client
# uses version 4 for its own downloads, but with a different, event-based
# param set (eventId/mountId/archId/recEvtType/offsetTimeMs/playTimeMs --
# confirmed by capturing its own traffic) for downloading an arbitrary
# sub-range rather than a whole recording, so version 4 does not apply to
# the id-based call this client makes. See download_recording_range.
RECORDING_DOWNLOAD_VERSION = 6


def preset_range(preset: str) -> tuple[int, int]:
    """Return (from_time, to_time) unix timestamps for a named time preset."""
    now = datetime.now()
    if preset == PRESET_TODAY:
        # Full day (00:00:00-23:59:59), not "now": every day-named preset
        # (Today, Yesterday, and the two "Last N days" below) names calendar
        # days, so it's expected to cover them in full regardless of when
        # the query runs — including the as-yet-unelapsed rest of today.
        # DSM tolerates a to_time past the current moment (it can only ever
        # have data up to now anyway), so this doesn't need special-casing.
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now.replace(hour=23, minute=59, second=59, microsecond=0)
        return int(start.timestamp()), int(end.timestamp())
    if preset == PRESET_YESTERDAY:
        yesterday = now - timedelta(days=1)
        start = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
        end = yesterday.replace(hour=23, minute=59, second=59, microsecond=0)
        return int(start.timestamp()), int(end.timestamp())
    if preset == PRESET_LAST24H:
        # The one duration-named (not day-named) preset: a literal rolling
        # 24h window ending at "now", not a calendar-day boundary.
        return int((now - timedelta(hours=24)).timestamp()), int(now.timestamp())
    if preset == PRESET_LAST7D:
        start = (now - timedelta(days=7)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = now.replace(hour=23, minute=59, second=59, microsecond=0)
        return int(start.timestamp()), int(end.timestamp())
    if preset == PRESET_LAST30D:
        start = (now - timedelta(days=30)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = now.replace(hour=23, minute=59, second=59, microsecond=0)
        return int(start.timestamp()), int(end.timestamp())
    raise ValueError(f"unknown preset: {preset}")


async def list_recordings(
    api: SurveillanceAPI,
    camera_id: int | None = None,
    camera_ids: list[int] | None = None,
    from_time: int | None = None,
    to_time: int | None = None,
    offset: int = 0,
    limit: int = 50,
) -> tuple[list[Recording], int]:
    """List recordings, optionally filtered by cameras and time range.

    Args:
        api: SurveillanceAPI instance
        camera_id: Single camera ID filter (legacy, use camera_ids for multiple)
        camera_ids: List of camera IDs to filter (comma-separated for API)
        from_time: Unix timestamp for start of time range
        to_time: Unix timestamp for end of time range
        offset: Pagination offset
        limit: Maximum number of recordings to return

    Returns (recordings, total_count).
    """
    params: dict[str, str] = {
        "offset": str(offset),
        "limit": str(limit),
    }
    if camera_ids:
        params["cameraIds"] = ",".join(str(cid) for cid in camera_ids)
    elif camera_id is not None:
        params["cameraIds"] = str(camera_id)
    if from_time is not None:
        params["fromTime"] = str(from_time)
    if to_time is not None:
        params["toTime"] = str(to_time)

    data = await api.request(
        api="SYNO.SurveillanceStation.Recording",
        method="List",
        version=5,
        extra_params=params,
    )

    raw = data.get("events", data.get("recordings", []))
    if raw:
        log.debug("Recording API first item keys: %s", list(raw[0].keys()))
    recordings = [Recording.from_api(r) for r in raw]
    total = data.get("total", len(recordings))
    return recordings, total


# How far around a click-to-seek target to search for a covering
# recording. Hardcoded for now at a size generous enough to comfortably
# cover a ~30min rolling recording segment (see ws_bridge.py's module
# docstring) -- segment rotation size isn't a DSM constant, so this may
# need to become dynamic or user-configurable if a shorter/longer
# rotation is ever seen in practice. Cheap enough to call fresh per
# click regardless.
_HISTORY_SEEK_WINDOW = 2 * 3600


async def find_recording_at(
    api: SurveillanceAPI, camera_id: int, target_unix: int
) -> Recording | None:
    """Find the recording covering *target_unix* for *camera_id*, for
    History-mode click-to-seek (see ws_bridge.py's module docstring for
    the wire protocol this feeds).

    A fresh List call per lookup rather than reusing LiveView's own
    presence-bar cache (LiveView._presence_cache): that cache lives in
    the UI layer, keyed by whatever range the timeline currently has
    fetched, while this service-layer function has no access to it and
    only ever needs a cheap, narrow window around one point -- a fresh
    call per lookup is simpler than threading that cache down here.

    Returns the containing recording if *target_unix* falls within one,
    otherwise the nearest recording in the fetched window (a click
    landing in a gap between recordings -- motion-only recording
    routinely leaves them -- should still seek to *something* nearby
    rather than refuse), or None if nothing was recorded anywhere near
    *target_unix*. See find_covering_recording_at for a strict variant
    that returns None instead of the nearest match.
    """
    recordings, _total = await list_recordings(
        api,
        camera_id=camera_id,
        from_time=target_unix - _HISTORY_SEEK_WINDOW,
        to_time=target_unix + _HISTORY_SEEK_WINDOW,
        limit=500,
    )
    if not recordings:
        return None
    for rec in recordings:
        if rec.start_time <= target_unix <= rec.stop_time:
            return rec
    return min(
        recordings,
        key=lambda r: min(abs(r.start_time - target_unix), abs(r.stop_time - target_unix)),
    )


async def find_recording_in_range(
    api: SurveillanceAPI, camera_id: int, start_unix: float, end_unix: float
) -> Recording | None:
    """The earliest recording of *camera_id* overlapping [start_unix,
    end_unix), for downloading a slice of it, or None.

    Never the nearest recording beside the range the way
    find_recording_at falls back to: that one holds none of what was
    asked for, and a download from it saved other footage under the
    selected time.
    """
    recordings, _total = await list_recordings(
        api,
        camera_id=camera_id,
        from_time=int(start_unix) - _HISTORY_SEEK_WINDOW,
        to_time=int(end_unix),
        limit=500,
    )
    overlapping = [r for r in recordings if r.start_time < end_unix and r.stop_time > start_unix]
    return min(overlapping, key=lambda r: r.start_time, default=None)


async def find_covering_recording_at(
    api: SurveillanceAPI, camera_id: int, target_unix: int
) -> Recording | None:
    """Like find_recording_at, but None instead of the nearest recording
    when *target_unix* falls in a genuine gap -- for a continuous-
    playback resolver (WebSocketBridge._refresh_history_recording_if_stale,
    wired up via LiveView._enter_history_mode's own resolve()) rather
    than click-to-seek.

    The two callers need opposite answers to the same gap: a click
    landing in one should still seek to *something* nearby rather than
    refuse (find_recording_at's own nearest-fallback), but a resolver
    checking whether playback has drifted past its loaded recording
    must be able to tell "nothing covers this yet" apart from "found a
    real one" -- otherwise it keeps swapping in whichever of the
    recordings on either side of the gap happens to be nearest as the
    target creeps forward, re-clamping the play offset to a different
    one of their edges each time. That bounces the position between two
    different boundaries instead of holding it steady until a recording
    that actually covers the target shows up.
    """
    rec = await find_recording_at(api, camera_id, target_unix)
    if rec is not None and rec.start_time <= target_unix <= rec.stop_time:
        return rec
    return None


def get_stream_url(api: SurveillanceAPI, rec: Recording) -> str:
    """Build a playback URL for a recording.

    Uses SYNO.SurveillanceStation.Stream EventStream (modern) with a
    fallback to SYNO.SurveillanceStation.Streaming EventStream (legacy).
    """
    # Modern: SYNO.SurveillanceStation.Stream method=EventStream
    stream_api = "SYNO.SurveillanceStation.Stream"
    if stream_api in api._api_info:
        return api.get_stream_url(
            api._get_api_path(stream_api).removeprefix("/webapi/"),
            {
                "api": stream_api,
                "method": "EventStream",
                "version": str(api._get_api_version(stream_api, 1)),
                "eventId": str(rec.id),
                "mountId": str(rec.mount_id),
                "recEvtType": str(rec.event_type),
                "archId": str(rec.arch_id),
            },
        )

    # Legacy: SYNO.SurveillanceStation.Streaming method=EventStream
    legacy_api = "SYNO.SurveillanceStation.Streaming"
    return api.get_stream_url(
        api._get_api_path(legacy_api).removeprefix("/webapi/"),
        {
            "api": legacy_api,
            "method": "EventStream",
            "version": str(api._get_api_version(legacy_api, 2)),
            "eventId": str(rec.id),
            "mountId": str(rec.mount_id),
            "framestart": "0",
            "timestamp": str(int(time.time())),
        },
    )


async def download_recording(
    api: SurveillanceAPI,
    recording_id: int,
    output_path: Path,
) -> Path:
    """Download a recording to disk.

    Validates the response content before writing so that empty or corrupt
    files are never created.  If a partial file was created but the write
    fails, it is removed before re-raising the exception.

    Raises:
        ValueError: API returned an error, HTML page, or empty body.
        ApiError: Synology API error with numeric code.
        OSError: File-system write failure (partial file is cleaned up).
    """
    log.debug("Downloading recording %d to %s", recording_id, output_path)
    chunks = api.stream_download(
        api="SYNO.SurveillanceStation.Recording",
        method="Download",
        version=RECORDING_DOWNLOAD_VERSION,
        extra_params={"id": str(recording_id)},
    )
    return await stream_to_file(chunks, output_path, f"Recording {recording_id}")


async def download_recording_range(
    api: SurveillanceAPI,
    rec: Recording,
    start_unix: float,
    end_unix: float,
    output_path: Path,
) -> Path:
    """Download the [start_unix, end_unix) slice of *rec* to disk.

    Uses the event-based version=4 download (see RECORDING_DOWNLOAD_VERSION's
    comment) rather than the whole-file id-based download: offsetTimeMs/
    playTimeMs let DSM cut an arbitrary sub-range out of the covering
    recording without this client having to trim the file itself.

    Raises:
        ValueError: end_unix does not come after start_unix, or the range
            lies wholly before or after *rec*.
        ApiError: Synology API error with numeric code.
        OSError: File-system write failure (partial file is cleaned up).
    """
    offset_ms = max(0, round((start_unix - rec.start_time) * 1000))
    play_ms = round((end_unix - start_unix) * 1000)
    if play_ms <= 0:
        raise ValueError("end time must be after start time")
    # A range that begins before the recording only has footage from the
    # recording's start on. Counted from start_unix instead, the slice
    # ran past end_unix by the difference.
    play_ms = round((end_unix - max(start_unix, rec.start_time)) * 1000)
    if play_ms <= 0:
        raise ValueError("selected range ends before the recording starts")
    # The mirror of the offset clamp above, at the other end. A range
    # chosen close to "now" sits inside a recording DSM is still writing,
    # whose stop_time was already out of date when it was fetched, so the
    # end can land past anything that exists yet. Without this, that asks
    # DSM for a playTimeMs longer than the file it is cutting from.
    available_ms = max(0, round((rec.stop_time - rec.start_time) * 1000)) - offset_ms
    if available_ms <= 0:
        raise ValueError("selected range starts after the end of the recording")
    play_ms = min(play_ms, available_ms)

    log.debug(
        "Downloading recording %d range (offset=%dms, play=%dms) to %s",
        rec.id,
        offset_ms,
        play_ms,
        output_path,
    )
    chunks = api.stream_download(
        api="SYNO.SurveillanceStation.Recording",
        method="Download",
        version=4,
        extra_params={
            "eventId": str(rec.id),
            "offsetTimeMs": str(offset_ms),
            "playTimeMs": str(play_ms),
            "mountId": str(rec.mount_id),
            "archId": str(rec.arch_id),
            "recEvtType": str(rec.event_type),
        },
    )
    return await stream_to_file(chunks, output_path, f"Recording {rec.id} range")


_recording_thumbnail_cache: collections.OrderedDict[int, bytes] = collections.OrderedDict()

_MAX_THUMBNAIL_CACHE = 128

# Bumped by clear_snapshot_cache(); a fetch that started before the bump
# still returns its image to the row that asked, but does not put it in
# the cache the next NAS will read.
_cache_generation = 0
# The clear runs on the GTK thread, the generation check and insert on
# the asyncio thread: without this a clear landing between the two let
# an old NAS's thumbnail back in.
_cache_lock = threading.Lock()


def _cache_put(
    cache: collections.OrderedDict[int, bytes], key: int, value: bytes, limit: int
) -> None:
    cache[key] = value
    cache.move_to_end(key)
    while len(cache) > limit:
        cache.popitem(last=False)


def clear_snapshot_cache() -> None:
    """Clear the thumbnail cache and disown fetches already in flight.

    Called on disconnect from the GTK thread while up to _thumbnail
    semaphore's worth of GetThumbnail requests are still running on the
    asyncio thread, plus however many are queued behind it. Clearing
    alone would let those finish and re-populate the cache with the old
    NAS's entries, and the key is a bare recording id with no notion of
    which server it came from, so logging into a second NAS could show
    the first one's thumbnail for a colliding id.
    """
    global _cache_generation

    with _cache_lock:
        _cache_generation += 1
        _recording_thumbnail_cache.clear()


async def _request_thumbnail(
    api: SurveillanceAPI, camera_id: int, arch_id: int, mount_id: int, target_time: int
) -> bytes:
    """Recording.GetThumbnail request/response handling, shared by every
    thumbnail source. eventInfo must be a JSON array of objects matching
    the APK format (dsId + blFallbackByLoadEvt + eventInfo only). Callers
    are responsible for holding _thumbnail_semaphore.
    """
    try:
        data = await api.request(
            api="SYNO.SurveillanceStation.Recording",
            method="GetThumbnail",
            version=5,
            extra_params={
                "dsId": "0",
                "blFallbackByLoadEvt": "true",
                "eventInfo": json.dumps(
                    [
                        {
                            "cameraId": camera_id,
                            "archId": arch_id,
                            "mountId": mount_id,
                            "rec_group": 0,
                            "targetTime": target_time,
                        }
                    ]
                ),
            },
        )
        thumbs = data if isinstance(data, list) else [data]
        for thumb in thumbs:
            b64 = thumb.get("thumbnail", "")
            if b64:
                image_data = base64.b64decode(b64)
                if image_data:
                    return image_data
    except Exception as exc:
        log.debug("Thumbnail request failed for camera %d at %d: %s", camera_id, target_time, exc)
    return b""


def fetch_recording_thumbnail(
    api: SurveillanceAPI,
    rec: Recording,
) -> Coroutine[Any, Any, bytes]:
    """Fetch a thumbnail for a recording, cached by recording id.

    Not a coroutine function itself: the cache generation is read here,
    when the fetch is asked for, rather than once the loop gets round to
    running it. A clear_snapshot_cache() landing in between would
    otherwise go unseen, and the old NAS's image would be cached.
    """
    return _fetch_recording_thumbnail(api, rec, _cache_generation)


async def _fetch_recording_thumbnail(
    api: SurveillanceAPI, rec: Recording, generation: int
) -> bytes:
    cached = _recording_thumbnail_cache.get(rec.id)
    if cached is not None:
        return cached

    async with _thumbnail_semaphore:
        cached = _recording_thumbnail_cache.get(rec.id)
        if cached is not None:
            return cached

        image_data = await _request_thumbnail(
            api, rec.camera_id, rec.arch_id, rec.mount_id, rec.start_time
        )
        if image_data:
            with _cache_lock:
                if generation == _cache_generation:
                    _cache_put(_recording_thumbnail_cache, rec.id, image_data, _MAX_THUMBNAIL_CACHE)
        return image_data


async def fetch_camera_thumbnail_at(api: SurveillanceAPI, camera_id: int, timestamp: int) -> bytes:
    """Fetch a thumbnail for *camera_id* at approximately *timestamp*.

    Used by the Live View timeline's hover preview — unlike a specific
    Recording row this is an arbitrary point on the timeline, so it isn't
    cached; the timeline debounces hover events instead to bound request
    volume. Returns b"" if the camera has no recording at that time (e.g.
    it was offline), same as fetch_recording_thumbnail's own failure case.
    """
    async with _thumbnail_semaphore:
        return await _request_thumbnail(
            api, camera_id, arch_id=0, mount_id=0, target_time=timestamp
        )
