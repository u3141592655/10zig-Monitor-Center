"""Create a local or NAS layout without blocking the GTK main loop."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Iterable

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")

from gi.repository import Gdk, Gtk, Pango  # type: ignore[import-untyped]

from surveillance.api.models import Camera

SaveLayout = Callable[[str, int, int, list[int | None], bool], None]


class LayoutEditorDialog(Gtk.Window):
    """Collect layout data; the parent owns asynchronous persistence.

    ``on_save(name, columns, rows, camera_ids, save_on_nas)`` receives one
    camera ID (or ``None`` for Empty) per tile, ordered left to right and
    then top to bottom. It must return promptly, dispatching any NAS work
    asynchronously. Call ``close()`` after success or ``show_error(text)``
    to keep the form open and allow another attempt.
    """

    _GRID_SIZES = (1, 2, 3, 4)

    def __init__(
        self,
        parent: Gtk.Window,
        cameras: Iterable[Camera],
        on_save: SaveLayout,
        nas_enabled: bool = True,
    ) -> None:
        super().__init__(title="New Layout", transient_for=parent, modal=True)
        self.set_default_size(540, 610)
        self._on_save = on_save
        self._nas_enabled = bool(nas_enabled)
        self._busy = False
        self._closed = False
        self._tile_choices: list[Gtk.DropDown] = []
        self._saved_tile_indices = [0] * 16
        self._cameras = sorted(cameras, key=lambda cam: (cam.name.casefold(), cam.id))
        name_counts = Counter(cam.name for cam in self._cameras)
        self._camera_ids: list[int | None] = [None] + [cam.id for cam in self._cameras]
        camera_names = ["Empty"] + [
            f"{cam.name} (ID {cam.id})" if name_counts[cam.name] > 1 else cam.name
            for cam in self._cameras
        ]
        self._camera_model = Gtk.StringList.new(camera_names)
        self.connect("close-request", self._on_close_request)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for edge in ("top", "bottom", "start", "end"):
            getattr(outer, f"set_margin_{edge}")(16)
        self.set_child(outer)

        self._form = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self._form.set_vexpand(True)
        outer.append(self._form)

        self.name_entry = Gtk.Entry()
        self.name_entry.set_placeholder_text("For example, Warehouse overview")
        self.name_entry.set_activates_default(True)
        self._form.append(self._field("Layout name", self.name_entry))

        options = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.grid_dropdown = Gtk.DropDown.new_from_strings(
            ["1 × 1 — 1 tile", "2 × 2 — 4 tiles", "3 × 3 — 9 tiles", "4 × 4 — 16 tiles"]
        )
        self.grid_dropdown.set_selected(1)
        options.append(self._field("Grid", self.grid_dropdown))
        destinations = ["This 10ZiG"]
        if self._nas_enabled:
            destinations.append("Synology NAS (this account)")
        self.destination_dropdown = Gtk.DropDown.new_from_strings(destinations)
        self.destination_dropdown.set_selected(0)
        destination_field = self._field("Save to", self.destination_dropdown)
        destination_field.set_hexpand(True)
        options.append(destination_field)
        self._form.append(options)

        self._destination_note = Gtk.Label()
        self._destination_note.set_xalign(0)
        self._destination_note.set_wrap(True)
        self._destination_note.set_max_width_chars(64)
        self._destination_note.add_css_class("dim-label")
        self._form.append(self._destination_note)
        self.destination_dropdown.connect("notify::selected", self._on_destination_changed)
        self._on_destination_changed()

        self._form.append(Gtk.Separator())
        heading = Gtk.Label(label="Choose cameras")
        heading.set_xalign(0)
        heading.add_css_class("title-4")
        self._form.append(heading)
        ordering = Gtk.Label(label="Tiles run left to right, then top to bottom. Leave unused tiles empty.")
        ordering.set_xalign(0)
        ordering.set_wrap(True)
        ordering.set_max_width_chars(64)
        ordering.add_css_class("dim-label")
        self._form.append(ordering)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_min_content_height(150)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self._tile_box.set_margin_end(8)
        scroll.set_child(self._tile_box)
        self._form.append(scroll)
        self.grid_dropdown.connect("notify::selected", self._rebuild_tiles)
        self._rebuild_tiles()

        self._status = Gtk.Label()
        self._status.set_xalign(0)
        self._status.set_wrap(True)
        self._status.set_max_width_chars(64)
        self._status.set_visible(False)
        outer.append(self._status)
        outer.append(Gtk.Separator())

        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        buttons.set_halign(Gtk.Align.END)
        self._spinner = Gtk.Spinner()
        self._spinner.set_visible(False)
        buttons.append(self._spinner)
        self.cancel_button = Gtk.Button(label="Cancel")
        self.cancel_button.connect("clicked", lambda _: self.close())
        buttons.append(self.cancel_button)
        self.save_button = Gtk.Button(label="Save Layout")
        self.save_button.add_css_class("suggested-action")
        self.save_button.connect("clicked", self._save_clicked)
        buttons.append(self.save_button)
        outer.append(buttons)
        self.set_default_widget(self.save_button)

        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self._on_key_pressed)
        self.add_controller(key_controller)

    @staticmethod
    def _field(label: str, widget: Gtk.Widget) -> Gtk.Box:
        field = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        caption = Gtk.Label(label=label)
        caption.set_xalign(0)
        caption.set_mnemonic_widget(widget)
        field.append(caption)
        field.append(widget)
        return field

    def _on_destination_changed(self, *_: object) -> None:
        nas = self._nas_enabled and self.destination_dropdown.get_selected() == 1
        self._destination_note.set_text(
            "Saved on the NAS for this Synology account, so it can be available "
            "when the same account signs in on other clients."
            if nas else
            "Saved in this 10ZiG's persistent profile. This layout appears in "
            "this native application; it does not change the layouts on the NAS."
        )

    @staticmethod
    def _camera_factory() -> Gtk.SignalListItemFactory:
        factory = Gtk.SignalListItemFactory()

        def setup(_factory: Gtk.SignalListItemFactory, item: Gtk.ListItem) -> None:
            label = Gtk.Label()
            label.set_xalign(0)
            label.set_hexpand(True)
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_max_width_chars(42)
            item.set_child(label)

        def bind(_factory: Gtk.SignalListItemFactory, item: Gtk.ListItem) -> None:
            text = item.get_item().get_string()
            item.get_child().set_text(text)
            item.get_child().set_tooltip_text(text)

        factory.connect("setup", setup)
        factory.connect("bind", bind)
        return factory

    def _rebuild_tiles(self, *_: object) -> None:
        for index, dropdown in enumerate(self._tile_choices):
            self._saved_tile_indices[index] = dropdown.get_selected()
        while (child := self._tile_box.get_first_child()) is not None:
            self._tile_box.remove(child)
        self._tile_choices = []
        size = self._GRID_SIZES[self.grid_dropdown.get_selected()]
        for index in range(size * size):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            label = Gtk.Label(label=f"Tile {index + 1:02d}")
            label.set_xalign(0)
            label.set_width_chars(7)
            label.set_tooltip_text(f"Row {index // size + 1}, column {index % size + 1}")
            row.append(label)
            dropdown = Gtk.DropDown(model=self._camera_model)
            dropdown.set_factory(self._camera_factory())
            dropdown.set_list_factory(self._camera_factory())
            dropdown.set_enable_search(True)
            dropdown.set_hexpand(True)
            dropdown.set_selected(self._saved_tile_indices[index])
            label.set_mnemonic_widget(dropdown)
            row.append(dropdown)
            self._tile_box.append(row)
            self._tile_choices.append(dropdown)

    def _save_clicked(self, *_: object) -> None:
        if self._busy or self._closed:
            return
        name = self.name_entry.get_text().strip()
        if not name:
            self.show_error("Enter a name for the layout.")
            self.name_entry.grab_focus()
            return
        size = self._GRID_SIZES[self.grid_dropdown.get_selected()]
        camera_ids = [self._camera_ids[choice.get_selected()] for choice in self._tile_choices]
        save_on_nas = self._nas_enabled and self.destination_dropdown.get_selected() == 1
        self.set_busy(True)
        try:
            self._on_save(name, size, size, camera_ids, save_on_nas)
        except Exception:
            # A synchronous persistence failure must not strand a disabled
            # dialog. The parent can supply a more specific, safe message
            # through show_error when handling an asynchronous failure.
            self.show_error("The layout could not be saved. Please try again.")

    def set_busy(self, busy: bool) -> None:
        if self._closed:
            return
        self._busy = bool(busy)
        self._form.set_sensitive(not self._busy)
        self.save_button.set_sensitive(not self._busy)
        self.cancel_button.set_sensitive(not self._busy)
        self._spinner.set_visible(self._busy)
        self._status.remove_css_class("error")
        self._status.set_text("Saving layout…" if self._busy else "")
        self._status.set_visible(self._busy)
        if self._busy:
            self._spinner.start()
        else:
            self._spinner.stop()

    def show_error(self, message: str) -> None:
        if self._closed:
            return
        self.set_busy(False)
        self._status.set_text(message)
        self._status.add_css_class("error")
        self._status.set_visible(True)

    def _on_close_request(self, *_: object) -> bool:
        if self._busy:
            return True
        self._closed = True
        return False

    def _on_key_pressed(self, _controller: object, keyval: int, *_: object) -> bool:
        if keyval == Gdk.KEY_Escape:
            if not self._busy:
                self.close()
            return True
        return False

    def close(self) -> None:
        """Close after successful save, or before any save is in flight."""
        self._busy = False
        self._closed = True
        self._spinner.stop()
        super().close()
