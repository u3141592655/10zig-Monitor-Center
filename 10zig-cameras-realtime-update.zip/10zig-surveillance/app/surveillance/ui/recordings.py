# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Recording browser with filters and playback."""

from __future__ import annotations

import concurrent.futures
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # type: ignore[import-untyped]

from surveillance.api.models import Camera, Recording, decode_detection_labels
from surveillance.config import load_search_filters, save_search_filters
from surveillance.services.recording import (
    PRESET_LABELS,
    PRESET_LAST7D,
    PRESET_LAST24H,
    PRESET_TODAY,
    PRESET_YESTERDAY,
    download_recording,
    fetch_recording_thumbnail,
    list_recordings,
    preset_range,
)
from surveillance.ui.advanced_search import AdvancedSearchDialog
from surveillance.ui.labels import truncate_label
from surveillance.util.async_bridge import run_async

_THUMB_WIDTH = 120
_THUMB_HEIGHT = 68

if TYPE_CHECKING:
    from surveillance.ui.window import MainWindow

log = logging.getLogger(__name__)


class RecordingsView(Gtk.Box):
    """Recording browser with camera filter and recording list."""

    def __init__(self, window: MainWindow) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self.app = window.app
        self._total = 0
        self._offset = 0
        self._camera_id: int | None = None
        self._loading = False
        self._reload_pending = False
        self._thumb_futures: list[concurrent.futures.Future[bytes]] = []
        self._thumb_generation = 0
        self._search_camera_ids: list[int] | None = None
        self._search_from_time: int | None = None
        self._search_to_time: int | None = None
        self._search_time_preset: str = ""

        self._load_search_from_config()

        # Toolbar row: quick date presets on the left, camera filter and
        # actions on the right, all in a single row.
        filter_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        filter_row.set_margin_top(8)
        filter_row.set_margin_bottom(4)
        filter_row.set_margin_start(8)
        filter_row.set_margin_end(8)

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.set_hexpand(True)
        toolbar.set_halign(Gtk.Align.END)
        toolbar.set_valign(Gtk.Align.CENTER)

        filter_label = Gtk.Label(label="Camera:")
        toolbar.append(filter_label)

        self.camera_combo = Gtk.ComboBoxText()
        self.camera_combo.append("all", "All cameras")
        self.camera_combo.set_active_id("all")
        self.camera_combo.connect("changed", self._on_filter_changed)
        # Caps width via CSS (see .filter-combo in style.css) — set_size_request
        # alone only sets a floor, not a ceiling: GTK still requests width for
        # the longest camera name ever appended (e.g. "HIKVISION
        # DS-2CD2387G2-LSU/SL"), so it can keep growing as more cameras are
        # added, eventually squeezing neighboring widgets in the same row.
        self.camera_combo.add_css_class("filter-combo")
        # KNOWN COSMETIC QUIRK: see the canonical comment on camera_combo in events.py.
        toolbar.append(self.camera_combo)

        refresh_btn = Gtk.Button()
        refresh_btn.set_icon_name("view-refresh-symbolic")
        refresh_btn.set_tooltip_text("Refresh")
        refresh_btn.connect("clicked", lambda _: self._load_recordings())
        toolbar.append(refresh_btn)

        search_btn = Gtk.Button()
        search_btn.set_icon_name("system-search-symbolic")
        search_btn.set_tooltip_text("Advanced search (custom range, multiple cameras)")
        search_btn.connect("clicked", self._on_search_clicked)
        toolbar.append(search_btn)

        self._reset_btn = Gtk.Button(label="Reset")
        self._reset_btn.set_icon_name("edit-clear-symbolic")
        self._reset_btn.set_tooltip_text("Clear all filters")
        self._reset_btn.connect("clicked", self._on_reset_clicked)
        toolbar.append(self._reset_btn)

        # Quick date presets
        preset_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        preset_bar.set_valign(Gtk.Align.CENTER)

        preset_label = Gtk.Label(label="Quick filter:")
        preset_label.add_css_class("dim-label")
        preset_label.add_css_class("caption")
        preset_bar.append(preset_label)

        self._preset_buttons: dict[str, Gtk.ToggleButton] = {}
        for key in (PRESET_TODAY, PRESET_YESTERDAY, PRESET_LAST24H, PRESET_LAST7D):
            btn = Gtk.ToggleButton(label=PRESET_LABELS[key])
            btn.add_css_class("flat")
            btn.add_css_class("caption")
            btn.connect("toggled", self._on_preset_toggled, key)
            preset_bar.append(btn)
            self._preset_buttons[key] = btn

        filter_row.append(preset_bar)
        filter_row.append(toolbar)
        self.append(filter_row)

        # Filter summary
        self.filter_summary = Gtk.Label(label="")
        self.filter_summary.set_margin_start(8)
        self.filter_summary.set_margin_bottom(4)
        self.filter_summary.add_css_class("dim-label")
        self.filter_summary.add_css_class("caption")
        self.filter_summary.set_xalign(0)
        self.filter_summary.set_visible(True)
        self.append(self.filter_summary)

        self.append(Gtk.Separator())

        # Recording list
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self.row_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        log.debug("RECORDINGS INIT: plain Gtk.Box")
        scroll.set_child(self.row_box)
        self.append(scroll)

        # Download status bar
        self._status_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._status_bar.set_margin_start(8)
        self._status_bar.set_margin_end(8)
        self._status_bar.set_margin_top(4)
        self._status_bar.set_margin_bottom(4)
        self._status_bar.set_visible(False)

        self._status_label = Gtk.Label(label="")
        self._status_label.set_hexpand(True)
        self._status_label.set_xalign(0)
        self._status_bar.append(self._status_label)

        self._open_folder_btn = Gtk.Button(label="Open Folder")
        self._open_folder_btn.set_visible(False)
        self._open_folder_btn.connect("clicked", self._on_open_folder)
        self._status_bar.append(self._open_folder_btn)

        self.append(self._status_bar)
        self._last_download_dir: str = ""

        # Pagination
        page_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        page_box.set_halign(Gtk.Align.CENTER)
        page_box.set_margin_top(4)
        page_box.set_margin_bottom(4)

        self.prev_btn = Gtk.Button(label="Previous")
        self.prev_btn.connect("clicked", self._on_prev)
        self.prev_btn.set_sensitive(False)
        page_box.append(self.prev_btn)

        self.page_label = Gtk.Label(label="")
        page_box.append(self.page_label)

        self.next_btn = Gtk.Button(label="Next")
        self.next_btn.connect("clicked", self._on_next)
        self.next_btn.set_sensitive(False)
        page_box.append(self.next_btn)

        self.append(page_box)

        # Restore preset button state, populate cameras, load
        self._sync_preset_buttons()
        self.refresh_camera_filter()
        self._load_recordings()

    def on_page_shown(self) -> None:
        """Refresh whenever this page becomes visible (called from
        MainWindow.show_page) — matches Snapshots' behavior, since
        recordings can appear from elsewhere between visits."""
        self._load_recordings()

    def refresh_camera_filter(self) -> None:
        """Populate camera filter from sidebar camera list.

        Only appends cameras not already in the combo, so calling it again
        after the async camera list loads (or after a re-login, when the
        combo already holds rows) does not duplicate every entry.
        """
        if not hasattr(self, "_known_camera_ids"):
            self._known_camera_ids: set[int] = set()
        added = False
        for cam in self.window.sidebar.cameras:
            if cam.id not in self._known_camera_ids:
                self.camera_combo.append(str(cam.id), truncate_label(cam.name))
                self._known_camera_ids.add(cam.id)
                added = True
        if added:
            # The construction-time load runs before the sidebar's camera
            # fetch returns, so a filter restored from the config was
            # summarised with no names to look the ids up in. No reload:
            # only the label was wrong, the query already asked for the
            # right cameras.
            self._update_filter_summary()

    def _ensure_camera_in_combo(self, camera_id: int, name: str) -> None:
        """Add a camera to the combo if not already present."""
        if not hasattr(self, "_known_camera_ids"):
            self._known_camera_ids = set()
        if camera_id not in self._known_camera_ids:
            self.camera_combo.append(str(camera_id), truncate_label(name))
            self._known_camera_ids.add(camera_id)

    def _on_filter_changed(self, combo: Gtk.ComboBoxText) -> None:
        active = combo.get_active_id()
        if active == "all":
            self._camera_id = None
        else:
            try:
                self._camera_id = int(active) if active else None
            except ValueError:
                self._camera_id = None
        # A quick pick takes precedence over a prior Advanced Search
        # multi-camera selection, the same way picking a date preset
        # overwrites a prior custom range — otherwise this combo silently
        # does nothing until Reset is used. Saved too, or a restart
        # brings the old selection back.
        self._search_camera_ids = None
        self._save_search_to_config()
        self._offset = 0
        self._load_recordings()

    def _on_camera_filter_clicked(self, btn: Gtk.Button, camera_id: int) -> None:
        log.debug("FILTER CLICKED: camera_id=%s", camera_id)
        self._ensure_camera_in_combo(camera_id, btn.get_label() or "")
        self._camera_id = camera_id
        self._search_camera_ids = None
        self._save_search_to_config()
        self._offset = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id(str(camera_id))
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._load_recordings()

    def _sync_preset_buttons(self) -> None:
        """Update toggle state of preset buttons to match current preset."""
        for key, btn in self._preset_buttons.items():
            btn.handler_block_by_func(self._on_preset_toggled)
            btn.set_active(key == self._search_time_preset)
            btn.handler_unblock_by_func(self._on_preset_toggled)

    def _on_preset_toggled(self, btn: Gtk.ToggleButton, key: str) -> None:
        if not btn.get_active():
            # Deactivating — only clear if this was the active preset
            if self._search_time_preset == key:
                self._search_time_preset = ""
                self._search_from_time = None
                self._search_to_time = None
                self._offset = 0
                self._save_search_to_config()
                self._load_recordings()
            return

        # Activating this preset — deactivate all others
        self._search_time_preset = key
        from_ts, to_ts = preset_range(key)
        self._search_from_time = from_ts
        self._search_to_time = to_ts
        self._offset = 0

        for other_key, other_btn in self._preset_buttons.items():
            if other_key != key:
                other_btn.handler_block_by_func(self._on_preset_toggled)
                other_btn.set_active(False)
                other_btn.handler_unblock_by_func(self._on_preset_toggled)

        self._save_search_to_config()
        self._load_recordings()

    def _on_reset_clicked(self, btn: Gtk.Button) -> None:
        self._search_camera_ids = None
        self._search_from_time = None
        self._search_to_time = None
        self._search_time_preset = ""
        self._camera_id = None
        self._offset = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id("all")
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._sync_preset_buttons()
        self._save_search_to_config()
        self._load_recordings()

    def _on_search_clicked(self, btn: Gtk.Button) -> None:
        """Open the search dialog."""
        from_time = None
        to_time = None
        if self._search_from_time:
            from_time = datetime.fromtimestamp(self._search_from_time)
        if self._search_to_time:
            to_time = datetime.fromtimestamp(self._search_to_time)

        def _on_search(
            camera_ids: list[int] | None,
            from_dt: datetime | None,
            to_dt: datetime | None,
            _event_type_ids: list[str] | None,
            _event_types_match_all: bool,
            time_preset: str | None,
        ) -> None:
            # Recordings has no event-type filter (Events-only feature) —
            # the dialog always passes these last two arguments regardless
            # of page.
            self._search_camera_ids = camera_ids
            self._search_from_time = int(from_dt.timestamp()) if from_dt else None
            self._search_to_time = int(to_dt.timestamp()) if to_dt else None
            # A preset picked in the dialog behaves exactly like clicking it
            # on the toolbar; a custom range (no preset) clears it.
            self._search_time_preset = time_preset or ""
            self._sync_preset_buttons()
            self._offset = 0
            self._save_search_to_config()
            self._load_recordings()

        def _on_reset() -> None:
            self._on_reset_clicked(btn)

        dialog = AdvancedSearchDialog(
            self.window,
            self.window.sidebar.cameras,
            on_search=_on_search,
            on_reset=_on_reset,
            selected_ids=self._search_camera_ids,
            from_time=from_time,
            to_time=to_time,
            selected_preset=self._search_time_preset or None,
            title="Search Recordings",
        )
        dialog.present()

    def _load_recordings(self) -> None:
        log.debug(
            "_load_recordings: cam=%s offset=%d loading=%s search=%s preset=%s",
            self._camera_id,
            self._offset,
            self._loading,
            self._search_camera_ids,
            self._search_time_preset,
        )
        if not self.app.api or self._loading:
            # A filter switch during a slow query is common; remember it and
            # reload once the in-flight request lands, rather than dropping it
            # and leaving the previous camera's rows under the new filter.
            self._reload_pending = True
            return
        self._loading = True
        self._reload_pending = False
        self.prev_btn.set_sensitive(False)
        self.next_btn.set_sensitive(False)

        # Recompute time range so presets like "Today" stay current after midnight
        if self._search_time_preset:
            self._search_from_time, self._search_to_time = preset_range(self._search_time_preset)

        self._update_filter_summary()

        camera_ids = self._search_camera_ids
        if camera_ids is None and self._camera_id is not None:
            camera_ids = [self._camera_id]

        run_async(
            list_recordings(
                self.app.api,
                camera_ids=camera_ids,
                from_time=self._search_from_time,
                to_time=self._search_to_time,
                offset=self._offset,
            ),
            callback=self._on_recordings_loaded,
            error_callback=self._on_load_error,
        )

    def _update_filter_summary(self) -> None:
        """Always show active filter state above the list."""
        parts: list[str] = []
        parts += self._camera_filter_parts()
        parts += self._time_filter_parts()
        if parts:
            self.filter_summary.set_text("Active filters: " + " | ".join(parts))
        else:
            self.filter_summary.set_text("No filters active — showing all recordings")

    def _camera_filter_parts(self) -> list[str]:
        cam_map = {c.id: c.name for c in self.window.sidebar.cameras}
        if self._search_camera_ids:
            names = [cam_map.get(cid, str(cid)) for cid in self._search_camera_ids]
            return [f"Cameras: {', '.join(names)}"]
        if self._camera_id is not None:
            return [f"Camera: {cam_map.get(self._camera_id, str(self._camera_id))}"]
        return []

    def _time_filter_parts(self) -> list[str]:
        if self._search_time_preset:
            label = PRESET_LABELS.get(self._search_time_preset, self._search_time_preset)
            return [f"Time: {label}"]
        parts: list[str] = []
        if self._search_from_time:
            ts = datetime.fromtimestamp(self._search_from_time)
            parts.append(f"From: {ts:%Y-%m-%d %H:%M}")
        if self._search_to_time:
            ts = datetime.fromtimestamp(self._search_to_time)
            parts.append(f"To: {ts:%Y-%m-%d %H:%M}")
        return parts

    def _clear_rows(self) -> None:
        """Remove every row, and stop the thumbnails still on their way
        to them."""
        for f in self._thumb_futures:
            f.cancel()
        self._thumb_futures.clear()
        self._thumb_generation += 1
        while child := self.row_box.get_first_child():
            self.row_box.remove(child)

    def _on_load_error(self, error: Exception) -> None:
        self._loading = False
        log.error("Failed to load recordings: %s", error)
        if self._reload_pending:
            self._load_recordings()
            return
        # The filter summary already describes the request that failed,
        # so rows from the one before would be listed under it.
        self._clear_rows()
        self._total = 0
        self.prev_btn.set_sensitive(self._offset > 0)
        self.next_btn.set_sensitive(False)
        self.page_label.set_text("Failed to load recordings")

    def _on_recordings_loaded(self, result: tuple[list[Recording], int]) -> None:
        self._loading = False
        if self._reload_pending:
            self._load_recordings()
            return
        recordings, total = result
        self._total = total
        log.debug("Loaded %d recordings (total=%d)", len(recordings), total)

        if self._offset and self._offset >= total:
            # Deleting the last row of the last page shrinks the total under
            # our feet; only the response reveals it, so step back and
            # refetch rather than showing an empty "Page 2 of 1". To the
            # first page when nothing is left at all.
            self._offset = max(0, ((total - 1) // 50) * 50)
            self._load_recordings()
            return
        if recordings:
            r = recordings[0]
            log.debug("First rec: id=%d cam='%s' cam_id=%d", r.id, r.camera_name, r.camera_id)

        self._clear_rows()
        generation = self._thumb_generation
        deferred: list[tuple[Gtk.Picture, Recording]] = []
        for i, rec in enumerate(recordings):
            row_box, picture = self._create_recording_row(rec)
            self.row_box.append(row_box)
            if i < 10:
                self._load_thumbnail(picture, rec)
            else:
                deferred.append((picture, rec))

        if deferred:

            def _load_rest() -> bool:
                if self._thumb_generation != generation:
                    return False
                for pic, r in deferred:
                    self._load_thumbnail(pic, r)
                return False

            GLib.idle_add(_load_rest)

        self.prev_btn.set_sensitive(self._offset > 0)
        self.next_btn.set_sensitive(self._offset + 50 < total)
        page = (self._offset // 50) + 1
        total_pages = max(1, (total + 49) // 50)
        self.page_label.set_text(f"Page {page} of {total_pages} ({total} total)")

    def _load_thumbnail(self, picture: Gtk.Picture, rec: Recording) -> None:
        """Async-load a thumbnail for a recording row."""
        if not self.app.api:
            return

        def _on_thumb(data: bytes) -> None:
            if not data:
                log.debug("Thumb rec %d: empty data", rec.id)
                return
            try:
                loader = GdkPixbuf.PixbufLoader()
                loader.write(data)
                loader.close()
                pixbuf = loader.get_pixbuf()
                if pixbuf:
                    texture = Gdk.Texture.new_for_pixbuf(pixbuf)
                    picture.set_paintable(texture)
                    log.debug(
                        "Thumb rec %d: set %dx%d", rec.id, pixbuf.get_width(), pixbuf.get_height()
                    )
                else:
                    log.debug("Thumb rec %d: no pixbuf", rec.id)
            except Exception as exc:
                log.warning("Thumbnail decode failed for recording %d: %s", rec.id, exc)

        future = run_async(
            fetch_recording_thumbnail(self.app.api, rec),
            callback=_on_thumb,
            error_callback=lambda e: log.warning("Thumbnail fetch failed: %s", e),
        )
        self._thumb_futures.append(future)

    def _create_recording_row(self, rec: Recording) -> tuple[Gtk.Box, Gtk.Picture]:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.add_css_class("recording-row")
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(8)
        box.set_margin_end(8)

        picture = Gtk.Picture()
        picture.set_size_request(_THUMB_WIDTH, _THUMB_HEIGHT)
        picture.set_content_fit(Gtk.ContentFit.COVER)
        picture.add_css_class("recording-thumbnail")
        box.append(picture)

        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info_box.set_hexpand(True)
        info_box.set_valign(Gtk.Align.CENTER)

        cam_btn = Gtk.Button(label=rec.camera_name or "(no name)")
        cam_btn.add_css_class("camera-label")
        cam_btn.add_css_class("flat")
        cam_btn.set_halign(Gtk.Align.START)
        cam_btn.set_tooltip_text(f"Filter recordings by {rec.camera_name}")
        cam_btn.connect("clicked", self._on_camera_filter_clicked, rec.camera_id)
        info_box.append(cam_btn)
        log.debug("ROW cam='%s' id=%d", rec.camera_name, rec.camera_id)

        start = datetime.fromtimestamp(rec.start_time)
        if rec.stop_time:
            stop = datetime.fromtimestamp(rec.stop_time)
            time_str = f"{start:%Y-%m-%d %H:%M:%S} - {stop:%H:%M:%S}"
        else:
            time_str = f"{start:%Y-%m-%d %H:%M:%S} (ongoing)"
        time_label = Gtk.Label(label=time_str)
        time_label.set_xalign(0)
        time_label.add_css_class("dim-label")
        time_label.add_css_class("caption")
        info_box.append(time_label)

        if rec.stop_time:
            duration = rec.stop_time - rec.start_time
            mins, secs = divmod(duration, 60)
            dur_label = Gtk.Label(label=f"{mins}m {secs}s")
            dur_label.set_xalign(0)
            dur_label.add_css_class("dim-label")
            dur_label.add_css_class("caption")
            info_box.append(dur_label)

        det_labels = decode_detection_labels(rec.detection_label)
        if det_labels:
            det_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            for tag in det_labels:
                tag_label = Gtk.Label(label=tag)
                tag_label.add_css_class("caption")
                tag_label.add_css_class("accent")
                det_box.append(tag_label)
            info_box.append(det_box)

        box.append(info_box)

        play_btn = Gtk.Button()
        play_btn.set_icon_name("media-playback-start-symbolic")
        play_btn.set_tooltip_text("Play")
        play_btn.set_valign(Gtk.Align.CENTER)
        play_btn.connect("clicked", self._on_play, rec)
        box.append(play_btn)

        dl_btn = Gtk.Button()
        dl_btn.set_icon_name("document-save-symbolic")
        dl_btn.set_tooltip_text("Download")
        dl_btn.set_valign(Gtk.Align.CENTER)
        dl_btn.connect("clicked", self._on_download, rec)
        box.append(dl_btn)

        return box, picture

    def _on_play(self, btn: Gtk.Button, rec: Recording) -> None:
        log.debug("PLAY CLICKED: rec_id=%s", rec.id)
        from surveillance.ui.player import PlayerDialog

        dialog = PlayerDialog(self.window, self.app, rec)
        dialog.present()

    def _on_download(self, btn: Gtk.Button, rec: Recording) -> None:
        """Download recording to disk with button feedback and error dialog."""
        dialog = Gtk.FileDialog()
        start = datetime.fromtimestamp(rec.start_time)
        safe_name = re.sub(r'[/\\<>:"|?*]', "_", rec.camera_name)
        dialog.set_initial_name(f"{safe_name}_{start:%Y%m%d_%H%M%S}.mp4")

        def _on_save(d: Gtk.FileDialog, result: object) -> None:
            try:
                gfile = d.save_finish(result)
            except Exception:
                return
            if gfile is None:
                return
            path = gfile.get_path()
            if not path or self.app.api is None:
                return

            btn.set_sensitive(False)
            btn.set_icon_name("content-loading-symbolic")
            self._show_status("Downloading…", download_dir=None)

            def _restore() -> None:
                btn.set_sensitive(True)
                btn.set_icon_name("document-save-symbolic")

            def _on_success(p: Path) -> None:
                _restore()
                self._show_status(f"Saved to {p}", download_dir=str(p.parent))
                log.info("Recording %d downloaded to %s", rec.id, p)

            def _on_error(exc: Exception) -> None:
                _restore()
                log.error("Download failed for recording %d: %s", rec.id, exc)
                err = Gtk.AlertDialog()
                err.set_message("Download failed")
                err.set_detail(f"Could not download from '{rec.camera_name}'.\n\n{exc}")
                err.set_buttons(["OK"])
                err.show(self.window)

            run_async(
                download_recording(self.app.api, rec.id, Path(path)),
                callback=_on_success,
                error_callback=_on_error,
            )

        dialog.save(self.window, None, _on_save)

    def _show_status(self, message: str, download_dir: str | None) -> None:
        self._status_label.set_text(message)
        self._status_bar.set_visible(True)
        if download_dir:
            self._last_download_dir = download_dir
            self._open_folder_btn.set_visible(True)
        else:
            self._open_folder_btn.set_visible(False)

    def _on_open_folder(self, btn: Gtk.Button) -> None:
        if self._last_download_dir:
            from gi.repository import Gio

            # Path.as_uri() percent-escapes; a bare f-string leaves "#"
            # to truncate the path and "%" to form a broken escape.
            uri = Path(self._last_download_dir).as_uri()
            try:
                Gio.AppInfo.launch_default_for_uri(uri, None)
            except Exception as exc:
                log.warning("Could not open folder %s: %s", self._last_download_dir, exc)

    def _on_prev(self, btn: Gtk.Button) -> None:
        self._offset = max(0, self._offset - 50)
        self._load_recordings()

    def _on_next(self, btn: Gtk.Button) -> None:
        self._offset += 50
        self._load_recordings()

    def on_camera_selected(self, camera: Camera) -> None:
        """Handle camera selection from sidebar."""
        log.debug("RecordingsView.on_camera_selected: cam=%s id=%d", camera.name, camera.id)
        self._ensure_camera_in_combo(camera.id, camera.name)
        self._camera_id = camera.id
        self._search_camera_ids = None
        self._save_search_to_config()
        self._offset = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id(str(camera.id))
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._load_recordings()

    def _load_search_from_config(self) -> None:
        """Load search filters from config."""
        camera_ids, from_time, to_time, time_preset = load_search_filters(self.app.config, "search")
        if camera_ids:
            self._search_camera_ids = camera_ids
        if from_time:
            self._search_from_time = from_time
        if to_time:
            self._search_to_time = to_time
        self._search_time_preset = time_preset

    def _save_search_to_config(self) -> None:
        """Save search filters to config."""
        save_search_filters(
            self.app.config,
            "search",
            self._search_camera_ids,
            self._search_from_time,
            self._search_to_time,
            self._search_time_preset,
        )
