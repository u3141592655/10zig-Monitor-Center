# Copyright (c) 2026, Renaud Allard <renaud@allard.it>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Snapshot browser with filters and picture viewing — same layout as
Recordings, with "Play" mapped to viewing the still image instead of
starting video playback."""

from __future__ import annotations

import base64
import contextlib
import logging
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import Gdk, GdkPixbuf, Gtk  # type: ignore[import-untyped]

from surveillance.api.models import Camera, Snapshot
from surveillance.config import CACHE_DIR, load_search_filters, save_search_filters
from surveillance.services.recording import (
    PRESET_LABELS,
    PRESET_LAST7D,
    PRESET_LAST24H,
    PRESET_TODAY,
    PRESET_YESTERDAY,
    preset_range,
)
from surveillance.services.snapshot import (
    delete_snapshot,
    download_snapshot,
    fetch_snapshot_image,
    list_snapshots,
)
from surveillance.ui.advanced_search import AdvancedSearchDialog
from surveillance.ui.labels import truncate_label
from surveillance.ui.mpv_widget import MpvGLArea, attach_zoom_pan_controls
from surveillance.util.async_bridge import run_async

_THUMB_WIDTH = 120
_THUMB_HEIGHT = 68

# Server-side pagination is used only with no camera filter. Any camera
# filter, one camera or several, fetches everything in the time range (a
# large limit rather than genuinely unbounded: snapshot counts are
# normally far smaller than recordings or events) and filters and pages
# client-side, because the camIdList param was found to be ignored by at
# least one real NAS (see services.snapshot.list_snapshots). See
# _load_snapshots().
_PAGE_SIZE = 50
_FETCH_ALL_LIMIT = 5000

if TYPE_CHECKING:
    from surveillance.app import SurveillanceApp
    from surveillance.ui.window import MainWindow

log = logging.getLogger(__name__)


class SnapshotsView(Gtk.Box):
    """Snapshot browser with camera filter and snapshot list."""

    def __init__(self, window: MainWindow) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self.app = window.app
        self._snapshots: list[Snapshot] = []
        # How many the NAS has in the time range, of which a client-side
        # filtered load fetched at most _FETCH_ALL_LIMIT.
        self._fetched_total = 0
        self._total = 0
        self._page = 0
        # The cameras a client-side filtered load keeps, set whenever a
        # camera filter is active (see _load_snapshots).
        self._multi_camera_filter: set[int] | None = None
        self._camera_id: int | None = None
        self._loading = False
        self._reload_pending = False
        self._search_camera_ids: list[int] | None = None
        self._search_from_time: int | None = None
        self._search_to_time: int | None = None
        self._search_time_preset: str = ""

        self._load_search_from_config()

        # Toolbar row: quick date presets on the left, camera filter and
        # actions on the right, all in a single row.
        filter_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        filter_row.set_margin_top(8)
        filter_row.set_margin_bottom(4)
        filter_row.set_margin_start(8)
        filter_row.set_margin_end(8)

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.set_hexpand(True)
        toolbar.set_halign(Gtk.Align.END)
        toolbar.set_valign(Gtk.Align.CENTER)

        filter_label = Gtk.Label(label="Camera:")
        toolbar.append(filter_label)

        self.camera_combo = Gtk.ComboBoxText()
        self.camera_combo.append("all", "All cameras")
        self.camera_combo.set_active_id("all")
        self.camera_combo.connect("changed", self._on_filter_changed)
        # Caps width via CSS (see .filter-combo in style.css) — set_size_request
        # alone only sets a floor, not a ceiling: GTK still requests width for
        # the longest camera name ever appended, so it can keep growing as
        # more cameras are added, eventually squeezing neighboring widgets.
        self.camera_combo.add_css_class("filter-combo")
        # KNOWN COSMETIC QUIRK: see the canonical comment on camera_combo in events.py.
        toolbar.append(self.camera_combo)

        refresh_btn = Gtk.Button()
        refresh_btn.set_icon_name("view-refresh-symbolic")
        refresh_btn.set_tooltip_text("Refresh")
        refresh_btn.connect("clicked", lambda _: self._load_snapshots())
        toolbar.append(refresh_btn)

        search_btn = Gtk.Button()
        search_btn.set_icon_name("system-search-symbolic")
        search_btn.set_tooltip_text("Advanced search (custom range, multiple cameras)")
        search_btn.connect("clicked", self._on_search_clicked)
        toolbar.append(search_btn)

        self._reset_btn = Gtk.Button(label="Reset")
        self._reset_btn.set_icon_name("edit-clear-symbolic")
        self._reset_btn.set_tooltip_text("Clear all filters")
        self._reset_btn.connect("clicked", self._on_reset_clicked)
        toolbar.append(self._reset_btn)

        # Quick date presets
        preset_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        preset_bar.set_valign(Gtk.Align.CENTER)

        preset_label = Gtk.Label(label="Quick filter:")
        preset_label.add_css_class("dim-label")
        preset_label.add_css_class("caption")
        preset_bar.append(preset_label)

        self._preset_buttons: dict[str, Gtk.ToggleButton] = {}
        for key in (PRESET_TODAY, PRESET_YESTERDAY, PRESET_LAST24H, PRESET_LAST7D):
            btn = Gtk.ToggleButton(label=PRESET_LABELS[key])
            btn.add_css_class("flat")
            btn.add_css_class("caption")
            btn.connect("toggled", self._on_preset_toggled, key)
            preset_bar.append(btn)
            self._preset_buttons[key] = btn

        filter_row.append(preset_bar)
        filter_row.append(toolbar)
        self.append(filter_row)

        # Filter summary
        self.filter_summary = Gtk.Label(label="")
        self.filter_summary.set_margin_start(8)
        self.filter_summary.set_margin_bottom(4)
        self.filter_summary.add_css_class("dim-label")
        self.filter_summary.add_css_class("caption")
        self.filter_summary.set_xalign(0)
        self.append(self.filter_summary)

        self.append(Gtk.Separator())

        # Snapshot list
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self.row_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        scroll.set_child(self.row_box)
        self.append(scroll)

        # Download status bar
        self._status_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._status_bar.set_margin_start(8)
        self._status_bar.set_margin_end(8)
        self._status_bar.set_margin_top(4)
        self._status_bar.set_margin_bottom(4)
        self._status_bar.set_visible(False)

        self._status_label = Gtk.Label(label="")
        self._status_label.set_hexpand(True)
        self._status_label.set_xalign(0)
        self._status_bar.append(self._status_label)

        self._open_folder_btn = Gtk.Button(label="Open Folder")
        self._open_folder_btn.set_visible(False)
        self._open_folder_btn.connect("clicked", self._on_open_folder)
        self._status_bar.append(self._open_folder_btn)

        self.append(self._status_bar)
        self._last_download_dir: str = ""

        # Pagination
        page_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        page_box.set_halign(Gtk.Align.CENTER)
        page_box.set_margin_top(4)
        page_box.set_margin_bottom(4)

        self.prev_btn = Gtk.Button(label="Previous")
        self.prev_btn.connect("clicked", self._on_prev)
        self.prev_btn.set_sensitive(False)
        page_box.append(self.prev_btn)

        self.page_label = Gtk.Label(label="")
        page_box.append(self.page_label)

        self.next_btn = Gtk.Button(label="Next")
        self.next_btn.connect("clicked", self._on_next)
        self.next_btn.set_sensitive(False)
        page_box.append(self.next_btn)

        self.append(page_box)

        # Restore preset button state, populate cameras, load
        self._sync_preset_buttons()
        self.refresh_camera_filter()
        self._load_snapshots()

    def on_page_shown(self) -> None:
        """Refresh whenever this page becomes visible (called from
        MainWindow.show_page) — snapshots taken elsewhere, e.g. via Live
        View's right-click menu, wouldn't otherwise show up here until an
        explicit Refresh click."""
        self._load_snapshots()

    def refresh_camera_filter(self) -> None:
        """Populate camera filter from sidebar camera list.

        Only appends cameras not already in the combo, so calling it again
        after the async camera list loads (or after a re-login, when the
        combo already holds rows) does not duplicate every entry.

        Reloads whenever cameras were newly appended, because SnapShot::List
        identifies a camera by name only: every row, filtered or not, gets
        its camera id through the sidebar's name-to-id map, and the
        construction-time load can beat the sidebar's own fetch. Without a
        reload the rows keep the id they were resolved with against an
        empty map, which leaves each one with a dead camera button
        claiming the camera is no longer on this NAS.
        """
        if not hasattr(self, "_known_camera_ids"):
            self._known_camera_ids: set[int] = set()
        added = False
        for cam in self.window.sidebar.cameras:
            if cam.id not in self._known_camera_ids:
                self.camera_combo.append(str(cam.id), truncate_label(cam.name))
                self._known_camera_ids.add(cam.id)
                added = True
        if added:
            self._load_snapshots()

    def _ensure_camera_in_combo(self, camera_id: int, name: str) -> None:
        """Add a camera to the combo if not already present."""
        if not hasattr(self, "_known_camera_ids"):
            self._known_camera_ids = set()
        if camera_id not in self._known_camera_ids:
            self.camera_combo.append(str(camera_id), truncate_label(name))
            self._known_camera_ids.add(camera_id)

    def _on_filter_changed(self, combo: Gtk.ComboBoxText) -> None:
        active = combo.get_active_id()
        if active == "all":
            self._camera_id = None
        else:
            try:
                self._camera_id = int(active) if active else None
            except ValueError:
                self._camera_id = None
        # A quick pick takes precedence over a prior Advanced Search
        # multi-camera selection, the same way picking a date preset
        # overwrites a prior custom range — otherwise this combo silently
        # does nothing until Reset is used. Saved too, or a restart
        # brings the old selection back.
        self._search_camera_ids = None
        self._save_search_to_config()
        self._page = 0
        self._load_snapshots()

    def _on_camera_filter_clicked(self, btn: Gtk.Button, camera_id: int) -> None:
        self._ensure_camera_in_combo(camera_id, btn.get_label() or "")
        self._camera_id = camera_id
        self._search_camera_ids = None
        self._save_search_to_config()
        self._page = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id(str(camera_id))
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._load_snapshots()

    def _sync_preset_buttons(self) -> None:
        """Update toggle state of preset buttons to match current preset."""
        for key, btn in self._preset_buttons.items():
            btn.handler_block_by_func(self._on_preset_toggled)
            btn.set_active(key == self._search_time_preset)
            btn.handler_unblock_by_func(self._on_preset_toggled)

    def _on_preset_toggled(self, btn: Gtk.ToggleButton, key: str) -> None:
        if not btn.get_active():
            # Deactivating — only clear if this was the active preset
            if self._search_time_preset == key:
                self._search_time_preset = ""
                self._search_from_time = None
                self._search_to_time = None
                self._page = 0
                self._save_search_to_config()
                self._load_snapshots()
            return

        # Activating this preset — deactivate all others
        self._search_time_preset = key
        from_ts, to_ts = preset_range(key)
        self._search_from_time = from_ts
        self._search_to_time = to_ts
        self._page = 0

        for other_key, other_btn in self._preset_buttons.items():
            if other_key != key:
                other_btn.handler_block_by_func(self._on_preset_toggled)
                other_btn.set_active(False)
                other_btn.handler_unblock_by_func(self._on_preset_toggled)

        self._save_search_to_config()
        self._load_snapshots()

    def _on_reset_clicked(self, btn: Gtk.Button) -> None:
        self._search_camera_ids = None
        self._search_from_time = None
        self._search_to_time = None
        self._search_time_preset = ""
        self._camera_id = None
        self._page = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id("all")
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._sync_preset_buttons()
        self._save_search_to_config()
        self._load_snapshots()

    def _on_search_clicked(self, btn: Gtk.Button) -> None:
        """Open the advanced search dialog."""
        from_time = None
        to_time = None
        if self._search_from_time:
            from_time = datetime.fromtimestamp(self._search_from_time)
        if self._search_to_time:
            to_time = datetime.fromtimestamp(self._search_to_time)

        def _on_search(
            camera_ids: list[int] | None,
            from_dt: datetime | None,
            to_dt: datetime | None,
            _event_type_ids: list[str] | None,
            _event_types_match_all: bool,
            time_preset: str | None,
        ) -> None:
            # Snapshots has no event-type filter (Events-only feature) — the
            # dialog always passes these last two arguments regardless of
            # page.
            self._search_camera_ids = camera_ids
            self._search_from_time = int(from_dt.timestamp()) if from_dt else None
            self._search_to_time = int(to_dt.timestamp()) if to_dt else None
            # A preset picked in the dialog behaves exactly like clicking it
            # on the toolbar; a custom range (no preset) clears it.
            self._search_time_preset = time_preset or ""
            self._sync_preset_buttons()
            self._page = 0
            self._save_search_to_config()
            self._load_snapshots()

        def _on_reset() -> None:
            self._on_reset_clicked(btn)

        dialog = AdvancedSearchDialog(
            self.window,
            self.window.sidebar.cameras,
            on_search=_on_search,
            on_reset=_on_reset,
            selected_ids=self._search_camera_ids,
            from_time=from_time,
            to_time=to_time,
            selected_preset=self._search_time_preset or None,
            title="Search Snapshots",
        )
        dialog.present()

    def _load_snapshots(self) -> None:
        """Query the server for the current page.

        Any camera filter (quick pick or Advanced Search) is applied
        client-side: fetch everything in the time range once and
        filter/paginate locally (see _on_multi_camera_loaded). This covers
        a single camera too, not just multiple — SnapShot::List's
        camIdList param (which matches the official client) was found to
        not actually filter on at least one real NAS, silently returning
        every camera's snapshots instead. A single-camera selection still
        passes camIdList as a hint in case the server does honor it there
        (smaller response, one page fetched instead of up to
        _FETCH_ALL_LIMIT), but never relies on it for correctness. With no
        camera filter at all, the server does the (trivial) filtering and
        pagination itself.
        """
        if not self.app.api or self._loading:
            # A filter switch during a slow query is common; remember it and
            # reload once the in-flight request lands, rather than dropping it
            # and leaving the previous camera's rows under the new filter.
            self._reload_pending = True
            return
        self._loading = True
        self._reload_pending = False
        self.prev_btn.set_sensitive(False)
        self.next_btn.set_sensitive(False)

        # Recompute time range so presets like "Today" stay current after midnight
        if self._search_time_preset:
            self._search_from_time, self._search_to_time = preset_range(self._search_time_preset)

        self._update_filter_summary()

        camera_ids = self._search_camera_ids
        if camera_ids is None and self._camera_id is not None:
            camera_ids = [self._camera_id]

        if camera_ids:
            self._multi_camera_filter = set(camera_ids)
            run_async(
                list_snapshots(
                    self.app.api,
                    camera_id=camera_ids[0] if len(camera_ids) == 1 else None,
                    from_time=self._search_from_time,
                    to_time=self._search_to_time,
                    offset=0,
                    limit=_FETCH_ALL_LIMIT,
                ),
                callback=self._on_multi_camera_loaded,
                error_callback=self._on_load_error,
            )
        else:
            self._multi_camera_filter = None
            run_async(
                list_snapshots(
                    self.app.api,
                    from_time=self._search_from_time,
                    to_time=self._search_to_time,
                    offset=self._page * _PAGE_SIZE,
                    limit=_PAGE_SIZE,
                ),
                callback=self._on_snapshots_loaded,
                error_callback=self._on_load_error,
            )

    def _resolve_camera_ids(self, snapshots: list[Snapshot]) -> None:
        """Fill in each snapshot's camera_id from its name.

        SnapShot::List identifies the camera by name only, so camera_id
        arrives as 0; per-camera filtering needs the numeric id, which the
        camera list provides.
        """
        by_name = {cam.name: cam.id for cam in self.window.sidebar.cameras}
        for snap in snapshots:
            snap.camera_id = by_name.get(snap.camera_name, 0)

    def _on_multi_camera_loaded(self, result: tuple[list[Snapshot], int]) -> None:
        """Client-side filtering path for any camera selection (one camera
        or several — see _load_snapshots): cache the full
        (time-range-filtered) fetch and render the current page from it —
        see _render_multi_camera_page(), also used by _on_prev/_on_next so
        paging doesn't re-fetch."""
        self._loading = False
        if self._reload_pending:
            self._load_snapshots()
            return
        snapshots, self._fetched_total = result
        self._resolve_camera_ids(snapshots)
        self._snapshots = snapshots
        self._render_multi_camera_page()

    def _render_multi_camera_page(self) -> None:
        camera_filter = self._multi_camera_filter
        if camera_filter is None:
            return
        filtered = [s for s in self._snapshots if s.camera_id in camera_filter]
        total_pages = max(1, (len(filtered) + _PAGE_SIZE - 1) // _PAGE_SIZE)
        self._page = max(0, min(self._page, total_pages - 1))
        start = self._page * _PAGE_SIZE
        note = ""
        if len(self._snapshots) < self._fetched_total:
            note = (
                f", only {len(self._snapshots)} of the {self._fetched_total} "
                "snapshots in this time range searched"
            )
        self._render_page(filtered[start : start + _PAGE_SIZE], len(filtered), note)

    def _render_page(self, page_snapshots: list[Snapshot], total: int, note: str = "") -> None:
        """Rebuild the visible rows and pagination controls for one page —
        shared by the server-paginated (single camera or none) and
        client-paginated (multi-camera fallback) load paths."""
        self._total = total
        while child := self.row_box.get_first_child():
            self.row_box.remove(child)
        for snap in page_snapshots:
            row_box = self._create_snapshot_row(snap)
            self.row_box.append(row_box)

        total_pages = max(1, (total + _PAGE_SIZE - 1) // _PAGE_SIZE)
        if self._page >= total_pages:
            # Deleting the last row of the last page shrinks the total under
            # our feet; only the response reveals it, so step back and
            # refetch rather than showing an empty "Page 2 of 1".
            self._page = total_pages - 1
            self._load_snapshots()
            return
        self.prev_btn.set_sensitive(self._page > 0)
        self.next_btn.set_sensitive(self._page < total_pages - 1)
        self.page_label.set_text(f"Page {self._page + 1} of {total_pages} ({total} total{note})")

    def _update_filter_summary(self) -> None:
        """Always show active filter state above the list."""
        parts: list[str] = []
        parts += self._camera_filter_parts()
        parts += self._time_filter_parts()
        if parts:
            self.filter_summary.set_text("Active filters: " + " | ".join(parts))
        else:
            self.filter_summary.set_text("No filters active — showing all snapshots")

    def _camera_filter_parts(self) -> list[str]:
        cam_map = {c.id: c.name for c in self.window.sidebar.cameras}
        if self._search_camera_ids:
            names = [cam_map.get(cid, str(cid)) for cid in self._search_camera_ids]
            return [f"Cameras: {', '.join(names)}"]
        if self._camera_id is not None:
            return [f"Camera: {cam_map.get(self._camera_id, str(self._camera_id))}"]
        return []

    def _time_filter_parts(self) -> list[str]:
        if self._search_time_preset:
            label = PRESET_LABELS.get(self._search_time_preset, self._search_time_preset)
            return [f"Time: {label}"]
        parts: list[str] = []
        if self._search_from_time:
            ts = datetime.fromtimestamp(self._search_from_time)
            parts.append(f"From: {ts:%Y-%m-%d %H:%M}")
        if self._search_to_time:
            ts = datetime.fromtimestamp(self._search_to_time)
            parts.append(f"To: {ts:%Y-%m-%d %H:%M}")
        return parts

    def _on_load_error(self, error: Exception) -> None:
        self._loading = False
        log.error("Failed to load snapshots: %s", error)
        if self._reload_pending:
            self._load_snapshots()
            return
        # The filter summary already describes the request that failed,
        # so rows from the one before would be listed under it.
        self._snapshots = []
        while child := self.row_box.get_first_child():
            self.row_box.remove(child)
        self.prev_btn.set_sensitive(self._page > 0)
        self.next_btn.set_sensitive(False)
        self.page_label.set_text("Failed to load snapshots")

    def _on_snapshots_loaded(self, result: tuple[list[Snapshot], int]) -> None:
        """Server already filtered and paginated this page — just render it."""
        self._loading = False
        if self._reload_pending:
            self._load_snapshots()
            return
        snapshots, total = result
        self._resolve_camera_ids(snapshots)
        self._snapshots = snapshots
        self._render_page(snapshots, total)

    def _set_thumbnail(self, picture: Gtk.Picture, snap: Snapshot) -> None:
        """Decode the thumbnail already included inline in SnapShot::List's
        response — no per-row fetch needed, unlike Recording thumbnails."""
        if not snap.image_data:
            return
        try:
            raw = base64.b64decode(snap.image_data)
            loader = GdkPixbuf.PixbufLoader()
            loader.write(raw)
            loader.close()
            pixbuf = loader.get_pixbuf()
            if pixbuf:
                texture = Gdk.Texture.new_for_pixbuf(pixbuf)
                picture.set_paintable(texture)
        except Exception as exc:
            log.warning("Thumbnail decode failed for snapshot %d: %s", snap.id, exc)

    def _create_snapshot_row(self, snap: Snapshot) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.add_css_class("recording-row")
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(8)
        box.set_margin_end(8)

        picture = Gtk.Picture()
        picture.set_size_request(_THUMB_WIDTH, _THUMB_HEIGHT)
        picture.set_content_fit(Gtk.ContentFit.COVER)
        picture.add_css_class("recording-thumbnail")
        self._set_thumbnail(picture, snap)
        box.append(picture)

        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info_box.set_hexpand(True)
        info_box.set_valign(Gtk.Align.CENTER)

        cam_btn = Gtk.Button(label=snap.camera_name or "(no name)")
        cam_btn.add_css_class("camera-label")
        cam_btn.add_css_class("flat")
        cam_btn.set_halign(Gtk.Align.START)
        if snap.camera_id:
            cam_btn.set_tooltip_text(f"Filter snapshots by {snap.camera_name}")
            cam_btn.connect("clicked", self._on_camera_filter_clicked, snap.camera_id)
        else:
            # camera_id 0 means the name matched no current camera — it was
            # renamed or deleted since. Filtering on the sentinel would pool
            # every such camera's snapshots under whichever name was clicked.
            cam_btn.set_sensitive(False)
            cam_btn.set_tooltip_text(f"{snap.camera_name} is no longer on this NAS")
        info_box.append(cam_btn)

        time_str = datetime.fromtimestamp(snap.create_time).strftime("%Y-%m-%d %H:%M:%S")
        time_label = Gtk.Label(label=time_str)
        time_label.set_xalign(0)
        time_label.add_css_class("dim-label")
        time_label.add_css_class("caption")
        info_box.append(time_label)

        box.append(info_box)

        # "Play" on Recordings opens video playback; here it opens the still
        # image instead, since a snapshot has no video to play.
        view_btn = Gtk.Button()
        view_btn.set_icon_name("media-playback-start-symbolic")
        view_btn.set_tooltip_text("View")
        view_btn.set_valign(Gtk.Align.CENTER)
        view_btn.connect("clicked", self._on_view, snap)
        box.append(view_btn)

        dl_btn = Gtk.Button()
        dl_btn.set_icon_name("document-save-symbolic")
        dl_btn.set_tooltip_text("Download")
        dl_btn.set_valign(Gtk.Align.CENTER)
        dl_btn.connect("clicked", self._on_download, snap)
        box.append(dl_btn)

        del_btn = Gtk.Button()
        del_btn.set_icon_name("user-trash-symbolic")
        del_btn.set_tooltip_text("Delete")
        del_btn.set_valign(Gtk.Align.CENTER)
        del_btn.connect("clicked", self._on_delete, snap)
        box.append(del_btn)

        return box

    def _on_view(self, btn: Gtk.Button, snap: Snapshot) -> None:
        dialog = SnapshotViewerDialog(self.window, self.app, snap)
        dialog.present()

    def _on_download(self, btn: Gtk.Button, snap: Snapshot) -> None:
        """Download snapshot to disk with button feedback and error dialog."""
        dialog = Gtk.FileDialog()
        ts = datetime.fromtimestamp(snap.create_time)
        safe_name = re.sub(r'[/\\<>:"|?*]', "_", snap.camera_name)
        dialog.set_initial_name(f"{safe_name}_{ts:%Y%m%d_%H%M%S}.jpg")

        def _on_save(d: Gtk.FileDialog, result: object) -> None:
            try:
                gfile = d.save_finish(result)
            except Exception:
                return
            if gfile is None:
                return
            path = gfile.get_path()
            if not path or self.app.api is None:
                return

            btn.set_sensitive(False)
            btn.set_icon_name("content-loading-symbolic")
            self._show_status("Downloading…", download_dir=None)

            def _restore() -> None:
                btn.set_sensitive(True)
                btn.set_icon_name("document-save-symbolic")

            def _on_success(p: Path) -> None:
                _restore()
                self._show_status(f"Saved to {p}", download_dir=str(p.parent))
                log.info("Snapshot %d downloaded to %s", snap.id, p)

            def _on_error(exc: Exception) -> None:
                _restore()
                log.error("Download failed for snapshot %d: %s", snap.id, exc)
                err = Gtk.AlertDialog()
                err.set_message("Download failed")
                err.set_detail(f"Could not download from '{snap.camera_name}'.\n\n{exc}")
                err.set_buttons(["OK"])
                err.show(self.window)

            run_async(
                download_snapshot(self.app.api, snap.id, Path(path)),
                callback=_on_success,
                error_callback=_on_error,
            )

        dialog.save(self.window, None, _on_save)

    def _on_delete(self, btn: Gtk.Button, snap: Snapshot) -> None:
        api = self.app.api
        if not api:
            return

        dialog = Gtk.AlertDialog()
        dialog.set_message("Delete snapshot?")
        dialog.set_detail("This cannot be undone.")
        dialog.set_buttons(["Cancel", "Delete"])
        dialog.set_cancel_button(0)
        dialog.set_default_button(0)

        def _on_response(d: Gtk.AlertDialog, result: object) -> None:
            try:
                idx = d.choose_finish(result)
            except Exception:
                return
            if idx == 1:
                run_async(
                    delete_snapshot(api, snap.id),
                    callback=lambda _: self._load_snapshots(),
                    error_callback=lambda e: log.error("Delete failed: %s", e),
                )

        dialog.choose(self.window, None, _on_response)

    def _show_status(self, message: str, download_dir: str | None) -> None:
        self._status_label.set_text(message)
        self._status_bar.set_visible(True)
        if download_dir:
            self._last_download_dir = download_dir
            self._open_folder_btn.set_visible(True)
        else:
            self._open_folder_btn.set_visible(False)

    def _on_open_folder(self, btn: Gtk.Button) -> None:
        if self._last_download_dir:
            from gi.repository import Gio

            # Path.as_uri() percent-escapes; a bare f-string leaves "#"
            # to truncate the path and "%" to form a broken escape.
            uri = Path(self._last_download_dir).as_uri()
            try:
                Gio.AppInfo.launch_default_for_uri(uri, None)
            except Exception as exc:
                log.warning("Could not open folder %s: %s", self._last_download_dir, exc)

    def _on_prev(self, btn: Gtk.Button) -> None:
        self._page = max(0, self._page - 1)
        if self._multi_camera_filter is not None:
            self._render_multi_camera_page()
        else:
            self._load_snapshots()

    def _on_next(self, btn: Gtk.Button) -> None:
        self._page += 1
        if self._multi_camera_filter is not None:
            self._render_multi_camera_page()
        else:
            self._load_snapshots()

    def on_camera_selected(self, camera: Camera) -> None:
        """Handle camera selection from sidebar."""
        self._ensure_camera_in_combo(camera.id, camera.name)
        self._camera_id = camera.id
        self._search_camera_ids = None
        self._save_search_to_config()
        self._page = 0
        self.camera_combo.handler_block_by_func(self._on_filter_changed)
        self.camera_combo.set_active_id(str(camera.id))
        self.camera_combo.handler_unblock_by_func(self._on_filter_changed)
        self._load_snapshots()

    def _load_search_from_config(self) -> None:
        """Load search filters from config."""
        camera_ids, from_time, to_time, time_preset = load_search_filters(
            self.app.config, "snapshots_search"
        )
        if camera_ids:
            self._search_camera_ids = camera_ids
        if from_time:
            self._search_from_time = from_time
        if to_time:
            self._search_to_time = to_time
        self._search_time_preset = time_preset

    def _save_search_to_config(self) -> None:
        """Save search filters to config."""
        save_search_filters(
            self.app.config,
            "snapshots_search",
            self._search_camera_ids,
            self._search_from_time,
            self._search_to_time,
            self._search_time_preset,
        )


# Where a viewer writes the image mpv plays, removed on close. Quitting
# goes through os._exit, which skips that, so a viewer still open then
# leaves its file behind; kept in the app's own cache rather than the
# shared temp directory, the next run's first viewer clears those out.
# One running instance per session (see SurveillanceApp), so nothing
# there is in use by anyone else at that point.
_VIEWER_DIR = CACHE_DIR / "viewer"
_viewer_dir_ready = False


def _prepare_viewer_dir() -> None:
    """Create _VIEWER_DIR, emptied of what an earlier run left, once per
    run. Raises OSError if it cannot be created."""
    global _viewer_dir_ready
    if _viewer_dir_ready:
        return
    _VIEWER_DIR.mkdir(parents=True, exist_ok=True)
    for leftover in _VIEWER_DIR.iterdir():
        with contextlib.suppress(OSError):
            leftover.unlink()
    _viewer_dir_ready = True


class SnapshotViewerDialog(Gtk.Window):
    """Full-size picture viewer for a single snapshot.

    Reuses the mpv-based player widget (and its shared scroll-to-zoom/
    drag-to-pan controls, see attach_zoom_pan_controls in mpv_widget.py)."""

    def __init__(self, parent: Gtk.Window, app: SurveillanceApp, snap: Snapshot) -> None:
        super().__init__()
        self.app = app
        self._tmp_path: Path | None = None
        self._closed = False
        ts = datetime.fromtimestamp(snap.create_time)
        self.set_title(f"{snap.camera_name} - {ts:%Y-%m-%d %H:%M:%S}")
        self.set_default_size(800, 600)
        self.set_transient_for(parent)

        verify_ssl = app.api.profile.verify_ssl if app.api else True
        self.player = MpvGLArea(tls_verify=verify_ssl)
        self.set_child(self.player)

        attach_zoom_pan_controls(self.player)

        self.connect("close-request", self._on_close)

        if app.api is not None:
            run_async(
                fetch_snapshot_image(app.api, snap.id),
                callback=self._on_image_loaded,
                error_callback=lambda e: log.error(
                    "Failed to load snapshot %d image: %s", snap.id, e
                ),
            )

    def _on_image_loaded(self, data: bytes) -> None:
        if not data:
            return
        # mpv plays from a path, not a byte buffer: write to a temp
        # file rather than teaching MpvGLArea a separate in-memory
        # source path for this one caller. Cleaned up in _on_close.
        tmp_path: Path | None = None
        try:
            _prepare_viewer_dir()
            with tempfile.NamedTemporaryFile(suffix=".jpg", dir=_VIEWER_DIR, delete=False) as f:
                tmp_path = Path(f.name)
                f.write(data)
        except OSError as exc:
            # A failed write (disk full) still created the file; nothing
            # else knows about it, so remove it here.
            if tmp_path is not None:
                with contextlib.suppress(OSError):
                    tmp_path.unlink()
            log.warning("Failed to write snapshot image: %s", exc)
            return
        if self._closed:
            # Viewer closed while the download was still in flight:
            # _on_close already ran and found _tmp_path still None, so
            # nothing else will ever clean this file up.
            with contextlib.suppress(OSError):
                tmp_path.unlink()
            return
        self._tmp_path = tmp_path
        self.player.play(str(self._tmp_path))

    def _on_close(self, window: Gtk.Window) -> bool:
        self._closed = True
        self.player.stop()
        if self._tmp_path is not None:
            with contextlib.suppress(OSError):
                self._tmp_path.unlink()
            self._tmp_path = None
        return False
