"""One-time transition from the experimental low-quality grid default.

This build follows the user's working single-camera settings in every tile.
Only the grid override is migrated; normal quality, camera profiles, layouts,
credentials and all unrelated settings keep their existing values.
"""
from __future__ import annotations

import logging
import os
import contextlib
from pathlib import Path

from surveillance import config as config_store
from surveillance.config import AppConfig

log = logging.getLogger(__name__)
REVISION = 1


def upgrade_live_defaults(config: AppConfig) -> bool:
    """Back up preferences, follow single-camera quality once, then persist.

    Subsequent user choices are respected. On a write failure, keep the
    previous in-memory policy so startup can continue without a partial
    migration being mistaken for a successful save.
    """
    if config.live_pipeline_revision >= REVISION:
        return False
    source: Path = config_store.CONFIG_FILE
    backup = source.with_suffix(".toml.before-realtime")
    old_policy = config.setting_overrides_choice.get("layout_stream_profile")
    old_revision = config.live_pipeline_revision
    backup_created = False
    backup_complete = False
    try:
        if source.is_file() and not backup.exists():
            original = source.read_bytes()
            fd = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            backup_created = True
            with os.fdopen(fd, "wb") as stream:
                stream.write(original)
                stream.flush()
                os.fsync(stream.fileno())
            backup_complete = True
        config.setting_overrides_choice["layout_stream_profile"] = "configured"
        config.live_pipeline_revision = REVISION
        config_store.save_config_now(config)
    except OSError:
        # A failed backup must not masquerade as the original on a retry.
        # Never remove an earlier backup, or a complete backup when the
        # later atomic configuration write failed.
        if backup_created and not backup_complete:
            with contextlib.suppress(OSError):
                backup.unlink()
        if old_policy is None:
            config.setting_overrides_choice.pop("layout_stream_profile", None)
        else:
            config.setting_overrides_choice["layout_stream_profile"] = old_policy
        config.live_pipeline_revision = old_revision
        log.exception("Could not save the one-time live playback preference update")
        return False
    log.info("Live grid now follows single-camera stream quality; previous preferences backed up")
    return True
