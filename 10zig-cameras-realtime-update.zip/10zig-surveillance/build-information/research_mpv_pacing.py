#!/usr/bin/env python3
"""Offline, wall-clock-paced encoded-video comparison for the Cameras player.

Uses a preencoded H264/PCMU Matroska fixture. Each independent ffmpeg -re
producer streams it through an OS pipe into a real GTK/MpvGLArea. Unlike the
earlier untimed lavfi check, packet timestamps and producer pace are meaningful.
The old policy is exactly the default (live=False) cache controller; the new
policy explicitly identifies a live stream. This is not a 10ZiG benchmark.
"""
import argparse
import contextlib
import faulthandler
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import time

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib
from surveillance.ui.mpv_widget import MpvGLArea

parser = argparse.ArgumentParser()
parser.add_argument("--players", type=int, default=1)
parser.add_argument("--policy", choices=["old", "live"], default="old")
parser.add_argument("--seconds", type=int, default=12)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
faulthandler.dump_traceback_later(args.seconds + 8)

class Probe(MpvGLArea):
    def __init__(self):
        self.frames = 0
        self.last_pts = None
        self.pts_at_render = None
        super().__init__()

    def _on_render(self, area, context):
        result = super()._on_render(area, context)
        if self._url:
            self.frames += 1
            self.pts_at_render = self.last_pts
        return result

Gtk.init()
window = Gtk.Window(title="Cameras encoded-video timing research")
window.set_default_size(1120, 720)
grid = Gtk.Grid()
grid.set_column_homogeneous(True)
grid.set_row_homogeneous(True)
window.set_child(grid)
players = [Probe() for _ in range(args.players)]
side = math.ceil(math.sqrt(args.players))
for index, player in enumerate(players):
    grid.attach(player, index % side, index // side, 1, 1)

producers = []
started = []
samples = [[] for _ in players]
loop = GLib.MainLoop()
begin_deadline = time.monotonic() + 6
done = False

def sample():
    for index, player in enumerate(players):
        if index >= len(started) or not player._mpv:
            continue
        wall = time.monotonic() - started[index]
        with contextlib.suppress(Exception):
            samples[index].append({
                "wall": round(wall, 4),
                "pts": player.last_pts,
                "pts_at_last_render": player.pts_at_render,
                "speed": float(player._mpv.speed),
                "cache": player._mpv.demuxer_cache_duration,
                "render_callbacks": player.frames,
            })
    return not done

def finish():
    global done
    done = True
    loop.quit()
    return False

def begin():
    if not all(player._initialized for player in players):
        if time.monotonic() < begin_deadline:
            return True
        raise RuntimeError("Player initialization timed out")
    for player in players:
        def position(name, value, player=player):
            if value is not None:
                player.last_pts = float(value)
        player._mpv.observe_property("time-pos", position)
        process = subprocess.Popen([
            "/tmp/10zig-surveillance-runtime/bin/ffmpeg",
            "-hide_banner", "-loglevel", "error", "-re",
            "-i", "/tmp/mpv-paced-research/fixture.mkv",
            "-c", "copy", "-f", "matroska", "-cluster_time_limit", "100",
            "-flush_packets", "1", "pipe:1",
        ], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        producers.append(process)
        started.append(time.monotonic())
        player.set_mute(True)
        player.play(f"fd://{process.stdout.fileno()}", muxed_audio=True,
                    live=args.policy == "live")
    GLib.timeout_add(250, sample)
    GLib.timeout_add(args.seconds * 1000, finish)
    return False

window.present()
GLib.timeout_add(100, begin)
GLib.timeout_add((args.seconds + 10) * 1000, finish)
loop.run()
summary = []
for index, player in enumerate(players):
    valid = [s for s in samples[index] if s["pts"] is not None and s["wall"] >= 3]
    speeds = [s["speed"] for s in valid]
    slopes = ((valid[-1]["pts"] - valid[0]["pts"]) /
              (valid[-1]["wall"] - valid[0]["wall"])) if len(valid) > 1 else None
    ages = [s["wall"] - s["pts_at_last_render"] for s in valid
            if s["pts_at_last_render"] is not None]
    summary.append({
        "tile": index + 1,
        "policy": args.policy,
        "speed_min": min(speeds) if speeds else None,
        "speed_max": max(speeds) if speeds else None,
        "samples_below_1x": sum(s < 0.999 for s in speeds),
        "samples": len(speeds),
        "media_seconds_per_wall_second": slopes,
        "median_wall_minus_last_render_pts": statistics.median(ages) if ages else None,
        "max_wall_minus_last_render_pts": max(ages) if ages else None,
        "render_callbacks": player.frames,
    })
result = {"policy": args.policy, "player_count": args.players,
          "duration_seconds": args.seconds,
          "source": "640x360 15fps H264 + 8kHz PCMU, encoded MKV, independent ffmpeg -re pipes",
          "virtual_display": True, "physical_10zig": False,
          "pts_note": "Encoded media timestamps, not synthetic raw-H264 time_pos. Render PTS is last observed player clock at GL render, an approximation, not pixel OCR.",
          "summary": summary, "samples": samples}
args.output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "samples"}))
faulthandler.cancel_dump_traceback_later()
# Freeze the observations before teardown: stopping a software-rendered
# multi-player virtual display can itself be slow and is not playback time.
for process in producers:
    process.terminate()
    with contextlib.suppress(Exception):
        process.wait(timeout=3)
    if process.poll() is None:
        process.kill()
for player in players:
    player.stop()
for process in producers:
    process.stdout.close()
window.destroy()
