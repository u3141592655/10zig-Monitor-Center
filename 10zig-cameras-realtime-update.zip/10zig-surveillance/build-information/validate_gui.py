"""Real GTK integration check using synthetic layouts, never a NAS."""
import json
from pathlib import Path
from unittest.mock import patch

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, GLib, Gdk
from surveillance.app import SurveillanceApp
from surveillance.api.client import SurveillanceAPI
from surveillance.api.models import Camera, CameraStatus
from surveillance.config import ConnectionProfile
from surveillance.services.layout import ServerLayout, LayoutTile
from surveillance.ui.window import MainWindow
from surveillance.ui.liveview import LiveView

app = SurveillanceApp()
app.register(None)
profile = ConnectionProfile('gui-test', '127.0.0.1', port=9)
app.config.profiles['gui-test'] = profile
app.config.default_profile = 'gui-test'
app.config.activate_profile('gui-test')
app.config.theme = 'dark'
app.config.timeline_visible = True
app.api = SurveillanceAPI(profile)
app.api.sid = 'synthetic-offline-test'
app.apply_theme('dark')
app._add_icon_path()
app._load_css()

patches = [patch.object(LiveView, '_start_stream'),
           patch.object(LiveView, '_request_presence_refresh'),
           patch.object(LiveView, '_load_slot_ptz_extras')]
for p in patches:
    p.start()

window = MainWindow(application=app)
app._window = window
live = LiveView(window)
window.stack.add_named(live, 'live')
window.stack.set_visible_child_name('live')
window.headerbar.set_connected(True)
window.headerbar.set_page('live')
window.sidebar.set_logged_out(False)
cameras = [Camera(i, name, '', '', CameraStatus.ENABLED) for i,name in enumerate([
    'North entrance', 'Loading dock', 'Main aisle', 'South entrance',
    'Parking area', 'Workshop', 'Warehouse', 'Front lobby', 'East gate',
    'West gate', 'Dispatch', 'Break room', 'Office hallway', 'Store room',
    'Back stairs', 'Side entrance', 'Stock room', 'North yard', 'South yard',
    'Reception'], 1)]
window.sidebar._update_camera_list(cameras)
live._cameras = cameras
positions = [(0,0,2,2),(2,0,1,1),(2,1,1,1),(0,2,1,1),(1,2,1,1),(2,2,1,1)]
tiles = tuple(LayoutTile(i,i+1,y,x,h,w) for i,(x,y,w,h) in enumerate(positions))
layouts = [ServerLayout(i, name, 3,3,tiles) for i,name in enumerate([
    'Site overview', 'Entrances', 'Warehouse', 'Production floor',
    'Yards and parking', 'Evening shift'], 101)]
window.server_layouts = {x.id:x for x in layouts}
window.headerbar._build_grid_menu()
window.sidebar.set_server_layouts(layouts)
window.select_server_layout('101')
window.present()

def settle():
    context = GLib.MainContext.default()
    for _ in range(30):
        while context.pending():
            context.iteration(False)

settle()
assert live._active == list(range(6))
assert [slot.camera.id for slot in live._slots[:6]] == [1,2,3,4,5,6]
assert window.sidebar.layout_listbox.get_selected_row().layout_id == '101'
manager = live.grid.get_layout_manager()
assert manager.get_layout_child(live._slots[0]).get_column_span() == 2
assert manager.get_layout_child(live._slots[0]).get_row_span() == 2
window.set_camera_fullscreen(True)
settle()
assert not window.headerbar.get_visible()
assert not window.sidebar.get_visible()
assert not live.timeline.get_visible()
window.focus_camera_fullscreen(3)
settle()
assert live.fullscreen_focus == 3
assert [i for i,s in enumerate(live._slots) if s.get_visible()] == [3]
window.show_whole_layout()
assert [i for i,s in enumerate(live._slots) if s.get_visible()] == list(range(6))
assert manager.get_layout_child(live._slots[0]).get_column_span() == 2
window._presentation_key_pressed(None, Gdk.KEY_Escape, None, None)
assert window.headerbar.get_visible() and window.sidebar.get_visible()
assert live.timeline.get_visible()
# Exercise >16 cells and duplicate camera placement with actual GTK children.
big = ServerLayout(501,'25-cell grid',5,5,tuple(
    LayoutTile(i, (i%6)+1, i//5, i%5) for i in range(25)))
window.server_layouts[501] = big
window.select_server_layout(501)
settle()
assert len(live._active) == 25 and len(live._slots) == 25
assert live._slots[6].camera.id == live._slots[0].camera.id
window.select_server_layout(101)
settle()
assert len(live._active) == 6
window.new_camera_layout()
settle()
from surveillance.ui.layout_editor import LayoutEditorDialog
editor = next(widget for widget in Gtk.Window.get_toplevels()
              if isinstance(widget, LayoutEditorDialog))
editor.name_entry.set_text('Created in the real GTK test')
editor._tile_choices[0].set_selected(1)
editor.save_button.emit('clicked')
settle()
assert len(app.config.custom_layouts) == 1
assert app.config.selected_server_layout == '-1'
assert live._current_layout == 'nas:-1'
assert window.sidebar.layout_listbox.get_selected_row().layout_id == '-1'
window.select_server_layout(101)
settle()
for slot in live._slots[:6]:
    slot.set_placeholder('Offline UI test\nSynthetic camera name')
Path('/tmp/10zig-performance-gui-result.json').write_text(json.dumps({
    'real_gtk': True, 'merged_grid': True, 'sidebar_selection': True,
    'fullscreen_layout': True, 'fullscreen_camera': True,
    'escape_restore': True, 'large_grid': True, 'duplicate_camera': True,
    'new_layout_actual_dialog_and_persistence': True,
    'network_requests': 0, 'live_nas_tested': False,
}, indent=2))
print('Real GTK integration checks passed', flush=True)
# Keep a short-lived window available for a screenshot.
loop = GLib.MainLoop()
GLib.timeout_add_seconds(2, lambda: (loop.quit(), False)[1])
loop.run()
