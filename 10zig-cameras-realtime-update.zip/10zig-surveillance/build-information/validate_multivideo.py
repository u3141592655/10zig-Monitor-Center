#!/usr/bin/env python3
"""Bounded, offline GTK/libmpv integration check, not a hardware benchmark.

Run with an extracted application runtime and an existing virtual X server:
    python3 validate_multivideo.py --runtime /tmp/10zig-surveillance-runtime --display :91

The parent launches the bundled Python with the launcher's library/GTK settings,
an isolated temporary profile, software decoding, and a 25-second hard timeout.
Four real MpvGLArea widgets play synthetic lavfi sources for five seconds.
No camera, NAS, credentials, network media, or installed profile is used.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


def worker(output: Path) -> int:
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import GLib, Gtk
    from surveillance.ui.mpv_widget import MpvGLArea

    class RenderProbe(MpvGLArea):
        def __init__(self):
            self.rendered_callbacks = 0
            super().__init__()

        def _on_render(self, area, context):
            result = super()._on_render(area, context)
            if self._initialized and self._ctx is not None and self._url:
                self.rendered_callbacks += 1
            return result

    Gtk.init()
    window = Gtk.Window(title="Offline four-camera render validation")
    window.set_default_size(800, 600)
    grid = Gtk.Grid()
    grid.set_column_homogeneous(True)
    grid.set_row_homogeneous(True)
    window.set_child(grid)
    players = [RenderProbe() for _ in range(4)]
    sources = [
        "av://lavfi:testsrc2=size=320x240:rate=10",
        "av://lavfi:testsrc=size=320x240:rate=10",
        "av://lavfi:smptebars=size=320x240:rate=10",
        "av://lavfi:color=c=darkgreen:size=320x240:rate=10",
    ]
    for index, player in enumerate(players):
        grid.attach(player, index % 2, index // 2, 1, 1)

    loop = GLib.MainLoop()
    samples = [[] for _ in players]
    heartbeat_times = []
    started = time.monotonic()
    playback_start = [None]
    finished = [False]
    failure = []

    def heartbeat():
        heartbeat_times.append(time.monotonic() - started)
        for index, player in enumerate(players):
            position = player.time_pos
            if position is not None:
                samples[index].append(float(position))
        return not finished[0]

    def finish():
        finished[0] = True
        loop.quit()
        return False

    def begin():
        if not all(player._initialized for player in players):
            if time.monotonic() - started < 3:
                return True
            failure.append("Not all four libmpv OpenGL contexts initialized within three seconds")
            return finish()
        playback_start[0] = time.monotonic()
        for player, source in zip(players, sources, strict=True):
            player.play(source, low_latency=True)
        GLib.timeout_add(5000, finish)
        return False

    window.present()
    GLib.timeout_add(100, heartbeat)
    GLib.timeout_add(100, begin)
    loop.run()

    details = []
    for index, player in enumerate(players):
        points = samples[index]
        progress = max(points) - min(points) if points else 0
        hwdec = player._mpv["hwdec"] if player._mpv else None
        if isinstance(hwdec, (list, tuple)) and len(hwdec) == 1:
            hwdec = hwdec[0]
        configured = bool(player._mpv.vo_configured) if player._mpv else False
        if not player._initialized or player.get_error() is not None:
            failure.append(f"Tile {index + 1}: OpenGL/libmpv initialization failed")
        if progress < 1.0 or player.rendered_callbacks < 3 or not configured:
            failure.append(f"Tile {index + 1}: insufficient playback/render progress")
        if hwdec != "no":
            failure.append(f"Tile {index + 1}: software decoding was not selected")
        details.append({
            "tile": index + 1,
            "source": sources[index],
            "initialized": player._initialized,
            "vo_configured": configured,
            "hwdec": hwdec,
            "video_dimensions": dict(player._video_size),
            "time_samples": points,
            "time_advance_seconds": round(progress, 3),
            "render_callbacks": player.rendered_callbacks,
        })
    if len(heartbeat_times) < 10:
        failure.append("GTK heartbeat did not execute at least ten times")
    gaps = [later - earlier for earlier, later in zip(heartbeat_times, heartbeat_times[1:])]
    result = {
        "passed": not failure,
        "purpose": "Functional four-video GTK/OpenGL integration, not a hardware benchmark",
        "platform": "Existing virtual X11 display; not the user's 10ZiG hardware",
        "display": os.environ.get("DISPLAY"),
        "synthetic_media_only": True,
        "nas_tested": False,
        "network_media_requests": 0,
        "runtime": sys.executable,
        "duration_seconds": round(time.monotonic() - playback_start[0], 3)
        if playback_start[0] is not None else 0,
        "gtk_heartbeat_count": len(heartbeat_times),
        "largest_observed_heartbeat_gap_seconds": round(max(gaps, default=0), 3),
        "tiles": details,
        "failures": failure,
    }
    output.write_text(json.dumps(result, indent=2) + "\n")
    for player in players:
        player.stop()
    window.destroy()
    print(json.dumps({"passed": not failure, "result": str(output), "failures": failure}))
    return 0 if not failure else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, default=Path("/tmp/10zig-surveillance-runtime"))
    parser.add_argument("--display", default=":91")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().with_name("multivideo-result.json"))
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        return worker(args.output)
    runtime = args.runtime.resolve()
    source = Path(__file__).resolve().parent / "source" / "src"
    with tempfile.TemporaryDirectory(prefix="surveillance-render-validation-") as folder:
        temporary = Path(folder)
        env = dict(os.environ)
        env.update({
            "DISPLAY": args.display,
            "PATH": f"{runtime}/bin:{env.get('PATH', '/usr/bin:/bin')}",
            "LD_LIBRARY_PATH": str(runtime / "lib"),
            "PYTHONPATH": str(source),
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "GI_TYPELIB_PATH": str(runtime / "lib" / "girepository-1.0"),
            "GSETTINGS_SCHEMA_DIR": str(runtime / "share" / "glib-2.0" / "schemas"),
            "XDG_DATA_DIRS": f"{runtime}/share:/usr/local/share:/usr/share",
            "XDG_CONFIG_HOME": str(temporary / "config"),
            "XDG_DATA_HOME": str(temporary / "data"),
            "XDG_STATE_HOME": str(temporary / "state"),
            "XDG_CACHE_HOME": str(temporary / "cache"),
            "SURVEILLANCE_CREDENTIAL_STORE": "file",
            "SURVEILLANCE_MPV_OPTS": "hwdec=no",
            "GDK_BACKEND": "x11", "GSK_RENDERER": "gl", "GDK_DEBUG": "gl-prefer-gl",
        })
        command = [str(runtime / "bin" / "python"), str(Path(__file__).resolve()),
                   "--worker", "--output", str(args.output.resolve())]
        try:
            completed = subprocess.run(command, env=env, timeout=25,
                                       capture_output=True, text=True, check=False)
        except subprocess.TimeoutExpired:
            args.output.write_text(json.dumps({
                "passed": False, "failure": "25-second process timeout",
                "synthetic_media_only": True, "nas_tested": False,
            }, indent=2) + "\n")
            return 1
        args.output.with_suffix(".log").write_text(completed.stdout + completed.stderr)
        print(completed.stdout, end="")
        if completed.returncode:
            print(completed.stderr, file=sys.stderr, end="")
        return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
