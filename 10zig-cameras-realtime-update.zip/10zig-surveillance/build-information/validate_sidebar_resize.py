"""Real GTK/X11 splitter-drag test; synthetic camera/layout names, no NAS.

Run against the package runtime on a disposable X11 display. XTest sends
actual pointer drags to the GTK pane handles; assertions inspect allocated
widget dimensions and the TOML reloaded by a newly constructed window.
"""
from __future__ import annotations

import ctypes
import json
from pathlib import Path
import time
from unittest.mock import patch

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("GdkX11", "4.0")
from gi.repository import GdkX11, GLib, Gtk

from surveillance.app import SurveillanceApp
from surveillance.api.models import Camera, CameraStatus
from surveillance.config import AppConfig, load_config, save_config_now
from surveillance.services.layout import LayoutTile, ServerLayout
from surveillance.ui.window import MainWindow


def settle(seconds=0.15):
    until = time.monotonic() + seconds
    context = GLib.MainContext.default()
    while time.monotonic() < until:
        while context.pending():
            context.iteration(False)
        time.sleep(0.005)


def separator(paned):
    child = paned.get_first_child()
    while child is not None:
        if child.get_css_name() == "separator":
            return child
        child = child.get_next_sibling()
    raise AssertionError("GTK pane handle not found")


x11 = ctypes.CDLL("libX11.so.6")
xtst = ctypes.CDLL("libXtst.so.6")
x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
x11.XOpenDisplay.restype = ctypes.c_void_p
x11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
x11.XDefaultRootWindow.restype = ctypes.c_ulong
x11.XTranslateCoordinates.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
    ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
    ctypes.POINTER(ctypes.c_ulong)]
x11.XFlush.argtypes = [ctypes.c_void_p]
xtst.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_ulong]
xtst.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint,
                                    ctypes.c_int, ctypes.c_ulong]
display = x11.XOpenDisplay(None)
assert display


def drag(window, handle, dx=0, dy=0):
    okay, bounds = handle.compute_bounds(window)
    assert okay
    xid = GdkX11.X11Surface.get_xid(window.get_surface())
    root = x11.XDefaultRootWindow(display)
    rx, ry, child = ctypes.c_int(), ctypes.c_int(), ctypes.c_ulong()
    x11.XTranslateCoordinates(display, xid, root, 0, 0, ctypes.byref(rx),
                              ctypes.byref(ry), ctypes.byref(child))
    x = rx.value + int(bounds.get_x() + bounds.get_width() / 2)
    y = ry.value + int(bounds.get_y() + bounds.get_height() / 2)
    xtst.XTestFakeMotionEvent(display, -1, x, y, 0)
    x11.XFlush(display)
    settle(0.03)
    xtst.XTestFakeButtonEvent(display, 1, 1, 0)
    x11.XFlush(display)
    settle(0.03)
    for step in range(1, 21):
        xtst.XTestFakeMotionEvent(display, -1, x + dx * step // 20, y + dy * step // 20, 0)
        x11.XFlush(display)
        settle(0.015)
    xtst.XTestFakeButtonEvent(display, 1, 0, 0)
    x11.XFlush(display)
    settle()


app = SurveillanceApp()
app.register(None)
app.config = AppConfig()
app.apply_theme("dark")
app._load_css()
app._add_icon_path()


def new_window(width=1200, height=900):
    with patch.object(MainWindow, "_schedule_login", lambda self: None):
        window = MainWindow(application=app)
    window.set_default_size(width, height)
    window.sidebar.set_logged_out(False)
    cameras = [Camera(i, f"Camera {i:02d} long name for resizing demonstration", "", "",
                      CameraStatus.ENABLED) for i in range(1, 31)]
    window.sidebar._update_camera_list(cameras)
    layouts = [ServerLayout(i, f"Saved layout {i:02d} with a descriptive name", 2, 2,
                   tuple(LayoutTile(j, j + 1, j // 2, j % 2) for j in range(4)))
               for i in range(1, 31)]
    window.sidebar.set_server_layouts(layouts)
    window.present()
    settle(0.3)
    return window


window = new_window()
sidebar = window.sidebar
before = {"width": window.paned.get_position(),
          "layouts": sidebar._lists_paned.get_position(),
          "list_area": sidebar._lists_paned.get_height()}
vertical_handle = separator(sidebar._lists_paned)
horizontal_handle = separator(window.paned)
assert vertical_handle.get_height() >= 12
assert horizontal_handle.get_width() >= 10
drag(window, horizontal_handle, dx=170)
assert window.paned.get_position() >= before["width"] + 150
assert app.config.sidebar_width == window.paned.get_position()

# Collapse navigation to release the space formerly occupied by eight rows.
sidebar._navigation_expander.set_expanded(False)
settle()
assert sidebar._lists_paned.get_height() > before["list_area"] + 150
drag(window, vertical_handle, dy=260)
assert sidebar._layouts_section.get_height() >= before["layouts"] + 220
assert app.config.sidebar_layout_height == sidebar._lists_paned.get_position()
assert not app.config.sidebar_navigation_expanded

saved = {"width": app.config.sidebar_width, "layouts": app.config.sidebar_layout_height}
save_config_now(app.config)
window.destroy()
settle()
app.config = load_config()
window = new_window()
sidebar = window.sidebar
assert window.paned.get_position() == saved["width"]
assert sidebar._lists_paned.get_position() == saved["layouts"]
assert not sidebar._navigation_expander.get_expanded()

sidebar.set_logged_out(True)
settle()
assert sidebar._navigation_expander.get_expanded()
assert not app.config.sidebar_navigation_expanded
sidebar.set_logged_out(False)
settle()
assert not sidebar._navigation_expander.get_expanded()
assert sidebar._lists_paned.get_position() == saved["layouts"]

# Hiding a fullscreen sidebar must not save an invisible zero-sized pane.
window.toggle_sidebar(False)
settle()
assert app.config.sidebar_width == saved["width"]
window.toggle_sidebar(True)
settle()
assert window.paned.get_position() == saved["width"]

# Large persisted positions must still leave room for a smaller-screen view.
window.destroy()
settle()
app.config.sidebar_width = 1400
app.config.sidebar_layout_height = 1900
window = new_window(800, 600)
sidebar = window.sidebar
assert 180 <= window.paned.get_position() <= window.paned.get_width() - 320
assert 64 <= sidebar._lists_paned.get_position() <= sidebar._lists_paned.get_height() - 88

result = {"passed": True, "real_gtk": True, "pointer_drags_via_x11_xtest": True,
          "initial": before, "saved_and_restored": saved,
          "small_screen_width": window.paned.get_position(),
          "small_screen_layouts_height": sidebar._lists_paned.get_position(),
          "collapse_navigation_releases_space": True, "fullscreen_hide_preserves_width": True,
          "logout_settings_access_and_login_restore": True,
          "network_requests": 0}
Path(__file__).with_name("sidebar-resize-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2), flush=True)
window.destroy()
