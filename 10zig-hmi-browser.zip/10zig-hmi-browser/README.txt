HMI BROWSER FOR 10ZIG PEAKOS
Release 1.0.0 | Target: PeakOS 16.5.40, x86_64

PURPOSE

A minimal application window for your Ignition Perspective webpage. It
reuses the Google Chrome engine already included in PeakOS. It adds an
HMI Browser option to Connection Manager's New Connection list, with its
own named connections and editable kiosk setting.

This is a custom launcher/integration package, not a new rendering engine
or an official 10ZiG or Inductive Automation release. It needs no Internet
access on the 10ZiG and does not bundle another Chrome, Electron, Java,
Python, or browser engine. The 10ZiG must be able to reach the HMI Gateway.

MODES

Normal (default)
    Webpage in a movable/resizable window, without browser tabs, address
    bar, bookmarks, or extensions. The title bar has an X close button;
    the menu, minimize and maximize buttons are removed. Closing returns
    you to the desktop/Connection Manager.

Kiosk (optional)
    Full-screen webpage, with no ordinary window frame. Alt+F4 closes it
    unless your existing PeakOS keyboard restrictions block that shortcut.
    Change kiosk mode in this connection's Edit setup, then close/reopen.

Chrome can still show necessary security/authentication UI, such as a
certificate warning or a cross-origin identity indicator. This package
does not conceal those warnings or bypass website authentication.

INSTALL FROM WINDOWS AND USB

1. On the Windows computer, extract 10zig-hmi-browser.zip using Extract All.

2. Copy the inner folder named 10zig-hmi-browser to the top level of a USB
   drive. The folder contains install.sh, README.txt, and the other files.

3. Insert the USB into the 10ZiG. Use the administrator session. Open its
   console with Ctrl+Alt+Shift+0 (zero on the top number row).

4. With only one copy of that folder connected, type:

       sh /media/*/10zig-hmi-browser/install.sh

   If File Manager shows a different USB mount path, use its actual path
   to install.sh. No build tools, CentOS preparation, or downloads are
   required on the device.

5. The first install creates a 512 MiB persistent browser profile image on
   INTERNAL STORAGE. This is disk space, not 512 MiB of allocated RAM.
   Allow the installer to finish. It checks for 544 MiB free disk space.
   Future installs preserve this image and existing browser session data.

6. Once installation reports success, restart the 10ZiG normally and
   remove the USB.

7. In Connection Manager, choose New, select HMI Browser, then OK.

8. A small setup window asks for:

       Connection name [HMI]:
       Address:
       Enable kiosk mode? [y/N]:
       Save this connection? [Y/n]:

   Press Enter to keep the name HMI, or type another simple name. Enter
   the FULL Perspective address you already use in the browser, including
   http:// or https://, the port if required, and the project/page path.

   Example format only:
       http://192.168.1.100:8088/data/perspective/client/MyProject

   Use YOUR working address. Do not substitute that example IP or project.
   Do not put a username or password into the URL.

   Press Enter at the kiosk question for normal window mode; type Y for
   full screen. Press Enter to save, then Enter to close setup.

9. Double-click HMI (or your chosen connection name) in Connection Manager.
   Launching the HMI opens no terminal window. The setup window appears
   only when creating or editing a connection.

USE IT WITH CAMERAS

Close the previous Chrome/Firefox/10ZiG Browser HMI window before opening
this connection. If the old HMI connection autostarts, disable its
autostart so it does not run a second copy after the next reboot.

The native Cameras application can remain installed and operate normally.
Keep PeakOS in its existing Connection Manager/WBT desktop mode so both
applications remain available. Choosing kiosk in the HMI connection does
not switch the entire 10ZiG into single-application desktop mode.

Repeated clicks bring back the existing HMI window instead of opening
duplicate sessions. This package deliberately allows one HMI window at a
time. To open a different configured HMI connection, close the current
window first.

CHANGE THE ADDRESS OR KIOSK OPTION

Close HMI Browser. Right-click its connection in Connection Manager and
choose Edit. Press Enter to keep the current address, change kiosk to Y
or N, and save. Reopen the connection.

The package leaves boot autostart OFF initially. If desired, use the
normal Connection Manager startup/default-connection controls after
confirming your HMI address and mode. Existing operator/admin restrictions
continue to control who can create or edit connections. Hiding browser
controls is not a complete device access-control mechanism.

WHAT REDUCES OVERHEAD

- Uses the existing Chrome engine; no extra browser runtime or local web
  server is installed.
- One application window and a clean dedicated profile.
- Extensions and Chrome account synchronization are disabled for this
  launch. Translation/password-save prompts and background-app mode are
  disabled in this profile.
- Chromecast discovery and background Optimization Hints are disabled.
- Profile data and the disk cache are stored on a persistent ext4 image
  backed by the internal disk, supplying the Unix locks/symlinks Chrome
  requires even if the underlying /boot partition is FAT.
- No restore/recompress/freeze of a whole Chrome profile on every open
  or close. Settings are saved when edited.
- Browser diagnostic output is kept to two 64 KiB files on internal
  storage. It cannot grow without limit in the RAM-backed /tmp directory.
- A small native window helper adjusts just this window and exits. A
  small native log supervisor keeps diagnostics bounded while it runs.
  Neither helper runs another webpage or browser engine.
- GPU acceleration, JavaScript, WebSockets, browser sandboxing, cookie
  authentication, audio, normal TLS checks, and site isolation remain.

The disk cache target is 16 MiB. That is NOT a 16 MiB RAM limit. The
Perspective page's JavaScript, DOM, decoded pictures and graphics buffers
still require memory. Linux may cache disk-backed pages in RAM; those
pages are reclaimable, unlike files stored entirely on tmpfs.

No specific RAM reduction or camera-playback improvement is promised.
The actual 10ZiG/Gateway workload has not been benchmarked remotely. This
is a conservative compatibility-first reduction of browser overhead; it
cannot make a heavy Perspective project free to render on an Atom CPU.

AUTHENTICATION AND CERTIFICATES

Website cookies/local storage persist across ordinary closes and reboots,
subject to the Gateway's own expiration and login rules. The browser's
password-saving UI is disabled, so it is not a separate password vault.
Use the HMI's existing login or session-retention mechanism.

Private HTTPS certificates must be trusted through your normal 10ZiG
certificate configuration. This package does not ignore certificate
errors or disable browser security. The existing machine-wide managed
Chrome policies still apply; it does not bypass or overwrite them.

UNINSTALL

Close HMI Browser and its setup editor. In the administrative console:

    sh /boot/custom-apps/10zig-hmi-browser/uninstall.sh

Restart normally. This removes the HMI Browser type and its connections,
while retaining the profile and settings backup in its own internal folder.
It leaves Cameras, the regular browsers and other connections in place.

To also delete the retained HMI-only profile AFTER successful removal:

    rm -r /boot/custom-apps/10zig-hmi-browser

That final command erases this browser's saved cookies/session data.

RECOVER AN INTERRUPTED INSTALL OR UPDATE

If the installer reports a rollback command, run it before rebooting:

    sh /boot/custom-apps/10zig-hmi-browser/rollback.sh

The previous HMI registration/launchers are restored; the persistent
browser profile is kept. A failed first install rolls back the newly
added type. Backups remain under the application folder.

TARGET AND LIMITS

Built against the inspected PeakOS 16.5.40 firmware and its installed
Chrome paths and configuration schema. Your 4648qm running that PeakOS
image is the intended target. No firmware upgrade is required.

A later PeakOS/RepurpOS firmware version may change its application schema
or browser locations. This package does not claim untested support for
every 10ZiG model or OS release. A firmware upgrade may require reinstalling
the custom registration. Browser security updates come from your normal
10ZiG firmware/package update process.

All custom launch/install source is included in the ZIP. See RESEARCH.txt
and build-information for the source evidence and validation scope.
