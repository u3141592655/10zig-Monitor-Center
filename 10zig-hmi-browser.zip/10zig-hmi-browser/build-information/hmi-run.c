/* HMI Browser bounded log/child supervisor. MIT license, see LICENSE.txt.
 * Holds no page state. Stores at most two 64 KiB diagnostic files on disk.
 * It keeps draining output even after a storage error, so logging cannot
 * break the browser with SIGPIPE or consume unlimited memory.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t child_pid;
static volatile sig_atomic_t requested_signal;
static void forward_signal(int sig) {
    requested_signal=sig;
    if(child_pid>0) kill(-(pid_t)child_pid,sig);
}
static double monotime(void) {
    struct timespec t;
    if(clock_gettime(CLOCK_MONOTONIC,&t)) return 0;
    return (double)t.tv_sec+(double)t.tv_nsec/1000000000.0;
}
static int open_log(const char *path) {
    return open(path,O_WRONLY|O_CREAT|O_TRUNC|O_CLOEXEC|O_NOFOLLOW,0600);
}
int main(int argc,char **argv) {
    const size_t limit=65536;
    if(argc<4 || strcmp(argv[2],"--")) {
        fputs("Usage: hmi-run LOGFILE -- COMMAND [ARG...]\n",stderr);return 2;
    }
    if(strlen(argv[1])>4000) {fputs("Log path too long\n",stderr);return 2;}
    char previous[4020];
    snprintf(previous,sizeof previous,"%s.previous",argv[1]);
    int logfd=open_log(argv[1]);
    if(logfd<0) fputs("HMI Browser: diagnostics cannot be saved; output will be discarded.\n",stderr);
    unlink(previous);
    int fds[2];
    if(pipe2(fds,O_CLOEXEC)) {perror("pipe");if(logfd>=0)close(logfd);return 1;}
    pid_t pid=fork();
    if(pid<0) {perror("fork");return 1;}
    if(pid==0) {
        setpgid(0,0);
        close(fds[0]);
        if(dup2(fds[1],STDOUT_FILENO)<0 || dup2(fds[1],STDERR_FILENO)<0) _exit(126);
        close(fds[1]);
        if(logfd>=0)close(logfd);
        close(9); /* Only the supervisor/launcher owns the HMI singleton lock. */
        execvp(argv[3],argv+3);
        perror("HMI Browser: cannot start engine");_exit(127);
    }
    child_pid=pid;
    setpgid(pid,pid);
    close(fds[1]);
    struct sigaction sa;
    memset(&sa,0,sizeof sa);sa.sa_handler=forward_signal;sigemptyset(&sa.sa_mask);
    sigaction(SIGTERM,&sa,NULL);sigaction(SIGINT,&sa,NULL);sigaction(SIGHUP,&sa,NULL);
    signal(SIGPIPE,SIG_IGN);
    fcntl(fds[0],F_SETFL,fcntl(fds[0],F_GETFL)|O_NONBLOCK);
    int done=0,status=0,eof=0;
    double exit_time=0,signal_time=0;
    size_t written=0;
    char buffer[4096];
    for(;;) {
        if(!done) {
            pid_t found=waitpid(pid,&status,WNOHANG);
            if(found==pid) {done=1;exit_time=monotime();child_pid=0;}
            else if(found<0 && errno!=EINTR) {status=1<<8;done=1;exit_time=monotime();child_pid=0;}
        }
        if(requested_signal && !signal_time)signal_time=monotime();
        if(!done && signal_time && monotime()-signal_time>5.0)kill(-pid,SIGKILL);
        if(done && (eof || monotime()-exit_time>1.0))break;
        struct pollfd p={fds[0],POLLIN|POLLHUP,0};
        int ready=poll(&p,1,250);
        if(ready<0) {if(errno==EINTR)continue;break;}
        if(ready==0)continue;
        for(int burst=0;burst<32;++burst) {
            ssize_t n=read(fds[0],buffer,sizeof buffer);
            if(n==0) {eof=1;break;}
            if(n<0) {if(errno==EINTR)continue;if(errno!=EAGAIN && errno!=EWOULDBLOCK)eof=1;break;}
            if(logfd<0)continue;
            if(written+(size_t)n>limit) {
                close(logfd);logfd=-1;
                unlink(previous);
                if(rename(argv[1],previous)==0)logfd=open_log(argv[1]);
                written=0;
                if(logfd<0) {fputs("HMI Browser: diagnostic storage is unavailable.\n",stderr);continue;}
            }
            size_t offset=0;
            while(offset<(size_t)n) {
                ssize_t nw=write(logfd,buffer+offset,(size_t)n-offset);
                if(nw<0 && errno==EINTR)continue;
                if(nw<=0) {close(logfd);logfd=-1;break;}
                offset+=(size_t)nw;written+=(size_t)nw;
            }
        }
        if(eof && !done) {
            /* The child may close stdout long before its window closes. */
            struct timespec t={0,250000000};nanosleep(&t,NULL);
        }
    }
    close(fds[0]);if(logfd>=0)close(logfd);
    if(!done) {
        kill(-pid,SIGTERM);
        while(waitpid(pid,&status,0)<0 && errno==EINTR) {}
    }
    if(WIFEXITED(status))return WEXITSTATUS(status);
    if(WIFSIGNALED(status))return 128+WTERMSIG(status);
    return 1;
}
