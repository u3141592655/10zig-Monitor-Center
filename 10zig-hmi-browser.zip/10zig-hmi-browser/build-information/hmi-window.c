/* Small X11 window helper for the HMI application. MIT license.
 * No resident watcher: wait briefly for an exact class match, apply, then exit.
 * Uses only long-established Xlib/ICCCM/EWMH interfaces.
 */
#define _POSIX_C_SOURCE 200809L
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static int x_error(Display *d, XErrorEvent *e) { (void)d; (void)e; return 0; }
static int matches(Display *d, Window w, const char *name) {
    XClassHint hint = {0}; int yes = 0;
    if (XGetClassHint(d, w, &hint)) {
        yes = (hint.res_class && strcmp(hint.res_class, name) == 0) ||
              (hint.res_name && strcmp(hint.res_name, name) == 0);
        if (hint.res_name) XFree(hint.res_name);
        if (hint.res_class) XFree(hint.res_class);
    }
    return yes;
}
static Window tree_find(Display *d, Window parent, const char *name, int depth) {
    Window root, above, *children = NULL, found = None; unsigned int count = 0;
    if (depth <= 0 || !XQueryTree(d,parent,&root,&above,&children,&count)) return None;
    for (unsigned int i=0; i<count && found==None; ++i) {
        if (matches(d,children[i],name)) found=children[i];
        else found=tree_find(d,children[i],name,depth-1);
    }
    if (children) XFree(children);
    return found;
}
static Window find_window(Display *d, Window root, const char *name) {
    Atom actual = None; int fmt=0; unsigned long count=0, remain=0;
    unsigned char *data=NULL; Window found=None;
    Atom clients=XInternAtom(d,"_NET_CLIENT_LIST",False);
    if (XGetWindowProperty(d,root,clients,0,4096,False,XA_WINDOW,
        &actual,&fmt,&count,&remain,&data)==Success && actual==XA_WINDOW && fmt==32 && data) {
        Window *windows=(Window *)data;
        for (unsigned long i=0;i<count;++i) if(matches(d,windows[i],name)) {found=windows[i];break;}
    }
    if(data)XFree(data);
    return found!=None?found:tree_find(d,root,name,6);
}
static void decorate(Display *d, Window w) {
    /* flags: functions + decorations; functions: resize + move + close;
       decorations: border + resize handle + title. No menu/min/max buttons. */
    unsigned long hints[5] = {3UL,38UL,14UL,0UL,0UL};
    Atom motif=XInternAtom(d,"_MOTIF_WM_HINTS",False);
    XChangeProperty(d,w,motif,motif,32,PropModeReplace,(unsigned char *)hints,5);
}
static void activate(Display *d, Window root, Window w) {
    XEvent e; memset(&e,0,sizeof(e));
    e.xclient.type=ClientMessage;e.xclient.display=d;e.xclient.window=w;
    e.xclient.message_type=XInternAtom(d,"_NET_ACTIVE_WINDOW",False);
    e.xclient.format=32;e.xclient.data.l[0]=2;e.xclient.data.l[1]=CurrentTime;
    XMapRaised(d,w);
    XSendEvent(d,root,False,SubstructureRedirectMask|SubstructureNotifyMask,&e);
}
int main(int argc,char **argv) {
    const char *action=argc>1?argv[1]:"";
    const char *name=argc>2?argv[2]:"HmiBrowser";
    int loops=200;
    if (argc>3) {
        char *end; long seconds=strtol(argv[3],&end,10);
        if (*end || seconds<0 || seconds>60) {fputs("Timeout must be 0..60 seconds\n",stderr);return 2;}
        loops=(int)seconds*10;
    }
    if(argc>4 || (strcmp(action,"decorate") && strcmp(action,"activate"))) {
        fputs("Usage: hmi-window decorate|activate [exact-WM-class] [timeout-seconds]\n",stderr);return 2;
    }
    Display *d=XOpenDisplay(NULL);
    if(!d){fputs("HMI window helper: cannot open X display\n",stderr);return 1;}
    XSetErrorHandler(x_error);
    Window root=DefaultRootWindow(d),w=None;
    const struct timespec delay={0,100000000};
    for(int i=0;i<=loops;i++) {
        w=find_window(d,root,name);
        if(w!=None) break;
        if(i<loops)nanosleep(&delay,NULL);
    }
    if(w==None){XCloseDisplay(d);return 3;}
    if(!strcmp(action,"decorate"))decorate(d,w);else activate(d,root,w);
    XSync(d,False);XCloseDisplay(d);return 0;
}
