#!/usr/bin/env python3
"""Exercise the real installer/editor/removal scripts in an isolated filesystem.

Only absolute OS paths are rebased in private copies. Privileged mounts, image
formatting, and the vendor freeze operation are modeled; configuration reads and
writes use the actual PeakOS 16.5.40 getconfig executable and its libraries.
Nothing writes to the host /tmp/config, /boot, user accounts, or mount table.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile
import unittest
import xml.etree.ElementTree as ET


BUILD = Path(__file__).resolve().parents[1]
SOURCE = BUILD / "10zig-hmi-browser"
WORKSPACE = BUILD.parent
GETCONFIG = WORKSPACE / "hmi-firmware/extracted/desktop-base/utils/usr/bin/getconfig"
LIBS = WORKSPACE / "hmi-firmware/test-app-libs"


MOCK = r'''#!/usr/bin/python3
import json, os, pathlib, shutil, subprocess, sys, tarfile, uuid
root = pathlib.Path(os.environ['HMI_TEST_ROOT'])
name = pathlib.Path(sys.argv[0]).name
args = sys.argv[1:]
state_file = root / 'mock-mounts.json'
state = json.loads(state_file.read_text()) if state_file.exists() else {}
def update():
    state_file.write_text(json.dumps(state))
    mounts = root / 'proc/mounts'
    mounts.parent.mkdir(parents=True, exist_ok=True)
    mounts.write_text(''.join('/dev/' + v['device'] + ' ' + k + ' ext4 rw 0 0\n' for k, v in state.items()))
    for target, data in state.items():
        backing = root / 'sys/class/block' / data['device'] / 'loop/backing_file'
        backing.parent.mkdir(parents=True, exist_ok=True)
        backing.write_text(data['image'] + '\n')
if name == 'id':
    if args == ['chrome']: print('uid=140(chrome) gid=140(chrome) groups=140(chrome)')
    elif args in (['-u'], ['-u', 'chrome']): print(0 if len(args) == 1 else 140)
    elif args == ['-g', 'chrome']: print(140)
    else: raise SystemExit(subprocess.call(['/usr/bin/id', *args]))
elif name in ('chown', 'sync', 'mk_menu'):
    pass
elif name == 'df':
    print('Filesystem 1024-blocks Used Available Capacity Mounted on')
    print('fixture 2097152 0 2097152 0% ' + str(root / 'boot'))
elif name == 'dd':
    output = next(x[3:] for x in args if x.startswith('of='))
    pathlib.Path(output).write_text('hmi-test-image:' + uuid.uuid4().hex)
elif name == 'mkfs.ext4':
    assert pathlib.Path(args[-1]).is_file()
elif name == 'mountpoint':
    raise SystemExit(0 if args[-1] in state else 1)
elif name == 'mount':
    image, target = args[-2:]
    assert str(root) in image and str(root) in target
    token = pathlib.Path(image).read_text().split(':', 1)[1]
    storage = root / 'mock-images' / token
    storage.mkdir(parents=True, exist_ok=True)
    shutil.copytree(storage, target, dirs_exist_ok=True)
    device = 'loop' + str(len(state))
    state[target] = dict(image=image, device=device, storage=str(storage))
    update()
elif name == 'umount':
    target = args[-1]
    if target not in state: raise SystemExit(1)
    storage = pathlib.Path(state[target]['storage'])
    shutil.rmtree(storage)
    shutil.copytree(target, storage)
    for item in pathlib.Path(target).iterdir():
        if item.is_dir() and not item.is_symlink(): shutil.rmtree(item)
        else: item.unlink()
    del state[target]
    update()
elif name == 'losetup':
    image = args[-1]
    for target, data in state.items():
        if data['image'] == image: print('/dev/' + data['device'] + ': (' + image + ')')
elif name == 'freeze':
    mode = os.environ.get('HMI_TEST_FREEZE', 'normal')
    archive = root / 'boot/config.tar.gz'
    archive.parent.mkdir(parents=True, exist_ok=True)
    if mode == 'error': raise SystemExit(1)
    if mode == 'corrupt':
        archive.write_bytes(b'not a valid configuration archive')
        raise SystemExit(0)
    with tarfile.open(archive, 'w:gz') as out:
        def accept(info):
            if mode == 'exclude-hmi' and ('/hmi-browser' in info.name or '/hmibrowser' in info.name): return None
            return info
        out.add(root / 'tmp/config', arcname='config', filter=accept)
elif name in ('getconfig', 'getxmlconfig'):
    env = os.environ.copy()
    env['LD_LIBRARY_PATH'] = os.environ['HMI_TEST_LIBS']
    raise SystemExit(subprocess.call([os.environ['HMI_TEST_GETCONFIG'], *args], env=env))
else:
    raise SystemExit('unexpected mock utility: ' + name)
'''


class InstallIntegrationTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hmi-install-test-")
        self.root = Path(self.temp.name)
        self.package = self.root / "usb/10zig-hmi-browser"
        shutil.copytree(SOURCE, self.package)
        self.bin = self.root / "mock-bin"
        self.bin.mkdir()
        mock = self.bin / "mock-tool"
        mock.write_text(MOCK)
        mock.chmod(0o755)
        for name in ('id', 'chown', 'sync', 'mk_menu', 'df', 'dd', 'mkfs.ext4', 'mountpoint', 'mount', 'umount', 'losetup', 'freeze', 'getconfig', 'getxmlconfig'):
            (self.bin / name).symlink_to(mock)
        for path in self.package.rglob('*'):
            if path.is_file() and path.suffix in ('.sh', '.xml'):
                content = path.read_text()
                content = re.sub(r'/(tmp|boot|opt|proc|sys)(?=[/\s\"\'])', lambda m: str(self.root) + m.group(0), content)
                path.write_text(content)
        # Final-package assets are generated after production code review.
        if not (self.package / 'hmi-browser.png').exists():
            (self.package / 'hmi-browser.png').write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aNioAAAAASUVORK5CYII='))
        self.configuration = self.root / 'tmp/config'
        self.configuration.mkdir(parents=True)
        self.cameras = self.configuration / 'xmlconfig/user/software/shellscript/connections/Q2FtZXJhcw==.xml'
        self.cameras.parent.mkdir(parents=True)
        self.cameras.write_text('<camera-connection>keep me unchanged</camera-connection>')
        self.camera_app = self.configuration / 'files/Cameras.sh'
        self.camera_app.parent.mkdir(parents=True, exist_ok=True)
        self.camera_app.write_text('#!/bin/sh\nprintf cameras\n')
        self.restrictions = self.configuration / 'xmlconfig/user/system/security/config.xml'
        self.restrictions.parent.mkdir(parents=True)
        self.restrictions.write_text('<operator-settings>locked</operator-settings>')
        self.original_others = {p: p.read_bytes() for p in (self.cameras, self.camera_app, self.restrictions)}
        engine = self.root / 'opt/google/chrome/google-chrome'
        engine.parent.mkdir(parents=True)
        engine.write_text('#!/bin/sh\nexit 0\n')
        engine.chmod(0o755)
        self.installed = self.root / 'boot/custom-apps/10zig-hmi-browser'
        self.local = self.configuration / 'files/hmi-browser'
        self.app_config = self.configuration / 'xmlconfig/user/software/hmibrowser'
        self.image = self.installed / 'profile.ext4'
        self.env = os.environ.copy()
        self.env.update(PATH=str(self.bin) + ':/usr/bin:/bin', DISPLAY='', HMI_TEST_ROOT=str(self.root), HMI_TEST_LIBS=str(LIBS), HMI_TEST_GETCONFIG=str(GETCONFIG))
        self.checksums()

    def tearDown(self):
        self.temp.cleanup()

    def checksums(self):
        lines = []
        for path in sorted(self.package.rglob('*')):
            if path.is_file() and path.name != 'SHA256SUMS.txt':
                lines.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(self.package)))
        (self.package / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n')

    def run_script(self, path, *args, text='', freeze='normal', success=True):
        env = dict(self.env, HMI_TEST_FREEZE=freeze)
        result = subprocess.run(['/bin/sh', str(path), *args], input=text, env=env, text=True, capture_output=True, timeout=20)
        if success:
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        return result

    def install(self, **kwargs):
        return self.run_script(self.package / 'install.sh', **kwargs)

    def assert_others_preserved(self):
        for path, content in self.original_others.items():
            self.assertEqual(path.read_bytes(), content)

    def archive_names(self):
        with tarfile.open(self.root / 'boot/config.tar.gz') as archive:
            return archive.getnames()

    def profile_storage(self):
        token = self.image.read_text().split(':', 1)[1]
        return self.root / 'mock-images' / token

    def config_tool(self, path, *args):
        env = dict(self.env, LD_LIBRARY_PATH=str(LIBS))
        result = subprocess.run([str(GETCONFIG), *args[:1], str(path), *args[1:]], env=env, capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout.strip()

    def create_connection(self):
        self.run_script(self.local / 'settings.sh', '--console', 'new', text='HMI\nhttp://hmi.example.test:8088/data/perspective/client/Plant\n\n\n\n')
        return self.app_config / 'connections/SE1J.xml'

    def test_fresh_install_registers_native_option_without_changing_startup(self):
        self.install()
        self.assertTrue((self.app_config / 'connections').is_dir())
        self.assertTrue((self.local / 'start-hmi.sh').is_file())
        template = self.app_config / 'config.xml'
        self.assertEqual(self.config_tool(template, '-v', 'connMgrSettings.connType'), 'HMIBROWSER')
        self.assertEqual(self.config_tool(template, '-v', 'startupOptions.autoStartEnabled'), 'false')
        self.assertEqual(self.config_tool(template, '-v', 'startupOptions.defaultConnection'), 'false')
        self.assertEqual(self.config_tool(template, '-v', 'kiosk'), 'false')
        self.assertEqual(ET.parse(template).findtext('./attr/isConn'), 'false')
        self.assertIn('config/xmlconfig/user/software/hmibrowser/config.xml', self.archive_names())
        self.assertEqual((self.profile_storage() / '.hmi-profile-owner').read_text().strip(), '10zig-hmi-browser-profile-v1')
        self.assert_others_preserved()

    def test_native_editor_creates_and_edits_preserving_existing_startup_options(self):
        self.install()
        connection = self.create_connection()
        document = ET.parse(connection)
        self.assertEqual(document.findtext('./attr/isConn'), 'true')
        self.assertEqual(document.findtext('./attr/connName'), 'SE1J')
        self.assertEqual(self.config_tool(connection, '-v', 'connName'), 'SE1J')
        self.config_tool(connection, '-w', 'startupOptions.autoStartEnabled', 'true')
        self.config_tool(connection, '-w', 'startupOptions.defaultConnection', 'true')
        self.run_script(self.local / 'settings.sh', '--console', 'edit', 'SE1J', text='https://hmi.example.test/new?test=1&screen=2\ny\n\n\n')
        expected = base64.b64encode(b'https://hmi.example.test/new?test=1&screen=2').decode()
        self.assertEqual(self.config_tool(connection, '-v', 'url'), expected)
        self.assertEqual(self.config_tool(connection, '-v', 'kiosk'), 'true')
        self.assertEqual(self.config_tool(connection, '-v', 'startupOptions.autoStartEnabled'), 'true')
        self.assertEqual(self.config_tool(connection, '-v', 'startupOptions.defaultConnection'), 'true')
        self.assertIn('config/xmlconfig/user/software/hmibrowser/connections/SE1J.xml', self.archive_names())
        self.assert_others_preserved()

    def test_update_preserves_profile_connections_and_other_apps(self):
        self.install()
        connection = self.create_connection()
        self.config_tool(connection, '-w', 'startupOptions.autoStartEnabled', 'true')
        original_connection = connection.read_bytes()
        original_image = self.image.read_bytes()
        persistent = self.profile_storage() / 'profile/Default/operator-test-state'
        persistent.write_text('stored site state')
        launcher = self.package / 'start-hmi.sh'
        launcher.write_text(launcher.read_text() + '\n# revision used by update test\n')
        self.checksums()
        self.install()
        self.assertEqual(self.image.read_bytes(), original_image)
        self.assertEqual(connection.read_bytes(), original_connection)
        self.assertEqual((self.root / 'tmp/10zig-hmi-storage/profile/Default/operator-test-state').read_text(), 'stored site state')
        self.assertIn('revision used by update test', (self.local / 'start-hmi.sh').read_text())
        self.assert_others_preserved()

    def test_damaged_package_fails_before_installing(self):
        with (self.package / 'start-hmi.sh').open('a') as out:
            out.write('\ncorrupted after manifest\n')
        self.install(success=False)
        self.assertFalse(self.installed.exists())
        self.assertFalse(self.local.exists())
        self.assert_others_preserved()

    def test_foreign_installation_folder_is_not_adopted(self):
        self.local.mkdir()
        unrelated = self.local / 'unrelated.txt'
        unrelated.write_text('do not replace')
        self.install(success=False)
        self.assertEqual(unrelated.read_text(), 'do not replace')
        self.assertFalse(self.installed.exists())
        self.assert_others_preserved()

    def test_incomplete_freeze_is_detected_and_fresh_install_can_roll_back(self):
        self.install(freeze='exclude-hmi', success=False)
        original_image = self.image.read_bytes()
        self.run_script(self.installed / 'rollback.sh')
        self.assertFalse(self.local.exists())
        self.assertFalse(self.app_config.exists())
        self.assertEqual(self.image.read_bytes(), original_image)
        self.assertFalse(any('/hmibrowser' in name or '/hmi-browser' in name for name in self.archive_names()))
        self.assert_others_preserved()

    def test_failed_update_can_restore_previous_scripts_and_connections(self):
        self.install()
        connection = self.create_connection()
        original_connection = connection.read_bytes()
        original_launcher = (self.local / 'start-hmi.sh').read_bytes()
        original_image = self.image.read_bytes()
        launcher = self.package / 'start-hmi.sh'
        launcher.write_text(launcher.read_text() + '\n# bad update revision\n')
        self.checksums()
        self.install(freeze='error', success=False)
        self.run_script(self.installed / 'rollback.sh')
        self.assertEqual((self.local / 'start-hmi.sh').read_bytes(), original_launcher)
        self.assertEqual(connection.read_bytes(), original_connection)
        self.assertEqual(self.image.read_bytes(), original_image)
        self.assert_others_preserved()

    def test_uninstall_removes_only_our_registration_and_keeps_profile(self):
        self.install()
        self.create_connection()
        original_image = self.image.read_bytes()
        self.run_script(self.installed / 'uninstall.sh')
        self.assertFalse(self.local.exists())
        self.assertFalse(self.app_config.exists())
        self.assertEqual(self.image.read_bytes(), original_image)
        self.assertTrue(list(self.installed.glob('removed-config.*/config/connections/SE1J.xml')))
        self.assertFalse(any('/hmibrowser' in name or '/hmi-browser' in name for name in self.archive_names()))
        self.assert_others_preserved()

    def test_uninstall_must_not_claim_success_after_corrupt_freeze(self):
        self.install()
        self.run_script(self.installed / 'uninstall.sh', freeze='corrupt', success=False)
        self.assertTrue(self.image.is_file())
        self.assert_others_preserved()

    def test_empty_rollback_must_not_claim_success_after_corrupt_freeze(self):
        self.install()
        self.run_script(self.installed / 'rollback.sh', freeze='corrupt', success=False)
        self.assertTrue(self.image.is_file())
        self.assert_others_preserved()


if __name__ == '__main__':
    unittest.main(verbosity=2)
