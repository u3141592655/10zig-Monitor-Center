#!/usr/bin/env python3
"""Isolated launcher contract tests; never start Chrome or edit PeakOS files.

The actual shell launcher and URL validator are executed from a temporary copy.
Device preflight/profile mounting are stubbed because this host is not PeakOS.
The su/getconfig/icesh/chown command boundaries are captured. These tests prove
argument handling, single-instance behavior and failure reporting, not target
hardware memory consumption, GPU rendering or sandbox availability.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest


PACKAGE = Path(__file__).resolve().parents[1] / "10zig-hmi-browser"


def executable(path: Path, body: str) -> None:
    path.write_text(body, encoding="utf-8")
    path.chmod(0o755)


class LauncherContract(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="hmi-review-")
        self.root = Path(self.temp.name)
        self.local = self.root / "local"
        self.local.mkdir()
        self.run = self.root / "run"
        self.config = self.root / "configuration"
        (self.config / "connections").mkdir(parents=True)
        (self.config / "connections" / "SE1J.xml").write_text("fixture\n")
        self.capture = self.root / "capture.jsonl"
        self.activation = self.root / "activation.jsonl"
        self.stubdir = self.root / "commands"
        self.stubdir.mkdir()
        self.url = "http://hmi.example:8088/data/perspective/client/Factory"
        replacements = {
            "/tmp/config/files/hmi-browser": str(self.local),
            "/tmp/config/xmlconfig/user/software/hmibrowser": str(self.config),
            "/tmp/10zig-hmi-storage": str(self.root / "storage"),
            "/tmp/10zig-hmi-run": str(self.run),
            "/boot/custom-apps/10zig-hmi-browser": str(self.root / "installed"),
            "/var/run/HMIBROWSER": str(self.root / "pidfiles"),
        }
        for name in ("lib-hmi.sh", "start-hmi.sh"):
            text = (PACKAGE / name).read_text(encoding="utf-8")
            for old, new in replacements.items():
                text = text.replace(old, new)
            if name == "lib-hmi.sh":
                text += """
# Isolated fixture substitutions; production source is left untouched.
hmi_require_device() { return 0; }
hmi_mount_profile() { mkdir -p "$HMI_PROFILE"; }
hmi_prepare_certificates() { return 0; }
"""
            (self.local / name).write_text(text, encoding="utf-8")
        # The actual bounded-output child supervisor is part of this test.
        shutil.copy2(PACKAGE / "hmi-run", self.local / "hmi-run")
        executable(
            self.stubdir / "su",
            f"#!{sys.executable}\n"
            "import json, os, sys, time\n"
            "with open(os.environ['HMI_TEST_CAPTURE'], 'a') as f:\n"
            "    f.write(json.dumps(sys.argv[1:]) + '\\n')\n"
            "print('fixture engine message', flush=True)\n"
            "time.sleep(float(os.environ.get('HMI_TEST_HOLD', '0')))\n"
            "raise SystemExit(int(os.environ.get('HMI_TEST_EXIT', '0')))\n",
        )
        executable(
            self.stubdir / "getconfig",
            f"#!{sys.executable}\n"
            "import base64, os, sys\n"
            "field = sys.argv[-1]\n"
            "if field == 'url':\n"
            "    print(base64.b64encode(os.environ['HMI_TEST_URL'].encode()).decode())\n"
            "elif field == 'kiosk':\n"
            "    print(os.environ.get('HMI_TEST_KIOSK', 'false'))\n"
            "else:\n"
            "    raise SystemExit(2)\n",
        )
        executable(self.stubdir / "chown", "#!/bin/sh\nexit 0\n")
        executable(
            self.local / "hmi-window",
            f"#!{sys.executable}\n"
            "import json, os, sys\n"
            "with open(os.environ['HMI_TEST_ACTIVATION'], 'a') as f:\n"
            "    f.write(json.dumps(sys.argv[1:]) + '\\n')\n",
        )
        self.env = os.environ.copy()
        self.env.update(
            PATH=str(self.stubdir) + os.pathsep + self.env.get("PATH", "/usr/bin:/bin"),
            HMI_TEST_CAPTURE=str(self.capture),
            HMI_TEST_ACTIVATION=str(self.activation),
            HMI_TEST_URL=self.url,
        )
        self.env.pop("DISPLAY", None)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def launch(self, **environment: str) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["/bin/sh", str(self.local / "start-hmi.sh"), "SE1J"],
            env=self.env | environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=8,
        )

    def invocations(self) -> list[list[str]]:
        if not self.capture.exists():
            return []
        return [json.loads(line) for line in self.capture.read_text().splitlines()]

    def test_default_launch_has_unprivileged_app_window_and_separate_profile(self) -> None:
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stderr)
        args = self.invocations()[0]
        self.assertEqual(args[:3], ["chrome", "--", "/opt/google/chrome/google-chrome"])
        self.assertIn("--app=" + self.url, args)
        self.assertIn("--disable-extensions", args)
        self.assertIn("--user-data-dir=" + str(self.root / "storage" / "profile"), args)
        self.assertNotIn("--kiosk", args)
        self.assertFalse(any("no-sandbox" in arg or "disable-web-security" in arg for arg in args))
        self.assertFalse((self.root / "pidfiles" / "SE1J").exists())

    def test_kiosk_is_explicit_option(self) -> None:
        result = self.launch(HMI_TEST_KIOSK="true")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.invocations()[0].count("--kiosk"), 1)

    def test_metacharacters_stay_in_one_argument_and_are_never_evaluated(self) -> None:
        sentinel = self.root / "SHOULD-NOT-EXIST"
        url = (
            "http://hmi.example:8088/data/perspective/client/Factory"
            "?one=two&literal='double\"'&cmd=$(touch${IFS}"
            + str(sentinel)
            + ");still=literal#fragment"
        )
        result = self.launch(HMI_TEST_URL=url)
        self.assertEqual(result.returncode, 0, result.stderr)
        args = self.invocations()[0]
        self.assertEqual([arg for arg in args if arg.startswith("--app=")], ["--app=" + url])
        self.assertFalse(sentinel.exists())

    def test_engine_failure_returns_error_and_retains_message(self) -> None:
        result = self.launch(HMI_TEST_EXIT="42")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("42", result.stderr)
        error = (self.run / "error.txt").read_text()
        self.assertIn("42", error)
        self.assertIn("fixture engine message", error)
        self.assertFalse((self.root / "pidfiles" / "SE1J").exists())

    def test_invalid_address_never_starts_browser(self) -> None:
        result = self.launch(HMI_TEST_URL="file:///etc/passwd")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.invocations(), [])

    def test_duplicate_click_does_not_create_second_perspective_session(self) -> None:
        first = subprocess.Popen(
            ["/bin/sh", str(self.local / "start-hmi.sh"), "SE1J"],
            env=self.env | {"HMI_TEST_HOLD": "5"},
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            end = time.monotonic() + 3
            while not self.capture.exists() and time.monotonic() < end:
                time.sleep(0.02)
            self.assertTrue(self.capture.exists(), "first browser invocation never reached su")
            second = self.launch()
            self.assertEqual(second.returncode, 0, second.stderr)
            self.assertEqual(len(self.invocations()), 1)
            activate = [json.loads(line) for line in self.activation.read_text().splitlines()]
            self.assertIn(["activate", "HmiBrowser", "0"], activate)
        finally:
            if first.poll() is None:
                os.killpg(first.pid, signal.SIGTERM)
            first.wait(timeout=3)


class URLValidation(unittest.TestCase):
    def validate(self, value: str) -> int:
        return subprocess.run(
            ["/bin/sh", "-c", '. "$1"; hmi_validate_url "$2"', "review", str(PACKAGE / "lib-hmi.sh"), value],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=3,
        ).returncode

    def test_accepts_normal_perspective_routes(self) -> None:
        for value in (
            "http://192.168.18.2:8088/data/perspective/client/Plant",
            "https://ignition.example/data/perspective/client/Plant%20One?view=main&line=2#top",
            "http://[2001:db8::1]:8088/",
        ):
            with self.subTest(value=value):
                self.assertEqual(self.validate(value), 0)

    def test_rejects_non_web_and_ambiguous_addresses(self) -> None:
        for value in (
            "",
            "192.168.1.1",
            "file:///etc/passwd",
            "javascript:alert(1)",
            "data:text/html,test",
            "http://",
            "http:///missing-host",
            "http://?query-with-no-host",
            "https://user:password@server/",
            "http://server/space here",
            "http://server/line\nbreak",
            "http://server/tab\there",
            "http://server/escape\x1bhere",
            "http://server/" + "a" * 8192,
        ):
            with self.subTest(value=value[:80]):
                self.assertNotEqual(self.validate(value), 0)


class CertificatePreparation(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="hmi-certs-review-")
        self.root = Path(self.temp.name)
        self.chrome_home = self.root / "chrome"
        self.nss = self.chrome_home / ".pki" / "nssdb"
        self.capture = self.root / "su.jsonl"
        self.imports = self.root / "imports.jsonl"
        self.stubdir = self.root / "commands"
        self.stubdir.mkdir()
        self.lib = self.root / "lib-hmi.sh"
        text = (PACKAGE / "lib-hmi.sh").read_text()
        text = text.replace("/tmp/.chrome", str(self.chrome_home))
        self.lib.write_text(text)
        executable(self.stubdir / "chown", "#!/bin/sh\nexit 0\n")
        executable(self.stubdir / "certutil", "#!/bin/sh\nexit 0\n")
        executable(
            self.stubdir / "su",
            f"#!{sys.executable}\n"
            "import json, os, pathlib, sys\n"
            "with open(os.environ['HMI_CERT_CAPTURE'], 'a') as f:\n"
            "    f.write(json.dumps(sys.argv[1:]) + '\\n')\n"
            "code = int(os.environ.get('HMI_CERT_INIT_STATUS', '0'))\n"
            "if code == 0:\n"
            "    pathlib.Path(os.environ['HMI_CERT_NSS'], 'cert9.db').write_text('new fixture database')\n"
            "raise SystemExit(code)\n",
        )
        executable(
            self.stubdir / "install_newcerts.sh",
            f"#!{sys.executable}\n"
            "import json, os, sys\n"
            "with open(os.environ['HMI_CERT_IMPORTS'], 'a') as f:\n"
            "    f.write(json.dumps(sys.argv[1:]) + '\\n')\n"
            "raise SystemExit(int(os.environ.get('HMI_CERT_IMPORT_STATUS', '0')))\n",
        )
        self.env = os.environ.copy()
        self.env.update(
            PATH=str(self.stubdir) + os.pathsep + self.env.get("PATH", "/usr/bin:/bin"),
            HMI_CERT_CAPTURE=str(self.capture),
            HMI_CERT_IMPORTS=str(self.imports),
            HMI_CERT_NSS=str(self.nss),
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def prepare(self, **environment: str) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["/bin/sh", "-c", '. "$1"; hmi_prepare_certificates', "review", str(self.lib)],
            env=self.env | environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=3,
        )

    def test_new_store_initializes_as_chrome_with_fixed_command_then_imports(self) -> None:
        result = self.prepare(HMI_URL="https://hmi/?literal=$(do-not-execute)")
        self.assertEqual(result.returncode, 0, result.stderr)
        invocations = [json.loads(line) for line in self.capture.read_text().splitlines()]
        self.assertEqual(invocations, [[
            "chrome", "-s", "/bin/sh", "-c",
            "certutil -N --empty-password -d sql:" + str(self.nss),
        ]])
        imports = [json.loads(line) for line in self.imports.read_text().splitlines()]
        self.assertEqual(imports, [[str(self.nss)]])

    def test_existing_store_is_preserved_and_only_imported(self) -> None:
        self.nss.mkdir(parents=True)
        db = self.nss / "cert9.db"
        db.write_text("existing store must survive")
        result = self.prepare()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse(self.capture.exists())
        self.assertEqual(db.read_text(), "existing store must survive")
        self.assertTrue(self.imports.exists())

    def test_failed_initialization_does_not_attempt_import(self) -> None:
        result = self.prepare(HMI_CERT_INIT_STATUS="23")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.imports.exists())

    def test_import_failure_is_reported(self) -> None:
        result = self.prepare(HMI_CERT_IMPORT_STATUS="29")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("managed-certificate import", result.stderr)

    def test_symlink_store_is_rejected(self) -> None:
        other = self.root / "unrelated"
        other.mkdir()
        self.chrome_home.symlink_to(other, target_is_directory=True)
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.capture.exists())
        self.assertEqual(list(other.iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
