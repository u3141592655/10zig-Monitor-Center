#!/bin/sh
# Offline installer for the x86_64 PeakOS 16.5.40 HMI Browser integration.
set -eu
HMI_SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
. "$HMI_SOURCE/lib-hmi.sh"
HMI_STAGE=''
HMI_CREATE_MOUNT=''
HMI_COMMITTED=no
HMI_BACKUP=''
HMI_NEW_IMAGE=''

hmi_install_cleanup() {
    hmi_status=$?
    if [ -n "$HMI_CREATE_MOUNT" ]; then
        if mountpoint -q "$HMI_CREATE_MOUNT"; then umount "$HMI_CREATE_MOUNT" || :; fi
        rmdir "$HMI_CREATE_MOUNT" 2>/dev/null || :
    fi
    # Never delete a backing file if an interrupted mount still uses it.
    if [ -n "$HMI_NEW_IMAGE" ] && [ -f "$HMI_NEW_IMAGE" ]; then
        if ! losetup -j "$HMI_NEW_IMAGE" 2>/dev/null | grep -q .; then rm -f "$HMI_NEW_IMAGE"; fi
    fi
    [ -z "$HMI_STAGE" ] || [ ! -d "$HMI_STAGE" ] || rm -rf -- "$HMI_STAGE"
    if [ "$hmi_status" -ne 0 ] && [ "$HMI_COMMITTED" = yes ]; then
        printf '\nInstallation did not finish. The previous files are in:\n%s\n' "$HMI_BACKUP" >&2
        printf 'Restore with: sh /boot/custom-apps/10zig-hmi-browser/rollback.sh\n' >&2
    fi
}
trap hmi_install_cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM

hmi_require_device
hmi_prepare_run_dir
exec 9>"$HMI_RUN/browser.lock"
flock -n 9 || { hmi_fail 'Close HMI Browser before installing or updating.'; exit 1; }
exec 8>"$HMI_RUN/settings.lock"
flock -n 8 || { hmi_fail 'Close the HMI setup window before installing.'; exit 1; }
[ "$HMI_SOURCE" != "$HMI_ROOT" ] || { hmi_fail 'Run install.sh from the extracted USB package.'; exit 1; }

for hmi_required in SHA256SUMS.txt config.xml lib-hmi.sh start-hmi.sh settings.sh uninstall.sh rollback.sh hmi-browser.png hmi-run hmi-window config/Preferences.json config/Local-State.json; do
    [ -f "$HMI_SOURCE/$hmi_required" ] || { hmi_fail "The package is incomplete: $hmi_required"; exit 1; }
done
printf 'Checking HMI Browser package...\n'
(cd "$HMI_SOURCE" && sha256sum -c SHA256SUMS.txt) > "$HMI_RUN/install.log" 2>&1 || {
    tail -n 12 "$HMI_RUN/install.log" >&2
    hmi_fail 'The package is incomplete or damaged. Extract it again.'; exit 1;
}

# Do not adopt another application's directory merely because its name matches.
for hmi_owned in "$HMI_ROOT" "$HMI_LOCAL" "$HMI_CONFIG"; do
    [ ! -L "$hmi_owned" ] || { hmi_fail "Refusing a symbolic-link installation path: $hmi_owned"; exit 1; }
    if [ -e "$hmi_owned" ] && [ ! -f "$hmi_owned/.hmi-browser-package" ]; then
        hmi_fail "An unrecognized folder already exists at $hmi_owned. Nothing was replaced."; exit 1
    fi
done

mkdir -p "$HMI_ROOT"
printf 'hmi-browser-v1\n' > "$HMI_ROOT/.hmi-browser-package"
HMI_STAGE=$(mktemp -d "$HMI_ROOT/.install.XXXXXX")
cp -R "$HMI_SOURCE/." "$HMI_STAGE/"

if [ ! -f "$HMI_IMAGE" ]; then
    for hmi_tool in mkfs.ext4 dd df; do
        command -v "$hmi_tool" >/dev/null 2>&1 || { hmi_fail "Missing profile creation utility: $hmi_tool"; exit 1; }
    done
    hmi_free_kb=$(df -Pk "$HMI_ROOT" | awk 'NR == 2 {print $4}')
    case "$hmi_free_kb" in ''|*[!0-9]*) hmi_fail 'Cannot determine available internal storage.'; exit 1 ;; esac
    [ "$hmi_free_kb" -ge 557056 ] || { hmi_fail 'At least 544 MiB of free internal storage is needed for the persistent profile.'; exit 1; }
    [ ! -e "$HMI_ROOT/profile.new.ext4" ] && [ ! -L "$HMI_ROOT/profile.new.ext4" ] || { hmi_fail 'An unfinished profile image exists. See the installation log before retrying.'; exit 1; }
    HMI_NEW_IMAGE="$HMI_ROOT/profile.new.ext4"
    printf 'Creating a 512 MiB profile on internal storage. This can take a minute...\n'
    dd if=/dev/zero of="$HMI_NEW_IMAGE" bs=1048576 count=512 2>> "$HMI_RUN/install.log"
    mkfs.ext4 -q -F -m 0 -L HMI_BROWSER "$HMI_NEW_IMAGE" >> "$HMI_RUN/install.log" 2>&1
    HMI_CREATE_MOUNT=$(mktemp -d /tmp/hmi-profile-create.XXXXXX)
    mount -t ext4 -o loop,nodev,nosuid,noexec "$HMI_NEW_IMAGE" "$HMI_CREATE_MOUNT"
    printf '%s\n' "$HMI_MARKER" > "$HMI_CREATE_MOUNT/.hmi-profile-owner"
    mkdir -p "$HMI_CREATE_MOUNT/profile/Default" "$HMI_CREATE_MOUNT/cache"
    cp "$HMI_SOURCE/config/Preferences.json" "$HMI_CREATE_MOUNT/profile/Default/Preferences"
    cp "$HMI_SOURCE/config/Local-State.json" "$HMI_CREATE_MOUNT/profile/Local State"
    : > "$HMI_CREATE_MOUNT/profile/First Run"
    chown -R chrome:chrome "$HMI_CREATE_MOUNT/profile" "$HMI_CREATE_MOUNT/cache"
    chmod 700 "$HMI_CREATE_MOUNT/profile" "$HMI_CREATE_MOUNT/cache"
    sync
    umount "$HMI_CREATE_MOUNT"
    rmdir "$HMI_CREATE_MOUNT"
    HMI_CREATE_MOUNT=''
    mv "$HMI_NEW_IMAGE" "$HMI_IMAGE"
    HMI_NEW_IMAGE=''
else
    # An update never formats, replaces or reseeds an existing profile.
    hmi_mount_profile >> "$HMI_RUN/install.log" 2>&1 || { hmi_fail 'The existing HMI profile could not be verified.'; exit 1; }
fi

HMI_BACKUP=$(mktemp -d "$HMI_ROOT/backup.XXXXXX")
if [ -d "$HMI_LOCAL" ]; then cp -R "$HMI_LOCAL" "$HMI_BACKUP/local"; fi
if [ -d "$HMI_CONFIG" ]; then cp -R "$HMI_CONFIG" "$HMI_BACKUP/config"; fi
printf '%s\n' "$HMI_BACKUP" > "$HMI_ROOT/last-backup.txt"
cp "$HMI_SOURCE/rollback.sh" "$HMI_ROOT/rollback.sh"
cp "$HMI_SOURCE/lib-hmi.sh" "$HMI_ROOT/lib-hmi.sh"
cp "$HMI_SOURCE/uninstall.sh" "$HMI_ROOT/uninstall.sh"

HMI_COMMITTED=yes
mkdir -p "$HMI_LOCAL" "$HMI_CONFIG/connections"
printf 'hmi-browser-v1\n' > "$HMI_LOCAL/.hmi-browser-package"
printf 'hmi-browser-v1\n' > "$HMI_CONFIG/.hmi-browser-package"
for hmi_file in lib-hmi.sh start-hmi.sh settings.sh hmi-run hmi-window hmi-browser.png; do
    cp "$HMI_STAGE/$hmi_file" "$HMI_LOCAL/$hmi_file.new"
    case "$hmi_file" in *.sh|hmi-run|hmi-window) chmod 700 "$HMI_LOCAL/$hmi_file.new" ;; *) chmod 644 "$HMI_LOCAL/$hmi_file.new" ;; esac
    mv "$HMI_LOCAL/$hmi_file.new" "$HMI_LOCAL/$hmi_file"
done
cp "$HMI_STAGE/config.xml" "$HMI_CONFIG/config.xml.new"
mv "$HMI_CONFIG/config.xml.new" "$HMI_CONFIG/config.xml"
# Existing connection XMLs and all startup/operator restrictions stay in place.
printf '%s\n' "$HMI_RELEASE" > "$HMI_LOCAL/release.txt"
for hmi_doc in README.txt RESEARCH.txt LICENSE.txt; do
    [ ! -f "$HMI_STAGE/$hmi_doc" ] || cp "$HMI_STAGE/$hmi_doc" "$HMI_ROOT/$hmi_doc"
done
command -v mk_menu >/dev/null 2>&1 && mk_menu >/dev/null 2>&1 || :
printf 'Saving the new Connection Manager application type...\n'
hmi_save_configuration "$HMI_LOCAL/.hmi-browser-package" "$HMI_LOCAL/lib-hmi.sh" \
    "$HMI_LOCAL/start-hmi.sh" "$HMI_LOCAL/settings.sh" "$HMI_LOCAL/hmi-browser.png" "$HMI_LOCAL/hmi-run" "$HMI_LOCAL/hmi-window" \
    "$HMI_CONFIG/.hmi-browser-package" "$HMI_CONFIG/config.xml"
printf '%s\n' "$HMI_RELEASE" > "$HMI_ROOT/release.txt"
sync
printf '\nHMI Browser %s is installed.\n' "$HMI_RELEASE"
printf 'Restart the 10ZiG normally, then choose New > HMI Browser in Connection Manager.\n'
printf 'Enter the webpage address. Kiosk defaults to OFF.\n'
printf 'Your camera application and existing browser connections are unchanged.\n'
