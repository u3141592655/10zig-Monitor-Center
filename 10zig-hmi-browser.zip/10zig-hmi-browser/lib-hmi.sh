#!/bin/sh
# HMI Browser 1.0.0. These files are locally maintained, not a vendor release.
# Runtime helpers use only utilities already provided in PeakOS 16.5.40.

HMI_RELEASE='1.0.0'
HMI_ROOT='/boot/custom-apps/10zig-hmi-browser'
HMI_LOCAL='/tmp/config/files/hmi-browser'
HMI_CONFIG='/tmp/config/xmlconfig/user/software/hmibrowser'
HMI_MOUNT='/tmp/10zig-hmi-storage'
HMI_RUN='/tmp/10zig-hmi-run'
HMI_IMAGE="$HMI_ROOT/profile.ext4"
HMI_PROFILE="$HMI_MOUNT/profile"
HMI_MARKER='10zig-hmi-browser-profile-v1'
HMI_ICON="$HMI_LOCAL/hmi-browser.svg"
HMI_ENGINE='/opt/google/chrome/google-chrome'

hmi_fail() {
    printf '\nHMI Browser: %s\n' "$1" >&2
    return 1
}

hmi_require_device() {
    [ "$(id -u)" = 0 ] || { hmi_fail 'Use the PeakOS administrative desktop.'; return 1; }
    [ "$(uname -m)" = x86_64 ] || { hmi_fail 'This package requires x86_64 PeakOS.'; return 1; }
    [ -d /tmp/config/xmlconfig ] && command -v freeze >/dev/null 2>&1 || {
        hmi_fail 'PeakOS configuration storage was not found.'; return 1;
    }
    [ -x "$HMI_ENGINE" ] && id chrome >/dev/null 2>&1 || {
        hmi_fail 'The installed PeakOS Chrome engine and its chrome account are required.'; return 1;
    }
    for hmi_tool in flock mount mountpoint losetup stat getconfig base64 su; do
        command -v "$hmi_tool" >/dev/null 2>&1 || {
            hmi_fail "Required PeakOS utility is missing: $hmi_tool"; return 1;
        }
    done
}

hmi_prepare_run_dir() {
    [ ! -L "$HMI_RUN" ] || { hmi_fail 'The runtime directory is a symbolic link.'; return 1; }
    mkdir -p "$HMI_RUN" || return 1
    [ "$(stat -c %u "$HMI_RUN")" = 0 ] || {
        hmi_fail 'The runtime directory is not owned by the administrator.'; return 1;
    }
    chmod 700 "$HMI_RUN" || return 1
}

hmi_validate_id() {
    case "$1" in
        ''|*[!A-Za-z0-9+/=_-]*) hmi_fail 'Invalid HMI connection identifier.'; return 1 ;;
    esac
    [ "${#1}" -le 160 ] || { hmi_fail 'The connection identifier is too long.'; return 1; }
}

hmi_validate_url() {
    case "$1" in
        http://?*|https://?*) ;;
        *) hmi_fail 'Enter a complete http:// or https:// webpage address.'; return 1 ;;
    esac
    [ "${#1}" -le 8192 ] || { hmi_fail 'The webpage address is too long.'; return 1; }
    # Reject whitespace/control characters, not shell metacharacters: the URL
    # is never evaluated and is always passed as one argument to Chromium.
    if [ "$1" != "$(printf '%s' "$1" | LC_ALL=C tr -d '[:space:][:cntrl:]')" ]; then
        hmi_fail 'The address contains whitespace. Use URL encoding, such as %20, where needed.'; return 1
    fi
    hmi_authority=${1#*://}
    hmi_authority=${hmi_authority%%/*}
    hmi_authority=${hmi_authority%%\?*}
    hmi_authority=${hmi_authority%%\#*}
    case "$hmi_authority" in
        ''|*@*) hmi_fail 'Use a host/IP address without a username or password in the URL.'; return 1 ;;
    esac
}

hmi_mount_matches() {
    mountpoint -q "$HMI_MOUNT" || return 1
    hmi_device=$(awk -v target="$HMI_MOUNT" '$2 == target {print $1; exit}' /proc/mounts)
    case "$hmi_device" in /dev/loop[0-9]*) ;; *) return 1 ;; esac
    hmi_loop=${hmi_device##*/}
    hmi_backing=$(cat "/sys/class/block/$hmi_loop/loop/backing_file" 2>/dev/null) || return 1
    [ "$hmi_backing" = "$HMI_IMAGE" ] || [ "/$hmi_backing" = "$HMI_IMAGE" ] || return 1
    [ "$(cat "$HMI_MOUNT/.hmi-profile-owner" 2>/dev/null)" = "$HMI_MARKER" ] || return 1
}

hmi_mount_profile() {
    [ -f "$HMI_IMAGE" ] && [ ! -L "$HMI_IMAGE" ] || {
        hmi_fail 'The persistent browser profile is missing. Run the USB installer again.'; return 1;
    }
    [ ! -L "$HMI_MOUNT" ] || { hmi_fail 'The profile mountpoint is a symbolic link.'; return 1; }
    mkdir -p "$HMI_MOUNT" || return 1
    [ "$(stat -c %u "$HMI_MOUNT")" = 0 ] || { hmi_fail 'The profile mountpoint is not owned by the administrator.'; return 1; }
    if mountpoint -q "$HMI_MOUNT"; then
        hmi_mount_matches || {
            hmi_fail 'The profile mountpoint belongs to another filesystem. Restart before launching.'; return 1;
        }
    else
        [ -z "$(ls -A "$HMI_MOUNT")" ] || { hmi_fail 'The unmounted profile directory is not empty.'; return 1; }
        # Journal recovery is performed by the kernel on an ordinary ext4 mount.
        # Do not run filesystem repair against a mounted or active image.
        mount -t ext4 -o loop,nodev,nosuid,noexec "$HMI_IMAGE" "$HMI_MOUNT" || {
            hmi_fail 'The browser profile could not be mounted. See the launch log.'; return 1;
        }
        if ! hmi_mount_matches; then
            umount "$HMI_MOUNT" || :
            hmi_fail 'This profile image does not belong to HMI Browser.'; return 1
        fi
    fi
    [ -d "$HMI_PROFILE" ] && [ -w "$HMI_PROFILE" ] || {
        hmi_fail 'The persistent profile folder is unavailable.'; return 1;
    }
}

hmi_prepare_certificates() {
    # Match the vendor Chrome startup's use of the chrome account's NSS store.
    # Initialize it before opening HTTPS so the first HMI launch after reboot
    # can use CAs already installed through the PeakOS Certificates controls.
    hmi_nss='/tmp/.chrome/.pki/nssdb'
    command -v certutil >/dev/null 2>&1 && command -v install_newcerts.sh >/dev/null 2>&1 || {
        hmi_fail 'The PeakOS certificate import utilities are unavailable.'; return 1;
    }
    for hmi_cert_path in /tmp/.chrome /tmp/.chrome/.pki "$hmi_nss" "$hmi_nss/cert9.db" "$hmi_nss/key4.db" "$hmi_nss/pkcs11.txt"; do
        [ ! -L "$hmi_cert_path" ] || { hmi_fail 'The Chrome certificate store contains an unexpected symbolic link.'; return 1; }
    done
    mkdir -p /tmp/.chrome/.pki "$hmi_nss" && \
    chown chrome:chrome /tmp/.chrome /tmp/.chrome/.pki "$hmi_nss" || return 1
    if [ ! -f "$hmi_nss/cert9.db" ]; then
        # This is fixed shell text, not a command containing user input.
        su chrome -s /bin/sh -c 'certutil -N --empty-password -d sql:/tmp/.chrome/.pki/nssdb' || return 1
    fi
    install_newcerts.sh "$hmi_nss" || {
        hmi_fail 'The PeakOS managed-certificate import did not finish.'; return 1;
    }
}

hmi_save_configuration() {
    freeze || return 1
    # A successful exit alone is insufficient: freeze is vendor code and can
    # return after a partial save. Verify our files inside its actual archive.
    hmi_verify=$(mktemp -d /tmp/hmi-freeze-check.XXXXXX) || return 1
    hmi_saved=yes
    for hmi_path in "$@"; do
        case "$hmi_path" in /tmp/config/*) ;; *) hmi_saved=no; break ;; esac
        hmi_archive_path=${hmi_path#/tmp/}
        if ! tar -xOzf /boot/config.tar.gz "$hmi_archive_path" > "$hmi_verify/saved" 2>/dev/null || \
           ! cmp -s "$hmi_path" "$hmi_verify/saved"; then
            hmi_saved=no
            break
        fi
    done
    rm -f "$hmi_verify/saved"
    rmdir "$hmi_verify"
    [ "$hmi_saved" = yes ] || { hmi_fail 'PeakOS did not save the HMI configuration successfully.'; return 1; }
}
