#!/bin/sh
set -eu
HMI_ROOT='/boot/custom-apps/10zig-hmi-browser'
. "$HMI_ROOT/lib-hmi.sh"
hmi_require_device
hmi_prepare_run_dir
exec 9>"$HMI_RUN/browser.lock"
flock -n 9 || { hmi_fail 'Close HMI Browser before rolling back.'; exit 1; }
exec 8>"$HMI_RUN/settings.lock"
flock -n 8 || { hmi_fail 'Close HMI setup before rolling back.'; exit 1; }
HMI_BACKUP=$(cat "$HMI_ROOT/last-backup.txt")
case "$HMI_BACKUP" in "$HMI_ROOT"/backup.*) ;; *) hmi_fail 'Invalid rollback path.'; exit 1 ;; esac
[ -d "$HMI_BACKUP" ] && [ ! -L "$HMI_BACKUP" ] || { hmi_fail 'The backup directory is missing.'; exit 1; }
for hmi_owned in "$HMI_LOCAL" "$HMI_CONFIG"; do
    [ ! -L "$hmi_owned" ] || { hmi_fail 'Refusing a symbolic-link rollback destination.'; exit 1; }
    [ ! -e "$hmi_owned" ] || [ -f "$hmi_owned/.hmi-browser-package" ] || { hmi_fail 'An installation folder is no longer owned by HMI Browser.'; exit 1; }
done
rm -rf -- "$HMI_LOCAL" "$HMI_CONFIG"
[ ! -d "$HMI_BACKUP/local" ] || cp -R "$HMI_BACKUP/local" "$HMI_LOCAL"
[ ! -d "$HMI_BACKUP/config" ] || cp -R "$HMI_BACKUP/config" "$HMI_CONFIG"
command -v mk_menu >/dev/null 2>&1 && mk_menu >/dev/null 2>&1 || :
freeze
if [ -f "$HMI_LOCAL/start-hmi.sh" ]; then
    hmi_save_configuration "$HMI_LOCAL/start-hmi.sh" "$HMI_CONFIG/config.xml"
else
    tar -tzf /boot/config.tar.gz > "$HMI_RUN/saved-config-list.txt" || { hmi_fail 'The saved PeakOS archive cannot be read. Rollback has not been verified.'; exit 1; }
    if grep -E '^config/(files/hmi-browser|xmlconfig/user/software/hmibrowser)(/|$)' "$HMI_RUN/saved-config-list.txt" >/dev/null; then
        hmi_fail 'PeakOS did not save the rollback. Keep the backup and retry before rebooting.'; exit 1
    fi
    rm -f "$HMI_RUN/saved-config-list.txt"
fi
printf '\nPrevious HMI application registration restored. The browser profile is preserved.\nRestart normally.\n'
