#!/bin/sh
# Short-lived editor used directly by Connection Manager's New/Edit commands.
set -u
HMI_LOCAL='/tmp/config/files/hmi-browser'
. "$HMI_LOCAL/lib-hmi.sh"

HMI_CONSOLE=no
if [ "${1:-}" = --console ]; then HMI_CONSOLE=yes; shift; fi
HMI_ACTION=${1:-new}
HMI_EDIT_ID=${2:-}
case "$HMI_ACTION" in new|edit) ;; *) printf 'Usage: settings.sh [--console] new|edit [connection-id]\n' >&2; exit 2 ;; esac

if [ "$HMI_CONSOLE" != yes ]; then
    if [ -n "${DISPLAY:-}" ] && command -v rxvt-unicode >/dev/null 2>&1; then
        exec rxvt-unicode -title 'HMI Browser - Setup' -geometry 100x22 \
            -e /bin/sh "$HMI_LOCAL/settings.sh" --console "$HMI_ACTION" "$HMI_EDIT_ID"
    fi
    [ -t 0 ] || { printf 'Open the PeakOS console to configure HMI Browser.\n' >&2; exit 1; }
fi

hmi_editor_error() {
    printf '\n%s\n\nPress Enter to close. ' "$1" >&2
    IFS= read -r hmi_reply || :
    exit 1
}
hmi_require_device || hmi_editor_error 'This editor requires PeakOS and its installed Chrome package.'
hmi_prepare_run_dir || hmi_editor_error 'Cannot create the editor runtime directory.'
exec 8>"$HMI_RUN/settings.lock"
flock -n 8 || hmi_editor_error 'Another HMI setup window is already open. Close it first.'

HMI_NAME=HMI
HMI_OLD_URL=''
HMI_OLD_KIOSK=false
if [ "$HMI_ACTION" = edit ]; then
    hmi_validate_id "$HMI_EDIT_ID" || hmi_editor_error 'Invalid connection identifier.'
    HMI_EXISTING="$HMI_CONFIG/connections/$HMI_EDIT_ID.xml"
    [ -f "$HMI_EXISTING" ] || hmi_editor_error 'This HMI connection no longer exists.'
    [ "$(getconfig -v "$HMI_EXISTING" connMgrSettings.connType)" = HMIBROWSER ] || \
        hmi_editor_error 'The selected connection is not owned by HMI Browser.'
    HMI_NAME=$(printf '%s' "$HMI_EDIT_ID" | base64 -d) || hmi_editor_error 'The connection name is damaged.'
    HMI_OLD_URL=$(getconfig -v "$HMI_EXISTING" url | base64 -d) || HMI_OLD_URL=''
    HMI_OLD_KIOSK=$(getconfig -v "$HMI_EXISTING" kiosk) || HMI_OLD_KIOSK=false
fi

printf 'HMI BROWSER SETUP\n\n'
if [ "$HMI_ACTION" = new ]; then
    printf 'Connection name [HMI]: '
    IFS= read -r hmi_input || exit 0
    [ -z "$hmi_input" ] || HMI_NAME=$hmi_input
    case "$HMI_NAME" in
        ''|*[!a-zA-Z0-9_\ -]*) hmi_editor_error 'Use letters, numbers, spaces, hyphens or underscores in the name.' ;;
    esac
    [ "${#HMI_NAME}" -le 48 ] || hmi_editor_error 'Use a connection name of at most 48 characters.'
fi
HMI_ID=$(printf '%s' "$HMI_NAME" | base64 | tr -d '\r\n')
HMI_DEST="$HMI_CONFIG/connections/$HMI_ID.xml"
if [ "$HMI_ACTION" = new ] && [ -e "$HMI_DEST" ]; then
    hmi_editor_error 'That name already exists. Edit the existing connection or choose a new name.'
fi
printf '\nConnection: %s\n' "$HMI_NAME"
if [ -n "$HMI_OLD_URL" ]; then
    printf '\nCurrent webpage:\n%s\n\nNew address (Enter keeps it): ' "$HMI_OLD_URL"
else
    printf '\nEnter the full webpage address, including http:// or https://.\nAddress: '
fi
IFS= read -r HMI_URL || exit 0
[ -n "$HMI_URL" ] || HMI_URL=$HMI_OLD_URL
hmi_validate_url "$HMI_URL" || hmi_editor_error 'The webpage address could not be saved.'
if [ "$HMI_OLD_KIOSK" = true ]; then hmi_prompt='Y/n'; else hmi_prompt='y/N'; fi
printf '\nKiosk mode: full screen without the window frame.\nNormal mode: webpage with a close button, no browser toolbar or tabs.\n\nEnable kiosk mode? [%s]: ' "$hmi_prompt"
IFS= read -r hmi_input || exit 0
case "$hmi_input" in
    y|Y|yes|YES) HMI_KIOSK=true ;;
    n|N|no|NO) HMI_KIOSK=false ;;
    '') HMI_KIOSK=$HMI_OLD_KIOSK ;;
    *) hmi_editor_error 'Enter Y or N for kiosk mode.' ;;
esac
printf '\nSave this connection? [Y/n]: '
IFS= read -r hmi_input || exit 0
case "$hmi_input" in ''|y|Y|yes|YES) ;; *) exit 0 ;; esac

mkdir -p "$HMI_CONFIG/connections"
HMI_TEMP="$HMI_RUN/settings-new.xml"
# The vendor getconfig utility requires an actual .xml suffix, including for
# temporary files. The editor lock and root-only directory protect this path.
rm -f "$HMI_TEMP"
trap 'rm -f "$HMI_TEMP"' EXIT
if [ "$HMI_ACTION" = edit ]; then
    cp "$HMI_DEST" "$HMI_TEMP" || hmi_editor_error 'Cannot read the existing connection.'
else
    # The encoded identifier cannot contain the sed delimiter or XML syntax.
    sed -e 's|<isConn>false</isConn>|<isConn>true</isConn>|' \
        -e "s|<connName */>|<connName>$HMI_ID</connName>|" \
        "$HMI_CONFIG/config.xml" > "$HMI_TEMP" || hmi_editor_error 'Cannot create the connection template.'
fi
HMI_B64_URL=$(printf '%s' "$HMI_URL" | base64 | tr -d '\r\n')
getconfig -w "$HMI_TEMP" connName "$HMI_ID" >/dev/null 2>&1 && \
getconfig -w "$HMI_TEMP" url "$HMI_B64_URL" >/dev/null 2>&1 && \
getconfig -w "$HMI_TEMP" kiosk "$HMI_KIOSK" >/dev/null 2>&1 || hmi_editor_error 'PeakOS could not write the connection settings.'
[ "$(getconfig -v "$HMI_TEMP" url)" = "$HMI_B64_URL" ] && \
[ "$(getconfig -v "$HMI_TEMP" kiosk)" = "$HMI_KIOSK" ] || hmi_editor_error 'The written settings could not be verified.'

HMI_BACKUP="$HMI_RUN/settings-backup.xml"
rm -f "$HMI_BACKUP"
if [ "$HMI_ACTION" = edit ]; then cp "$HMI_DEST" "$HMI_BACKUP" || hmi_editor_error 'Cannot back up the existing settings.'; fi
mv "$HMI_TEMP" "$HMI_DEST" || hmi_editor_error 'Cannot commit the new connection.'
if ! hmi_save_configuration "$HMI_DEST" "$HMI_CONFIG/config.xml"; then
    if [ "$HMI_ACTION" = edit ]; then cp "$HMI_BACKUP" "$HMI_DEST"; else rm -f "$HMI_DEST"; fi
    freeze >/dev/null 2>&1 || :
    hmi_editor_error 'Saving failed. The previous configuration has been restored in memory. Reopen Setup before rebooting.'
fi
rm -f "$HMI_BACKUP"
command -v mk_menu >/dev/null 2>&1 && mk_menu >/dev/null 2>&1 || :
printf '\nSaved. Launch %s from Connection Manager.\n\nPress Enter to close this setup window. ' "$HMI_NAME"
IFS= read -r hmi_reply || :
exit 0
