#!/bin/sh
# One native Chromium app window, with a disk-backed persistent profile.
# The supervising shell sleeps in wait(); no Python or extra webview engine.
set -u
HMI_LOCAL='/tmp/config/files/hmi-browser'
. "$HMI_LOCAL/lib-hmi.sh"
HMI_LOG="$HMI_RUN/browser.log"

if [ "${1:-}" = --show-error ]; then
    cat "$HMI_RUN/error.txt" 2>/dev/null || :
    printf '\nPress Enter to close this message. '
    IFS= read -r hmi_reply || :
    exit 0
fi

hmi_launch_error() {
    printf '%s\n' "$1" >&2
    if [ -d "$HMI_RUN" ]; then
        {
            printf '%s\n\n' "$1"
            [ ! -s "$HMI_LOG" ] || tail -n 30 "$HMI_LOG"
            if [ "$HMI_LOG" != "$HMI_RUN/browser.log" ] && [ -s "$HMI_RUN/browser.log" ]; then
                printf '\nStartup messages:\n'
                tail -n 15 "$HMI_RUN/browser.log"
            fi
        } > "$HMI_RUN/error.txt"
        chmod 600 "$HMI_RUN/error.txt"
        if [ -n "${DISPLAY:-}" ] && command -v rxvt-unicode >/dev/null 2>&1; then
            rxvt-unicode -title 'HMI Browser - message' -geometry 100x20 \
                -e /bin/sh "$HMI_LOCAL/start-hmi.sh" --show-error 9>&- >/dev/null 2>&1 &
        fi
    fi
    exit 1
}

hmi_prepare_run_dir || exit 1
hmi_require_device || hmi_launch_error 'The PeakOS Chrome engine or a required system utility is unavailable.'
HMI_ID=${1:-SE1J}
hmi_validate_id "$HMI_ID" || hmi_launch_error 'The HMI connection identifier is invalid.'
HMI_XML="$HMI_CONFIG/connections/$HMI_ID.xml"
[ -f "$HMI_XML" ] || hmi_launch_error 'Create an HMI Browser connection in Connection Manager first.'
HMI_URL_B64=$(getconfig -v "$HMI_XML" url) || hmi_launch_error 'Cannot read the HMI connection.'
HMI_URL=$(printf '%s' "$HMI_URL_B64" | base64 -d) || hmi_launch_error 'The HMI address is damaged. Edit the connection and save it again.'
hmi_validate_url "$HMI_URL" || hmi_launch_error 'Edit this HMI Browser connection and enter a complete http:// or https:// address.'
HMI_KIOSK=$(getconfig -v "$HMI_XML" kiosk) || HMI_KIOSK=false
case "$HMI_KIOSK" in true|false) ;; *) hmi_launch_error 'The kiosk setting is invalid. Edit the connection and save it again.' ;; esac

exec 9>"$HMI_RUN/browser.lock"
if ! flock -n 9; then
    # One active window intentionally prevents repeated clicks from opening
    # duplicate Perspective sessions. This targets only our own window class.
    [ ! -x "$HMI_LOCAL/hmi-window" ] || "$HMI_LOCAL/hmi-window" activate HmiBrowser 0 9>&- >/dev/null 2>&1 || :
    exit 0
fi
: > "$HMI_RUN/browser.log"
chmod 600 "$HMI_RUN/browser.log"
hmi_mount_profile >> "$HMI_RUN/browser.log" 2>&1 || hmi_launch_error 'HMI Browser could not open its disk-backed profile.'
hmi_prepare_certificates >> "$HMI_RUN/browser.log" 2>&1 || hmi_launch_error 'HMI Browser could not prepare the normal PeakOS trusted certificates.'
HMI_LOG="$HMI_MOUNT/browser.log"

# Keep logs and browser caches on internal storage. /tmp/10zig-hmi-storage
# is an ext4 loop mount backed by /boot, not a RAM-backed profile.
HMI_CACHE="$HMI_MOUNT/cache"
mkdir -p "$HMI_CACHE" && chown chrome:chrome "$HMI_PROFILE" "$HMI_CACHE" && \
chmod 700 "$HMI_PROFILE" "$HMI_CACHE" || hmi_launch_error 'The browser profile or cache permissions could not be set.'

set -- \
    "--user-data-dir=$HMI_PROFILE" \
    "--disk-cache-dir=$HMI_CACHE" \
    --disk-cache-size=16777216 \
    --no-first-run \
    --no-default-browser-check \
    --disable-default-apps \
    --disable-extensions \
    --disable-component-extensions-with-background-pages \
    --disable-sync \
    --disable-features=MediaRouter,OptimizationHints \
    --class=HmiBrowser
if [ "$HMI_KIOSK" = true ]; then set -- "$@" --kiosk; fi
set -- "$@" "--app=$HMI_URL"

HMI_CHILD=''
HMI_DECOR=''
hmi_cleanup() {
    [ -z "$HMI_CHILD" ] || ! kill -0 "$HMI_CHILD" 2>/dev/null || kill -TERM "$HMI_CHILD" 2>/dev/null || :
    rm -f "/var/run/HMIBROWSER/$HMI_ID"
    [ -z "$HMI_DECOR" ] || ! kill -0 "$HMI_DECOR" 2>/dev/null || kill -TERM "$HMI_DECOR" 2>/dev/null || :
    # Leave this small persistent filesystem mounted; normal OS shutdown
    # flushes/unmounts it. A busy profile is never unmounted below a browser.
}
trap hmi_cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM
mkdir -p /var/run/HMIBROWSER
printf '%s\n' "$$" > "/var/run/HMIBROWSER/$HMI_ID"

# The real PeakOS Chrome package creates this unprivileged account and uses
# this su invocation. Preserve all argument boundaries; never run as root,
# disable the sandbox, evaluate the URL, or touch system-wide Chrome policy.
[ -x "$HMI_LOCAL/hmi-run" ] && [ -x "$HMI_LOCAL/hmi-window" ] || hmi_launch_error 'The small native helpers are missing. Run the USB installer again.'
"$HMI_LOCAL/hmi-run" "$HMI_LOG" -- su chrome -- "$HMI_ENGINE" "$@" 9>&- >> "$HMI_RUN/browser.log" 2>&1 &
HMI_CHILD=$!
if [ "$HMI_KIOSK" = false ]; then
    "$HMI_LOCAL/hmi-window" decorate HmiBrowser 20 9>&- >/dev/null 2>&1 &
    HMI_DECOR=$!
fi
wait "$HMI_CHILD"
HMI_STATUS=$?
HMI_CHILD=''
[ "$HMI_STATUS" -eq 0 ] || hmi_launch_error "The Chrome engine exited with status $HMI_STATUS. Its message follows."
exit 0
