#!/bin/sh
set -eu
HMI_ROOT='/boot/custom-apps/10zig-hmi-browser'
. "$HMI_ROOT/lib-hmi.sh"
hmi_require_device
hmi_prepare_run_dir
exec 9>"$HMI_RUN/browser.lock"
flock -n 9 || { hmi_fail 'Close HMI Browser before removing it.'; exit 1; }
exec 8>"$HMI_RUN/settings.lock"
flock -n 8 || { hmi_fail 'Close HMI setup before removing it.'; exit 1; }
for hmi_owned in "$HMI_ROOT" "$HMI_LOCAL" "$HMI_CONFIG"; do
    if [ -e "$hmi_owned" ] && { [ -L "$hmi_owned" ] || [ ! -f "$hmi_owned/.hmi-browser-package" ]; }; then
        hmi_fail "Unrecognized installation folder: $hmi_owned"; exit 1
    fi
done
if mountpoint -q "$HMI_MOUNT"; then
    hmi_mount_matches || { hmi_fail 'The profile mount does not belong to HMI Browser.'; exit 1; }
    umount "$HMI_MOUNT" || { hmi_fail 'The browser profile is still in use.'; exit 1; }
fi
hmi_backup=$(mktemp -d "$HMI_ROOT/removed-config.XXXXXX")
[ ! -d "$HMI_LOCAL" ] || cp -R "$HMI_LOCAL" "$hmi_backup/local"
[ ! -d "$HMI_CONFIG" ] || cp -R "$HMI_CONFIG" "$hmi_backup/config"
rm -rf -- "$HMI_LOCAL" "$HMI_CONFIG"
command -v mk_menu >/dev/null 2>&1 && mk_menu >/dev/null 2>&1 || :
freeze
tar -tzf /boot/config.tar.gz > "$HMI_RUN/saved-config-list.txt" || { hmi_fail 'The saved PeakOS archive cannot be read. Removal has not been verified.'; exit 1; }
if grep -E '^config/(files/hmi-browser|xmlconfig/user/software/hmibrowser)(/|$)' "$HMI_RUN/saved-config-list.txt" >/dev/null; then
    hmi_fail "PeakOS did not save the removal. Backup: $hmi_backup"; exit 1
fi
rm -f "$HMI_RUN/saved-config-list.txt"
printf '\nHMI Browser has been removed from Connection Manager. Restart normally.\n'
printf 'Its profile and a settings backup remain in %s.\n' "$HMI_ROOT"
printf 'To also erase that HMI-only profile after removal, run:\n'
printf '  rm -r /boot/custom-apps/10zig-hmi-browser\n'
